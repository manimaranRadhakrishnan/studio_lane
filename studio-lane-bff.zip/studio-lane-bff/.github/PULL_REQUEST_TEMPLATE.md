# Pull Request

## Description

Brief description of changes

## Type of Change

- [ ] Bug fix
- [ ] New feature
- [ ] Breaking change
- [ ] Documentation update
- [ ] Refactoring

## API Definition of Done Checklist

### Code Quality
- [ ] Endpoint implemented with full type hints
- [ ] RBAC enforced via `require_role()` dependency
- [ ] Request/response Pydantic models defined
- [ ] Tenant isolation verified in code
- [ ] Business logic in domain/application layers (not router)

### Testing
- [ ] Unit tests for domain logic (>90% coverage)
- [ ] Integration test (DB + endpoint)
- [ ] RBAC test (unauthorized returns 403)
- [ ] Multi-tenant test (no data leakage)
- [ ] Error cases tested (400, 404, 500)

### Documentation
- [ ] OpenAPI schema auto-generated
- [ ] Example request/response in docstring
- [ ] Error codes documented in `shared/error_codes.py`
- [ ] Business rules documented in domain service

### Observability
- [ ] Metrics emitted (via middleware, automatic)
- [ ] Trace span created (via middleware, automatic)
- [ ] Error scenarios logged with context
- [ ] Slow queries detected (>100ms)

### Security
- [ ] Input validation (Pydantic + custom rules)
- [ ] SQL injection protected (SQLAlchemy ORM)
- [ ] PII sanitized in logs
- [ ] Rate limiting configured
- [ ] No secrets in code/logs

## Testing

How was this tested?

## Related Issues

Closes #

## Screenshots (if applicable)

## Additional Notes

