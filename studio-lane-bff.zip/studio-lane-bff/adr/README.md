# ADRs: Studio Lane BFF

## Prefix: BFF-xxx

Use `BFF-001`, `BFF-002`, etc. for local service-specific decisions.

## Relevant Global ADRs

From `../docs/adr/INDEX.md`:
- [001](../../docs/adr/001-monorepo-structure.md) - Monorepo Structure
- [002](../../docs/adr/002-azure-infrastructure.md) - Azure Infrastructure
- [003](../../docs/adr/003-fastapi-backend.md) - FastAPI Framework (core to this service)

## Local ADRs

| ID | Title | Status | Date |
|----|-------|--------|------|
| [BFF-001](BFF-001-jwt-middleware.md) | JWT Middleware Pattern | Accepted | 2025-12-08 |

## When to Create BFF ADR

- Authentication/authorization patterns specific to BFF
- Workspace domain model decisions
- API endpoint organization
- Service-specific middleware
- Database schema choices

## Template

Use `../../docs/adr/template.md` for structure.

