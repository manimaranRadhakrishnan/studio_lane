# BFF-001: JWT Middleware Pattern

**Status**: Accepted  
**Date**: 2025-12-08  
**Deciders**: Backend Team  
**Tags**: auth, middleware, security

## Context

Need consistent auth across all BFF endpoints. Azure AD provides JWTs. Need to:
- Validate JWTs on every protected endpoint
- Extract user_id and tenant_id from claims
- Make available to endpoint handlers via dependency injection
- Handle token expiry and refresh

## Decision

Use **FastAPI dependency injection** for JWT validation:

```python
from fastapi.security import HTTPBearer
from jose import jwt, JWTError

security = HTTPBearer()

def verify_token(credentials: HTTPAuthorizationCredentials = Depends(security)) -> dict:
    token = credentials.credentials
    try:
        # Verify against Azure AD public keys
        decoded = jwt.decode(
            token,
            key=get_azure_ad_public_key(),
            algorithms=["RS256"],
            audience=os.getenv("AZURE_AD_CLIENT_ID"),
        )
        return decoded
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid token")

@app.get("/api/v1/resource")
async def get_resource(claims: dict = Depends(verify_token)):
    user_id = claims["sub"]
    tenant_id = claims["tenant_id"]
    # Use in query
```

## Consequences

### Positive
- Consistent auth across all endpoints
- Type-safe with dependency injection
- Easy to test (mock Depends)
- Automatic 401 on invalid tokens

### Negative
- Every endpoint must remember to add `Depends(verify_token)`
- No automatic global middleware (explicit per endpoint)

### Neutral
- Token refresh handled by frontend/Azure AD, not BFF

## Alternatives Considered

### Global middleware
- Applied to all routes
- Rejected: Can't easily exclude health checks, harder to test

### Decorator pattern
- `@require_auth` on functions
- Rejected: Less type-safe than Depends

## References

- Global: ADR-003 (FastAPI)
- Implementation: `services/auth/main.py`

