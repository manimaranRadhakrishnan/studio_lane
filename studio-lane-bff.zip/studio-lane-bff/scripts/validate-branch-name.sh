#!/bin/bash

# Branch name validation script for JIRA ticket enforcement
# This script validates that branch names contain JIRA ticket numbers
# Protected branches are exempt from validation

# Protected branches that don't require JIRA tickets
PROTECTED_BRANCHES=("main" "develop" "dev" "qa" "stage" "stg" "prod")

# Get current branch name
BRANCH_NAME=$(git rev-parse --abbrev-ref HEAD 2>/dev/null)

# If not in a git repository or branch name is empty, exit successfully
if [ -z "$BRANCH_NAME" ]; then
  exit 0
fi

# Check if branch is protected
for protected in "${PROTECTED_BRANCHES[@]}"; do
  if [ "$BRANCH_NAME" = "$protected" ]; then
    exit 0
  fi
done

# Validate branch name format
# Expected format: feature/JIRA-123-description or bug/JIRA-123-description
# JIRA ticket pattern: [A-Z]+-[0-9]+

# Check if branch starts with feature/ or bug/
if [[ ! "$BRANCH_NAME" =~ ^(feature|bug)/ ]]; then
  echo "❌ Branch name must start with 'feature/' or 'bug/' prefix"
  echo "   Example: feature/PROJ-123-description or bug/PROJ-456-fix-issue"
  exit 1
fi

# Extract the part after feature/ or bug/
BRANCH_SUFFIX="${BRANCH_NAME#*/}"

# Check if branch contains a JIRA ticket (format: PROJECT-123)
if [[ ! "$BRANCH_SUFFIX" =~ ^[A-Z]+-[0-9]+ ]]; then
  echo "❌ Branch name must include a JIRA ticket number immediately after the prefix"
  echo "   Expected format: feature/PROJECT-123-description or bug/PROJECT-456-description"
  echo "   Current branch: $BRANCH_NAME"
  exit 1
fi

# Extract JIRA ticket to validate format more strictly
if [[ "$BRANCH_SUFFIX" =~ ^([A-Z]+-[0-9]+) ]]; then
  JIRA_TICKET="${BASH_REMATCH[1]}"
  
  # Validate JIRA ticket format: at least one uppercase letter, dash, at least one digit
  if [[ ! "$JIRA_TICKET" =~ ^[A-Z]{2,}-[0-9]+$ ]]; then
    echo "❌ JIRA ticket format invalid: $JIRA_TICKET"
    echo "   Expected format: PROJECT-123 (uppercase letters, dash, numbers)"
    echo "   Example: PROJ-123, TEMENOS-456, JIRA-789"
    exit 1
  fi
else
  echo "❌ Could not extract JIRA ticket from branch name"
  echo "   Current branch: $BRANCH_NAME"
  exit 1
fi

# All validations passed
echo "✅ Branch name validated: $BRANCH_NAME (JIRA: $JIRA_TICKET)"
exit 0


