"""Error types and normalization for consistent API responses."""

import uuid
from typing import Any

from fastapi import HTTPException, Request, status
from fastapi.responses import JSONResponse
from opentelemetry import trace

from shared.error_codes import ErrorCode, get_error_message, get_support_contact


class AppError(Exception):
    """Base application error."""

    def __init__(
        self,
        message: str,
        error_code: str = "APP_ERROR",
        status_code: int = status.HTTP_500_INTERNAL_SERVER_ERROR,
        details: dict[str, Any] | None = None,
    ):
        self.message = message
        self.error_code = error_code
        self.status_code = status_code
        self.details = details or {}
        super().__init__(message)


class AuthError(AppError):
    """Authentication error."""

    def __init__(self, message: str = "Authentication failed", details: dict[str, Any] | None = None):
        super().__init__(
            message=message,
            error_code="AUTH_ERROR",
            status_code=status.HTTP_401_UNAUTHORIZED,
            details=details,
        )


class PermissionError(AppError):
    """Permission/authorization error."""

    def __init__(self, message: str = "Permission denied", details: dict[str, Any] | None = None):
        super().__init__(
            message=message,
            error_code="PERMISSION_DENIED",
            status_code=status.HTTP_403_FORBIDDEN,
            details=details,
        )


class NotFoundError(AppError):
    """Resource not found error."""

    def __init__(self, message: str = "Resource not found", details: dict[str, Any] | None = None):
        super().__init__(
            message=message,
            error_code="NOT_FOUND",
            status_code=status.HTTP_404_NOT_FOUND,
            details=details,
        )


class ValidationError(AppError):
    """Validation error."""

    def __init__(self, message: str = "Validation failed", details: dict[str, Any] | None = None):
        super().__init__(
            message=message,
            error_code="VALIDATION_ERROR",
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            details=details,
        )


class DownstreamError(AppError):
    """Error from downstream service (Gen/Delivery/Control)."""

    def __init__(
        self,
        service: str,
        message: str = "Downstream service error",
        status_code: int = status.HTTP_502_BAD_GATEWAY,
        details: dict[str, Any] | None = None,
    ):
        error_code = f"{service.upper()}_DOWNSTREAM_ERROR"
        super().__init__(
            message=message,
            error_code=error_code,
            status_code=status_code,
            details=details or {},
        )
        self.details["service"] = service


def _get_trace_id() -> str | None:
    span = trace.get_current_span()
    ctx = span.get_span_context()
    if not ctx or not ctx.is_valid:
        return None
    return format(ctx.trace_id, "032x")


def to_error_response(
    exc: Exception,
    trace_id: str | None = None,
    include_support: bool = False,
) -> dict[str, Any]:
    """
    Convert any exception to a normalized error response.

    Returns a stable JSON shape (legacy internal shape):
    {
        "errorCode": "...",
        "message": "...",
        "traceId": "...",
        "details": {...},
        "support": {...}  # Only for critical errors
    }

    Args:
        exc: Exception to convert
        trace_id: Correlation/trace ID
        include_support: Whether to include support contact info
    """
    if trace_id is None:
        trace_id = str(uuid.uuid4())

    if isinstance(exc, AppError):
        # Try to get standardized error code
        try:
            error_code_enum = ErrorCode(exc.error_code)
            user_message = get_error_message(error_code_enum)
        except ValueError:
            error_code_enum = None
            user_message = exc.message

        response = {
            "errorCode": exc.error_code,
            "message": user_message,
            "traceId": trace_id,
            "details": exc.details,
        }

        # Add support contact for critical errors
        if include_support and exc.status_code >= 500:
            response["support"] = get_support_contact()

        return response
    if isinstance(exc, HTTPException):
        return {
            "errorCode": ErrorCode.INTERNAL_ERROR.value,
            "message": exc.detail,
            "traceId": trace_id,
            "details": {},
        }
    # Generic unexpected error
    response = {
        "errorCode": ErrorCode.UNEXPECTED_ERROR.value,
        "message": get_error_message(ErrorCode.UNEXPECTED_ERROR),
        "traceId": trace_id,
        "details": {"error_type": type(exc).__name__},
    }

    # Always include support for unexpected errors
    response["support"] = get_support_contact()

    return response


async def global_exception_handler(request: Request, exc: Exception) -> JSONResponse:
    """
    Global exception handler for FastAPI.

    Catches all exceptions and returns normalized error responses.
    Tracks errors for observability.
    """
    # Correlation/trace meta
    correlation_id = request.headers.get("X-Correlation-Id") or request.headers.get("X-Correlation-ID")
    trace_id = _get_trace_id() or request.headers.get("traceId") or correlation_id or str(uuid.uuid4())
    request_id = request.headers.get("X-Request-Id")

    # Track error
    from shared.error_tracking import get_error_tracker
    error_tracker = get_error_tracker()

    # Get request context if available
    ctx = getattr(request.state, "request_context", None)
    context = {
        "path": request.url.path,
        "method": request.method,
        "trace_id": trace_id,
    }
    if ctx:
        context["tenant_id"] = ctx.tenant_id
        context["user_id"] = ctx.user_id

    fingerprint = error_tracker.track_error(exc, context)

    # Get recovery suggestion
    recovery_suggestion = error_tracker.get_recovery_suggestion(exc)

    def _meta() -> dict[str, Any]:
        return {
            "requestId": request_id,
            "correlationId": correlation_id,
            "traceId": trace_id,
        }

    if isinstance(exc, AppError):
        # Include support contact for 5xx errors
        include_support = exc.status_code >= 500
        legacy = to_error_response(exc, trace_id, include_support=include_support)
        details = legacy.get("details", {}) | {"fingerprint": fingerprint}
        if recovery_suggestion:
            details["recovery_suggestion"] = recovery_suggestion
        if "support" in legacy:
            details["support"] = legacy["support"]
        error_response = {
            "error": {
                "code": legacy["errorCode"],
                "message": legacy["message"],
                "details": details,
            },
            "meta": _meta(),
        }
        return JSONResponse(
            status_code=exc.status_code,
            content=error_response,
        )
    if isinstance(exc, HTTPException):
        legacy = to_error_response(exc, trace_id)
        error_response = {
            "error": {
                "code": legacy["errorCode"],
                "message": legacy["message"],
                "details": {"fingerprint": fingerprint},
            },
            "meta": _meta(),
        }
        return JSONResponse(
            status_code=exc.status_code,
            content=error_response,
        )
    # Log unexpected errors
    import logging
    logger = logging.getLogger(__name__)
    logger.exception(f"Unexpected error with trace_id={trace_id}: {exc}")

    legacy = to_error_response(exc, trace_id)
    details = legacy.get("details", {}) | {"fingerprint": fingerprint}
    if recovery_suggestion:
        details["recovery_suggestion"] = recovery_suggestion
    if "support" in legacy:
        details["support"] = legacy["support"]
    error_response = {
        "error": {
            "code": legacy["errorCode"],
            "message": legacy["message"],
            "details": details,
        },
        "meta": _meta(),
    }
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content=error_response,
    )

