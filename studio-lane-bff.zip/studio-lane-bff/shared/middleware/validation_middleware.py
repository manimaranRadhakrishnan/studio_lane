"""Request validation middleware: size limits, malformed JSON detection."""

import json
from collections.abc import Callable

from fastapi import Request, Response, status
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.types import ASGIApp


class ValidationMiddleware(BaseHTTPMiddleware):
    """
    Middleware to validate requests before processing.

    Validates:
    - Request size limits
    - JSON format validity
    - Content-Type headers
    """

    def __init__(
        self,
        app: ASGIApp,
        max_request_size: int = 10 * 1024 * 1024,  # 10MB default
    ):
        """
        Initialize validation middleware.

        Args:
            app: ASGI application
            max_request_size: Maximum request body size in bytes
        """
        super().__init__(app)
        self.max_request_size = max_request_size

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        """Process request with validation."""
        # Check content length
        content_length = request.headers.get("content-length")
        if content_length:
            try:
                size = int(content_length)
                if size > self.max_request_size:
                    return JSONResponse(
                        status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
                        content={
                            "errorCode": "REQUEST_TOO_LARGE",
                            "message": f"Request body exceeds maximum size of {self.max_request_size} bytes",
                            "max_size": self.max_request_size,
                            "received_size": size,
                        },
                    )
            except ValueError:
                pass  # Invalid content-length, let it proceed

        # Validate JSON for POST/PUT/PATCH requests
        if request.method in ["POST", "PUT", "PATCH"]:
            content_type = request.headers.get("content-type", "").lower()
            if "application/json" in content_type:
                try:
                    body = await request.body()
                    if body:
                        try:
                            json.loads(body)
                        except json.JSONDecodeError as e:
                            return JSONResponse(
                                status_code=status.HTTP_400_BAD_REQUEST,
                                content={
                                    "errorCode": "INVALID_JSON",
                                    "message": f"Malformed JSON in request body: {e!s}",
                                    "details": {"json_error": str(e)},
                                },
                            )
                        # Reset body stream for downstream handlers
                        async def receive():
                            return {"type": "http.request", "body": body}

                        request._receive = receive
                except Exception:
                    # If we can't read body, let it proceed (might be streaming)
                    pass

        return await call_next(request)

