"""Rate limiting middleware by tenant/user."""

import time
from collections import defaultdict
from collections.abc import Callable

from fastapi import Request, Response, status
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.types import ASGIApp

from shared.context import RequestContext


class RateLimitMiddleware(BaseHTTPMiddleware):
    """
    Simple in-memory rate limiting middleware.

    Limits requests per tenant/user per time window.
    For production, consider using Redis-based rate limiting.
    """

    def __init__(
        self,
        app: ASGIApp,
        requests_per_minute: int = 100,
        window_seconds: int = 60,
    ):
        """
        Initialize rate limit middleware.

        Args:
            app: ASGI application
            requests_per_minute: Maximum requests per minute per tenant
            window_seconds: Time window in seconds
        """
        super().__init__(app)
        self.requests_per_minute = requests_per_minute
        self.window_seconds = window_seconds
        self.requests: dict[str, list[float]] = defaultdict(list)

    def _cleanup_old_requests(self, key: str, now: float) -> None:
        """Remove requests outside the time window."""
        cutoff = now - self.window_seconds
        self.requests[key] = [
            timestamp for timestamp in self.requests[key] if timestamp > cutoff
        ]

    def _check_rate_limit(self, key: str) -> bool:
        """
        Check if request should be rate limited.

        Args:
            key: Rate limit key (tenant_id or user_id)

        Returns:
            True if request should be allowed, False if rate limited
        """
        now = time.time()
        self._cleanup_old_requests(key, now)

        if len(self.requests[key]) >= self.requests_per_minute:
            return False

        self.requests[key].append(now)
        return True

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        """Process request with rate limiting."""
        # Skip rate limiting for health checks
        if request.url.path.startswith("/health"):
            return await call_next(request)

        # Get rate limit key from request context
        ctx = getattr(request.state, "request_context", None)
        if ctx and isinstance(ctx, RequestContext):
            # Use tenant_id as rate limit key
            rate_limit_key = f"tenant:{ctx.tenant_id}"
        else:
            # Fallback to IP address if no context
            rate_limit_key = f"ip:{request.client.host if request.client else 'unknown'}"

        # Check rate limit
        if not self._check_rate_limit(rate_limit_key):
            return JSONResponse(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                content={
                    "errorCode": "RATE_LIMIT_EXCEEDED",
                    "message": f"Rate limit exceeded: {self.requests_per_minute} requests per {self.window_seconds} seconds",
                    "details": {
                        "limit": self.requests_per_minute,
                        "window_seconds": self.window_seconds,
                    },
                },
                headers={"Retry-After": str(self.window_seconds)},
            )

        return await call_next(request)

