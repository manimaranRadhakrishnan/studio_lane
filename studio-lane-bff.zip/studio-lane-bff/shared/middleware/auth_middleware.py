"""Authentication middleware for global JWT validation."""

from collections.abc import Callable

from fastapi import Request, Response
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.types import ASGIApp

from shared.auth import get_request_context
from shared.config import get_settings as _get_settings


security = HTTPBearer(auto_error=False)


class AuthMiddleware(BaseHTTPMiddleware):
    """
    Middleware to extract and validate JWT tokens.

    Adds RequestContext to request.state for use in endpoints.
    Can be combined with dependency-based auth for flexibility.
    """

    def __init__(self, app: ASGIApp, require_auth: bool = False):
        """
        Initialize auth middleware.

        Args:
            app: ASGI application
            require_auth: If True, reject requests without valid tokens
        """
        super().__init__(app)
        self.require_auth = require_auth

    async def dispatch(self, request: Request, call_next: Callable) -> Response:
        """Process request with authentication."""
        # Skip auth for health checks and public endpoints
        if request.url.path.startswith("/health") or request.url.path == "/":
            return await call_next(request)

        # Try to extract credentials
        authorization = request.headers.get("authorization")
        credentials = None
        if authorization and authorization.startswith("Bearer "):
            token = authorization[7:]  # Remove "Bearer " prefix
            credentials = HTTPAuthorizationCredentials(
                scheme="Bearer", credentials=token
            )

        # Extract request context if credentials available
        if credentials:
            try:
                settings = _get_settings()
                ctx = await get_request_context(
                    credentials=credentials,
                    x_correlation_id=request.headers.get("X-Correlation-ID"),
                    x_session_id=request.headers.get("X-Session-ID"),
                    x_cs_tenant_id=request.headers.get("X-CS-Tenant-Id"),
                    settings=settings,
                )
                # Store in request state for use in endpoints
                request.state.request_context = ctx
            except Exception:
                # Auth failed, but only reject if require_auth is True
                if self.require_auth:
                    from fastapi import status
                    from fastapi.responses import JSONResponse


                    return JSONResponse(
                        status_code=status.HTTP_401_UNAUTHORIZED,
                        content={
                            "errorCode": "AUTH_ERROR",
                            "message": "Authentication required",
                        },
                    )

        return await call_next(request)

