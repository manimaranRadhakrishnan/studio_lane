"""Delivery service HTTP client for preview, build, and release operations."""

from typing import Any

import httpx

from shared.config import Settings
from shared.context import RequestContext
from shared.http_utils import HttpClientContextManager
from shared.observability import LatencyTracker


class DeliveryClient:
    """
    HTTP client for Delivery services.

    Handles preview, build, and release orchestration.

    Can be used as async context manager:
        async with DeliveryClient(settings) as client:
            result = await client.start_build(...)
    """

    def __init__(self, settings: Settings):
        self.base_url = settings.delivery_base_url
        self.timeout = settings.http_timeout
        self.max_retries = settings.http_max_retries
        self.settings = settings
        self.client: httpx.AsyncClient | None = None
        self._context_manager: HttpClientContextManager | None = None

    async def __aenter__(self) -> "DeliveryClient":
        """Enter async context manager."""
        self._context_manager = HttpClientContextManager(
            base_url=self.base_url,
            timeout=self.timeout,
            max_retries=self.max_retries,
        )
        self.client = await self._context_manager.__aenter__()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        """Exit async context manager."""
        if self._context_manager:
            await self._context_manager.__aexit__(exc_type, exc_val, exc_tb)
            self.client = None
            self._context_manager = None

    def _ensure_client(self) -> httpx.AsyncClient:
        """Ensure client is initialized."""
        if self.client is None:
            # Fallback to manual initialization for backward compatibility
            self.client = httpx.AsyncClient(
                base_url=self.base_url,
                timeout=httpx.Timeout(self.timeout),
            )
        return self.client

    async def close(self) -> None:
        """Close HTTP client (for manual management)."""
        if self.client:
            await self.client.aclose()
            self.client = None

    def _headers(self, ctx: RequestContext) -> dict[str, str]:
        return {
            "X-Correlation-Id": ctx.correlation_id or "",
            "X-CS-Tenant-Id": ctx.tenant_id,
        }

    async def create_env(self, ctx: RequestContext, payload: dict[str, Any]) -> dict[str, Any]:
        client = self._ensure_client()
        with LatencyTracker("delivery", "create_env"):
            try:
                resp = await client.post("/v1/preview/envs", json=payload, headers=self._headers(ctx))
                resp.raise_for_status()
                return resp.json()
            except httpx.HTTPStatusError as e:
                raise Exception(e.response.text) from e

    async def refresh_env(self, ctx: RequestContext, env_id: str, tenant_id: str, payload: dict[str, Any]) -> dict[str, Any]:
        client = self._ensure_client()
        with LatencyTracker("delivery", "refresh_env"):
            resp = await client.post(
                f"/v1/preview/envs/{env_id}:refresh",
                params={"tenantId": tenant_id},
                json=payload,
                headers=self._headers(ctx),
            )
            resp.raise_for_status()
            return resp.json()

    async def revert_env(self, ctx: RequestContext, env_id: str, tenant_id: str, payload: dict[str, Any]) -> dict[str, Any]:
        client = self._ensure_client()
        with LatencyTracker("delivery", "revert_env"):
            resp = await client.post(
                f"/v1/preview/envs/{env_id}:revert",
                params={"tenantId": tenant_id},
                json=payload,
                headers=self._headers(ctx),
            )
            resp.raise_for_status()
            return resp.json()

    async def start_build(
        self,
        ctx: RequestContext,
        payload: dict[str, Any],
    ) -> dict[str, Any]:
        """
        Trigger a new build (contract-first).
        """
        client = self._ensure_client()
        with LatencyTracker("delivery", "start_build"):
            resp = await client.post("/v1/builds", json=payload, headers=self._headers(ctx))
            resp.raise_for_status()
            return resp.json()

    async def get_build(
        self,
        ctx: RequestContext,
        build_id: str,
        tenant_id: str,
    ) -> dict[str, Any]:
        """
        Get build status and artifacts.
        """
        client = self._ensure_client()
        with LatencyTracker("delivery", "get_build"):
            resp = await client.get(
                f"/v1/builds/{build_id}",
                params={"tenantId": tenant_id},
                headers=self._headers(ctx),
            )
            resp.raise_for_status()
            return resp.json()

    async def publish(self, ctx: RequestContext, payload: dict[str, Any]) -> dict[str, Any]:
        client = self._ensure_client()
        with LatencyTracker("delivery", "publish"):
            resp = await client.post("/v1/publish", json=payload, headers=self._headers(ctx))
            resp.raise_for_status()
            return resp.json()

    async def git_push(self, ctx: RequestContext, payload: dict[str, Any]) -> dict[str, Any]:
        client = self._ensure_client()
        with LatencyTracker("delivery", "git_push"):
            resp = await client.post("/v1/git/actions:push", json=payload, headers=self._headers(ctx))
            resp.raise_for_status()
            return resp.json()


async def get_delivery_client(settings: Settings) -> DeliveryClient:
    """Dependency to get Delivery client."""
    return DeliveryClient(settings)

