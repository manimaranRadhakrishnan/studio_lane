"""Authentication and JWT validation."""

import uuid

from cryptography.hazmat.primitives import serialization
from fastapi import Depends, Header
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from jose import JWTError, jwt

from shared.config import Settings, get_settings
from shared.context import RequestContext
from shared.errors import AuthError
from shared.jwt_cache import get_jwks_cache


security = HTTPBearer(auto_error=False)


async def verify_jwt_signature(token: str, settings: Settings) -> dict:
    """
    Verify and decode Temenos SSO JWT token with full validation.

    Validates:
    - Signature using public key from Azure AD JWKS
    - Issuer matches SSO authority
    - Audience matches SSO audience
    - Token expiration

    Args:
        token: JWT token string
        settings: Application settings

    Returns:
        Decoded token claims

    Raises:
        AuthError: If token is invalid, expired, or signature verification fails
    """
    # Check if JWKS URL is configured (required in production)
    if not settings.sso_jwks_url and settings.studio_env != "dev":
        raise AuthError(
            message="JWKS URL required in production. Set SSO_JWKS_URL environment variable."
        )

    try:
        # In development, allow skipping verification if JWKS not configured
        if not settings.sso_jwks_url and settings.studio_env == "dev":
            # Development mode: decode without verification
            return jwt.decode(
                token,
                key="",
                options={"verify_signature": False},
            )

        # Production mode: full verification
        # Get public key from JWKS cache
        jwks_cache = get_jwks_cache(settings)
        public_key = await jwks_cache.get_public_key(token)

        # Serialize public key to PEM format for jose
        public_key_pem = public_key.public_key_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        )

        # Verify and decode token
        return jwt.decode(
            token,
            key=public_key_pem,
            algorithms=["RS256"],
            audience=settings.sso_audience,
            issuer=settings.sso_authority,
            options={"verify_signature": True, "verify_aud": True, "verify_iss": True},
        )

    except JWTError as e:
        raise AuthError(message=f"Invalid JWT token: {e!s}") from e
    except Exception as e:
        raise AuthError(message=f"JWT verification failed: {e!s}") from e


def decode_temenos_jwt(token: str, settings: Settings) -> dict:
    """
    Decode and validate Temenos SSO JWT token.

    This is a synchronous wrapper that calls the async verification.
    For async contexts, use verify_jwt_signature directly.

    Note: In async FastAPI endpoints, this will work but is not optimal.
    Consider refactoring to use async verification directly.
    """
    import asyncio

    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            # If loop is running, we need to use a different approach
            # For now, fall back to development mode if JWKS not configured
            if not settings.sso_jwks_url:
                return jwt.decode(
                    token,
                    key="",
                    options={"verify_signature": False},
                )
            # In production with running loop, this is a limitation
            # Should be refactored to use async verification
            raise AuthError(
                message="JWT verification requires async context. Use verify_jwt_signature in async functions."
            )
        return loop.run_until_complete(verify_jwt_signature(token, settings))
    except RuntimeError:
        # No event loop, create one
        return asyncio.run(verify_jwt_signature(token, settings))


def extract_roles_from_claims(claims: dict) -> set[str]:
    """
    Extract roles from JWT claims.

    Maps Azure AD groups to Studio roles:
    - "Temenos-Studio-Owner" or "owner" → "Owner"
    - "Temenos-Studio-Editor" or "editor" → "Editor"

    Additional roles can be defined in custom claims.
    """
    roles = set()

    # Check groups claim (Azure AD)
    groups = claims.get("groups", [])
    if isinstance(groups, list):
        for group in groups:
            group_lower = str(group).lower()
            if "owner" in group_lower:
                roles.add("Owner")
            elif "editor" in group_lower:
                roles.add("Editor")

    # Check roles claim (custom)
    custom_roles = claims.get("roles", [])
    if isinstance(custom_roles, list):
        for role in custom_roles:
            if role in ["Owner", "Editor", "Viewer"]:
                roles.add(role)

    return roles


async def get_request_context(
    credentials: HTTPAuthorizationCredentials | None = Depends(security),  # noqa: B008
    x_correlation_id: str | None = Header(None),
    x_session_id: str | None = Header(None),
    x_cs_tenant_id: str | None = Header(None, alias="X-CS-Tenant-Id"),
    settings: Settings = Depends(get_settings),  # noqa: B008
) -> RequestContext:
    """
    FastAPI dependency to extract RequestContext from JWT.

    Validates JWT token, extracts tenant_id, user_id, and roles.
    Raises AuthError if token is missing or invalid.
    """
    if not credentials:
        raise AuthError(message="Missing Authorization header")

    token = credentials.credentials
    # Use async verification for proper signature checking
    claims = await verify_jwt_signature(token, settings)

    # Extract standard claims
    user_id = claims.get("sub") or claims.get("oid")
    if not user_id:
        raise AuthError(message="Missing user ID in token claims")

    # Extract tenant ID (from token) and validate against header (tenant scoping)
    tenant_id = claims.get("tenant_id") or claims.get("tid")
    if not tenant_id:
        raise AuthError(message="Missing tenant ID in token claims")

    # In production-grade mode, tenant scoping header should be present and must match token.
    # We don't derive tenant from payload; header is used as an explicit tenant routing guard.
    if settings.studio_env != "dev" and not x_cs_tenant_id:
        raise AuthError(message="Missing tenant scope header", details={"header": "X-CS-Tenant-Id"})
    if x_cs_tenant_id and x_cs_tenant_id != tenant_id:
        raise AuthError(message="Tenant scope mismatch", details={"headerTenantId": x_cs_tenant_id})

    # Extract roles
    roles = extract_roles_from_claims(claims)

    # Generate correlation ID if not provided
    correlation_id = x_correlation_id or str(uuid.uuid4())

    return RequestContext(
        tenant_id=tenant_id,
        user_id=user_id,
        roles=roles,
        session_id=x_session_id,
        correlation_id=correlation_id,
    )


async def get_optional_request_context(
    credentials: HTTPAuthorizationCredentials | None = Depends(security),  # noqa: B008
    x_correlation_id: str | None = Header(None),
    x_session_id: str | None = Header(None),
    x_cs_tenant_id: str | None = Header(None, alias="X-CS-Tenant-Id"),
    settings: Settings = Depends(get_settings),  # noqa: B008
) -> RequestContext | None:
    """
    Optional auth dependency - returns None if no credentials provided.

    Useful for endpoints that support both authenticated and anonymous access.
    """
    if not credentials:
        return None

    try:
        return await get_request_context(credentials, x_correlation_id, x_session_id, x_cs_tenant_id, settings)
    except AuthError:
        return None

