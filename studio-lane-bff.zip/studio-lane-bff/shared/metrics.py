"""Centralized metrics collection for Prometheus/OpenTelemetry."""


try:
    from prometheus_client import Counter, Gauge, Histogram
    PROMETHEUS_AVAILABLE = True
except ImportError:
    PROMETHEUS_AVAILABLE = False

from opentelemetry import metrics


# OpenTelemetry metrics
if not PROMETHEUS_AVAILABLE:
    meter = metrics.get_meter(__name__)


class MetricsCollector:
    """
    Centralized metrics collection.

    Supports both Prometheus and OpenTelemetry backends.
    """

    def __init__(self):
        """Initialize metrics collector."""
        if PROMETHEUS_AVAILABLE:
            # Prometheus metrics
            self.request_counter = Counter(
                "http_requests_total",
                "Total HTTP requests",
                ["method", "path", "status_code"],
            )
            self.request_duration = Histogram(
                "http_request_duration_seconds",
                "HTTP request duration in seconds",
                ["method", "path", "status_code"],
            )
            self.active_requests = Gauge(
                "http_active_requests",
                "Number of active HTTP requests",
            )
            self.db_query_duration = Histogram(
                "db_query_duration_seconds",
                "Database query duration in seconds",
                ["operation", "table"],
            )
            self.downstream_latency = Histogram(
                "downstream_request_duration_seconds",
                "Downstream service request duration",
                ["service", "operation"],
            )
        else:
            # OpenTelemetry metrics
            self.request_counter = meter.create_counter(
                "http_requests_total",
                description="Total HTTP requests",
            )
            self.request_duration = meter.create_histogram(
                "http_request_duration_seconds",
                description="HTTP request duration in seconds",
            )
            self.active_requests = meter.create_up_down_counter(
                "http_active_requests",
                description="Number of active HTTP requests",
            )

    def record_request(
        self,
        method: str,
        path: str,
        status_code: int,
        duration_ms: float,
    ) -> None:
        """
        Record HTTP request metrics.

        Args:
            method: HTTP method
            path: Request path
            status_code: Response status code
            duration_ms: Request duration in milliseconds
        """
        # Normalize path (remove IDs, etc.)
        normalized_path = self._normalize_path(path)

        if PROMETHEUS_AVAILABLE:
            self.request_counter.labels(
                method=method, path=normalized_path, status_code=status_code
            ).inc()
            self.request_duration.labels(
                method=method, path=normalized_path, status_code=status_code
            ).observe(duration_ms / 1000.0)
        else:
            self.request_counter.add(
                1,
                {
                    "method": method,
                    "path": normalized_path,
                    "status_code": str(status_code),
                },
            )
            self.request_duration.record(
                duration_ms / 1000.0,
                {
                    "method": method,
                    "path": normalized_path,
                    "status_code": str(status_code),
                },
            )

    def increment_active_requests(self) -> None:
        """Increment active requests counter."""
        if PROMETHEUS_AVAILABLE:
            self.active_requests.inc()
        else:
            self.active_requests.add(1)

    def decrement_active_requests(self) -> None:
        """Decrement active requests counter."""
        if PROMETHEUS_AVAILABLE:
            self.active_requests.dec()
        else:
            self.active_requests.add(-1)

    def record_db_query(
        self,
        operation: str,
        table: str,
        duration_ms: float,
    ) -> None:
        """
        Record database query metrics.

        Args:
            operation: Query operation (select, insert, update, delete)
            table: Table name
            duration_ms: Query duration in milliseconds
        """
        if PROMETHEUS_AVAILABLE:
            self.db_query_duration.labels(
                operation=operation, table=table
            ).observe(duration_ms / 1000.0)

    def record_downstream_latency(
        self,
        service: str,
        operation: str,
        duration_ms: float,
    ) -> None:
        """
        Record downstream service latency.

        Args:
            service: Service name (gen, delivery, fabric, audit)
            operation: Operation name
            duration_ms: Request duration in milliseconds
        """
        if PROMETHEUS_AVAILABLE:
            self.downstream_latency.labels(
                service=service, operation=operation
            ).observe(duration_ms / 1000.0)

    def _normalize_path(self, path: str) -> str:
        """
        Normalize path by replacing IDs with placeholders.

        Example: /api/workspaces/123 -> /api/workspaces/{id}
        """
        import re

        # Replace UUIDs
        path = re.sub(
            r"[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}",
            "{id}",
            path,
            flags=re.IGNORECASE,
        )

        # Replace numeric IDs
        return re.sub(r"/\d+", "/{id}", path)



# Global metrics instance
_metrics: MetricsCollector | None = None


def get_metrics() -> MetricsCollector:
    """Get or create global metrics collector."""
    global _metrics  # noqa: PLW0603
    if _metrics is None:
        _metrics = MetricsCollector()
    return _metrics

