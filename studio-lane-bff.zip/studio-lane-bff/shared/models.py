"""Common domain models and enums."""

from datetime import datetime
from enum import Enum
from typing import Literal

from pydantic import BaseModel, EmailStr, Field


# ==================== Enums ====================


class UserRole(str, Enum):
    """User roles for RBAC."""

    OWNER = "Owner"
    EDITOR = "Editor"
    VIEWER = "Viewer"


class ProjectStatus(str, Enum):
    """Project status."""

    DRAFT = "draft"
    ACTIVE = "active"
    ARCHIVED = "archived"


class PermissionLevel(str, Enum):
    """Project sharing permission level."""

    VIEW = "view"
    EDIT = "edit"


class TaskStatus(str, Enum):
    """Task planner status."""

    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"


class PreviewStatus(str, Enum):
    """Preview deployment status."""

    STARTING = "starting"
    RUNNING = "running"
    FAILED = "failed"
    STOPPED = "stopped"


class BuildStatus(str, Enum):
    """Build status."""

    QUEUED = "queued"
    BUILDING = "building"
    SUCCESS = "success"
    FAILED = "failed"


class ReleaseStatus(str, Enum):
    """Release status."""

    PENDING = "pending"
    DEPLOYING = "deploying"
    COMPLETED = "completed"
    FAILED = "failed"


# ==================== User Models ====================


class UserProfile(BaseModel):
    """User profile model."""

    id: str
    full_name: str | None = None
    email: EmailStr
    avatar_url: str | None = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


class UserRoleAssignment(BaseModel):
    """User role assignment (for workspace/project)."""

    id: str
    user_id: str
    workspace_id: str | None = None
    project_id: str | None = None
    role: UserRole
    created_at: datetime = Field(default_factory=datetime.utcnow)


# ==================== Workspace & Project Models ====================


class Workspace(BaseModel):
    """Workspace model (top-level organization unit)."""

    id: str
    name: str
    description: str | None = None
    tenant_id: str
    owner_id: str
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


class Folder(BaseModel):
    """Folder model for organizing projects within workspace."""

    id: str
    name: str
    workspace_id: str
    user_id: str
    tenant_id: str
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


class Project(BaseModel):
    """Project model."""

    id: str
    name: str
    description: str | None = None
    status: ProjectStatus = ProjectStatus.DRAFT
    workspace_id: str
    folder_id: str | None = None
    tenant_id: str
    user_id: str  # owner
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


class Favorite(BaseModel):
    """Favorite project model."""

    id: str
    user_id: str
    project_id: str
    created_at: datetime = Field(default_factory=datetime.utcnow)


class ProjectShare(BaseModel):
    """Project sharing model."""

    id: str
    project_id: str
    shared_by_user_id: str
    shared_with_email: EmailStr
    shared_with_user_id: str | None = None
    permission: PermissionLevel = PermissionLevel.VIEW
    created_at: datetime = Field(default_factory=datetime.utcnow)


# ==================== Design System Models ====================


class DesignSystem(BaseModel):
    """Design system model."""

    id: str
    name: str
    version: str
    description: str | None = None
    project_id: str | None = None  # Linked project
    tenant_id: str
    created_by: str
    config: dict = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


# ==================== Theme Models ====================


class Theme(BaseModel):
    """Theme model (colors/typography)."""

    id: str
    name: str
    tenant_id: str
    created_by: str
    description: str | None = None
    colors: dict = Field(default_factory=dict)
    typography: dict = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


# ==================== Context Library Models ====================


class ContextItem(BaseModel):
    """Prompt library / context catalog item."""

    id: str
    tenant_id: str
    title: str
    content: str
    tags: list[str] = Field(default_factory=list)
    version: int = 1
    created_by: str
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


class ProjectContextSelection(BaseModel):
    """Context selection state stored on a project (single-select for MVP)."""

    id: str  # use project_id as id for simple upsert semantics
    project_id: str
    tenant_id: str
    selected_context_ids: list[str] = Field(default_factory=list)
    updated_by: str
    updated_at: datetime = Field(default_factory=datetime.utcnow)


# ==================== Session Models ====================


class StudioSession(BaseModel):
    """Session projection for Studio Web (does not replace SSO)."""

    id: str
    tenant_id: str
    user_id: str
    created_at: datetime = Field(default_factory=datetime.utcnow)
    last_seen_at: datetime = Field(default_factory=datetime.utcnow)


# ==================== Conversation Models ====================


class ChatSession(BaseModel):
    """AI chat session model."""

    id: str
    project_id: str
    workspace_id: str
    user_id: str
    title: str = "New Chat"
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


class ChatMessage(BaseModel):
    """Chat message model."""

    id: str
    session_id: str
    role: Literal["user", "assistant"]
    content: str
    created_at: datetime = Field(default_factory=datetime.utcnow)


class Task(BaseModel):
    """Task planner task model."""

    id: str
    session_id: str
    title: str
    description: str | None = None
    status: TaskStatus = TaskStatus.PENDING
    agent: str | None = None  # Agent responsible for task
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    completed_at: datetime | None = None


# ==================== Delivery Models ====================


class Preview(BaseModel):
    """Preview deployment model."""

    id: str
    project_id: str
    environment_id: str
    status: PreviewStatus
    url: str | None = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


class Build(BaseModel):
    """Build model."""

    id: str
    project_id: str
    branch: str = "main"
    status: BuildStatus
    artifacts: list[dict] = Field(default_factory=list)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    completed_at: datetime | None = None


class Release(BaseModel):
    """Release model."""

    id: str
    project_id: str
    build_id: str
    target_environment: str
    status: ReleaseStatus
    deployed_at: datetime | None = None
    created_at: datetime = Field(default_factory=datetime.utcnow)


# ==================== File Models ====================


class File(BaseModel):
    """File model."""

    id: str
    name: str
    path: str
    project_id: str
    content: str | None = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


# ==================== Working Copy Models ====================


class WorkingCopyRef(BaseModel):
    """Working copy reference (pointer to Blob storage)."""

    blob_base_uri: str
    wc_version_stamp: str
    branch: str


class WorkingCopyMetadata(BaseModel):
    """Working copy metadata (BFF-owned pointers only; GenAI owns actual code in Blob)."""

    id: str  # Use wc_version_stamp as id
    tenant_id: str
    project_id: str
    branch: str
    wc_version_stamp: str
    blob_base_uri: str
    base_wc_version_stamp: str | None = None  # Parent version if cloned
    git_commit_sha: str | None = None  # Git commit SHA if synced from Git
    created_by: str | None = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


# ==================== Job Projection Models ====================


class GenRunStatus(str, Enum):
    """GenAI run status."""

    QUEUED = "queued"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class JobProjection(BaseModel):
    """BFF projection of GenAI run status/progress (UI-friendly view)."""

    id: str  # Use genRunId as id
    tenant_id: str
    project_id: str
    gen_run_id: str
    session_id: str | None = None
    status: GenRunStatus = GenRunStatus.QUEUED
    progress_percent: int = 0
    current_task_id: str | None = None
    tasks_completed: int = 0
    tasks_total: int = 0
    patch_set_id: str | None = None
    error_message: str | None = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    completed_at: datetime | None = None


# ==================== Lifecycle Timeline Models ====================


class PreviewTimelineEntry(BaseModel):
    """Preview environment timeline entry."""

    env_id: str
    status: PreviewStatus
    preview_url: str | None = None
    wc_version_stamp: str | None = None
    triggered_by: str | None = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


class BuildTimelineEntry(BaseModel):
    """Build timeline entry."""

    build_id: str
    status: BuildStatus
    platform: str | None = None
    logs_url: str | None = None
    artifact_id: str | None = None
    wc_version_stamp: str | None = None
    triggered_by: str | None = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    completed_at: datetime | None = None


class PublishTimelineEntry(BaseModel):
    """Publish timeline entry."""

    publish_id: str
    status: ReleaseStatus
    platforms: list[str] = Field(default_factory=list)
    artifacts: list[dict] = Field(default_factory=list)
    release_notes: str | None = None
    wc_version_stamp: str | None = None
    triggered_by: str | None = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    completed_at: datetime | None = None


class LifecycleTimeline(BaseModel):
    """UI-friendly lifecycle timeline per project (preview/build/publish history)."""

    id: str  # Use project_id as id for simple upsert semantics
    tenant_id: str
    project_id: str
    previews: list[PreviewTimelineEntry] = Field(default_factory=list)
    builds: list[BuildTimelineEntry] = Field(default_factory=list)
    publishes: list[PublishTimelineEntry] = Field(default_factory=list)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

