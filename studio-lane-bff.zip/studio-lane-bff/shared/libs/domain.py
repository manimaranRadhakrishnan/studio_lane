"""Common domain models."""

from datetime import datetime
from enum import Enum
from typing import Literal

from pydantic import BaseModel, EmailStr, Field


class AppRole(str, Enum):
    """User roles in the system."""

    ADMIN = "admin"
    MANAGER = "manager"
    STAFF = "staff"


class ProjectStatus(str, Enum):
    """Project status."""

    DRAFT = "draft"
    ACTIVE = "active"
    ARCHIVED = "archived"


class DeploymentStatus(str, Enum):
    """Deployment status."""

    PENDING = "pending"
    DEPLOYING = "deploying"
    SUCCESS = "success"
    FAILED = "failed"


class PermissionLevel(str, Enum):
    """Project sharing permission level."""

    VIEW = "view"
    EDIT = "edit"


class UserProfile(BaseModel):
    """User profile model."""

    id: str
    full_name: str | None = None
    email: EmailStr
    avatar_url: str | None = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


class UserRole(BaseModel):
    """User role assignment model."""

    id: str
    user_id: str
    role: AppRole
    created_at: datetime = Field(default_factory=datetime.utcnow)


class Folder(BaseModel):
    """Folder model for organizing projects."""

    id: str
    name: str
    user_id: str
    tenant_id: str
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


class Project(BaseModel):
    """Project model."""

    id: str
    name: str
    description: str | None = None
    status: ProjectStatus = ProjectStatus.DRAFT
    folder_id: str | None = None
    tenant_id: str
    user_id: str  # owner_id in Supabase
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


class Favorite(BaseModel):
    """Favorite project model."""

    id: str
    user_id: str
    project_id: str
    created_at: datetime = Field(default_factory=datetime.utcnow)


class ProjectShare(BaseModel):
    """Project sharing model."""

    id: str
    project_id: str
    shared_by_user_id: str
    shared_with_email: EmailStr
    shared_with_user_id: str | None = None
    permission: PermissionLevel = PermissionLevel.VIEW
    created_at: datetime = Field(default_factory=datetime.utcnow)


class Deployment(BaseModel):
    """Deployment model."""

    id: str
    project_id: str
    status: DeploymentStatus = DeploymentStatus.PENDING
    url: str | None = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


class ChatSession(BaseModel):
    """AI chat session model."""

    id: str
    project_id: str
    user_id: str
    title: str = "New Chat"
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


class ChatMessage(BaseModel):
    """Chat message model."""

    id: str
    session_id: str
    role: Literal["user", "assistant"]
    content: str
    created_at: datetime = Field(default_factory=datetime.utcnow)


class File(BaseModel):
    """File model."""

    id: str
    name: str
    path: str
    project_id: str
    content: str | None = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

