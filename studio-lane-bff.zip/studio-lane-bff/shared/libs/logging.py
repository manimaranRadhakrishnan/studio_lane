"""Structured logging configuration."""

import json
import logging
import sys
from datetime import datetime
from typing import Any


class JSONFormatter(logging.Formatter):
    """JSON formatter for structured logging."""

    def format(self, record: logging.LogRecord) -> str:
        log_data: dict[str, Any] = {
            "timestamp": datetime.utcnow().isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }

        if record.exc_info:
            log_data["exception"] = self.formatException(record.exc_info)

        # Add extra fields
        if hasattr(record, "correlation_id"):
            log_data["correlation_id"] = record.correlation_id
        if hasattr(record, "tenant_id"):
            log_data["tenant_id"] = record.tenant_id
        if hasattr(record, "user_id"):
            log_data["user_id"] = record.user_id

        return json.dumps(log_data)


def setup_logging(level: str = "INFO") -> None:
    """
    Setup structured JSON logging.

    Note: This function sets up console logging with JSON formatter.
    OpenTelemetry logging instrumentation (configured in observability.py)
    will automatically capture these logs and forward them to Azure Application Insights.
    """
    root_logger = logging.getLogger()
    root_logger.setLevel(getattr(logging, level.upper()))

    # Check if OpenTelemetry handler already exists
    has_otel_handler = any(
        isinstance(h, logging.Handler) and hasattr(h, 'logger_provider')
        for h in root_logger.handlers
    )

    # Only add console handler if OpenTelemetry handler is not present
    # (OpenTelemetry handler is added in observability.py)
    if not has_otel_handler:
        handler = logging.StreamHandler(sys.stdout)
        handler.setFormatter(JSONFormatter())
        root_logger.addHandler(handler)

