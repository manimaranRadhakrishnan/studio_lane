"""JWKS (JSON Web Key Set) caching for Azure AD token verification."""

import time

import httpx
from cryptography.hazmat.primitives.asymmetric import rsa
from jose import jwk, jwt

from shared.config import Settings
from shared.errors import AuthError


class JWKSCache:
    """
    Cache for Azure AD JWKS (JSON Web Key Set).

    Fetches and caches public keys from Azure AD JWKS endpoint.
    Keys are cached for 24 hours to reduce API calls.
    """

    def __init__(self, settings: Settings):
        self.settings = settings
        self.jwks_url = settings.sso_jwks_url
        self.cache_ttl = 24 * 60 * 60  # 24 hours in seconds
        self._keys: dict[str, dict] = {}
        self._cache_timestamp: float | None = None
        self._client = httpx.AsyncClient(timeout=httpx.Timeout(10.0))

    async def _fetch_jwks(self) -> dict:
        """
        Fetch JWKS from Azure AD endpoint.

        Returns:
            Dictionary containing keys from JWKS endpoint

        Raises:
            AuthError: If JWKS URL is not configured or fetch fails
        """
        if not self.jwks_url:
            raise AuthError(
                message="JWKS URL not configured. Set SSO_JWKS_URL environment variable."
            )

        try:
            response = await self._client.get(self.jwks_url)
            response.raise_for_status()
            return response.json()
        except httpx.RequestError as e:
            raise AuthError(
                message=f"Failed to fetch JWKS from {self.jwks_url}: {e!s}"
            ) from e
        except httpx.HTTPStatusError as e:
            raise AuthError(
                message=f"JWKS endpoint returned error: {e.response.status_code}"
            ) from e

    async def _get_jwks(self) -> dict:
        """
        Get JWKS, using cache if available and fresh.

        Returns:
            JWKS dictionary
        """
        now = time.time()

        # Check if cache is valid
        if (
            self._cache_timestamp is not None
            and (now - self._cache_timestamp) < self.cache_ttl
            and self._keys
        ):
            return {"keys": list(self._keys.values())}

        # Fetch fresh JWKS
        jwks_data = await self._fetch_jwks()
        keys = jwks_data.get("keys", [])

        # Cache keys by kid (key ID)
        self._keys = {key["kid"]: key for key in keys}
        self._cache_timestamp = now

        return jwks_data

    async def get_public_key(self, token: str) -> rsa.RSAPublicKey:
        """
        Get public key for verifying a JWT token.

        Args:
            token: JWT token string (header will be parsed to find key ID)

        Returns:
            RSA public key for signature verification

        Raises:
            AuthError: If key not found or invalid
        """
        # Parse token header to get kid
        try:
            unverified_header = jwt.get_unverified_header(token)
            kid = unverified_header.get("kid")
            if not kid:
                raise AuthError(message="Token header missing 'kid' (key ID)")
        except Exception as e:
            raise AuthError(message=f"Failed to parse token header: {e!s}") from e

        # Get JWKS
        jwks_data = await self._get_jwks()

        # Find key by kid
        key_data = None
        for key in jwks_data.get("keys", []):
            if key.get("kid") == kid:
                key_data = key
                break

        if not key_data:
            raise AuthError(message=f"Key with kid '{kid}' not found in JWKS")

        # Convert JWK to RSA public key
        try:
            jwk_key = jwk.construct(key_data)
            return jwk_key.public_key()
        except Exception as e:
            raise AuthError(message=f"Failed to construct public key: {e!s}") from e

    async def close(self) -> None:
        """Close HTTP client."""
        await self._client.aclose()


# Global cache instance (initialized per request via dependency)
_jwks_cache: JWKSCache | None = None


def get_jwks_cache(settings: Settings) -> JWKSCache:
    """Get or create JWKS cache instance."""
    global _jwks_cache  # noqa: PLW0603
    if _jwks_cache is None:
        _jwks_cache = JWKSCache(settings)
    return _jwks_cache

