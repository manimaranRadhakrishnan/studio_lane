"""Error tracking and fingerprinting for error aggregation."""

import hashlib
import traceback
from typing import Any

from opentelemetry import trace

from shared.errors import AppError
from shared.observability import get_logger


class ErrorTracker:
    """Track and fingerprint errors for aggregation and reporting."""

    def __init__(self):
        """Initialize error tracker."""
        self.logger = get_logger("error.tracker")
        self.error_counts: dict[str, int] = {}

    def track_error(
        self,
        error: Exception,
        context: dict[str, Any] | None = None,
    ) -> str:
        """
        Track an error and generate fingerprint.

        Args:
            error: Exception that occurred
            context: Additional context (request details, user actions, etc.)

        Returns:
            Error fingerprint (hash) for grouping similar errors
        """
        # Generate fingerprint from error type and message
        fingerprint = self._generate_fingerprint(error)

        # Increment count
        self.error_counts[fingerprint] = self.error_counts.get(fingerprint, 0) + 1

        # Get current span for error reporting
        current_span = trace.get_current_span()
        if current_span:
            current_span.record_exception(error)
            current_span.set_status(
                trace.Status(trace.StatusCode.ERROR, str(error))
            )
            current_span.set_attribute("error.fingerprint", fingerprint)
            current_span.set_attribute("error.type", type(error).__name__)
            if isinstance(error, AppError):
                current_span.set_attribute("error.code", error.error_code)

        # Log error with context
        error_context = {
            "fingerprint": fingerprint,
            "error_type": type(error).__name__,
            "error_message": str(error),
            "count": self.error_counts[fingerprint],
        }

        if isinstance(error, AppError):
            error_context["error_code"] = error.error_code
            error_context["status_code"] = error.status_code
            error_context["details"] = error.details

        if context:
            error_context["context"] = context

        # Add stack trace for non-AppError exceptions
        if not isinstance(error, AppError):
            error_context["traceback"] = traceback.format_exc()

        self.logger.error(
            f"Error tracked: {type(error).__name__}",
            **error_context,
        )

        return fingerprint

    def _generate_fingerprint(self, error: Exception) -> str:
        """
        Generate error fingerprint for grouping similar errors.

        Uses error type and message to create a hash.
        """
        # Normalize error message (remove IDs, timestamps, etc.)
        message = str(error)

        # Remove common variable parts
        import re
        message = re.sub(r'\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b', '{uuid}', message, flags=re.IGNORECASE)
        message = re.sub(r'\b\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2}', '{timestamp}', message)
        message = re.sub(r'/\d+', '/{id}', message)

        # Create fingerprint
        fingerprint_data = f"{type(error).__name__}:{message}"
        if isinstance(error, AppError):
            fingerprint_data += f":{error.error_code}"

        return hashlib.md5(fingerprint_data.encode()).hexdigest()[:16]

    def get_error_stats(self) -> dict[str, Any]:
        """
        Get error statistics.

        Returns:
            Dictionary with error counts and frequencies
        """
        total_errors = sum(self.error_counts.values())

        return {
            "total_errors": total_errors,
            "unique_errors": len(self.error_counts),
            "error_counts": dict(
                sorted(
                    self.error_counts.items(),
                    key=lambda x: x[1],
                    reverse=True,
                )[:10]  # Top 10
            ),
        }

    def get_recovery_suggestion(self, error: Exception) -> str | None:
        """
        Get recovery suggestion for an error.

        Args:
            error: Exception that occurred

        Returns:
            Recovery suggestion or None
        """
        if isinstance(error, AppError):
            error_code = error.error_code

            suggestions = {
                "AUTH_ERROR": "Check JWT token validity and expiration",
                "PERMISSION_DENIED": "Verify user has required roles",
                "NOT_FOUND": "Verify resource ID exists and user has access",
                "VALIDATION_ERROR": "Check request payload matches API schema",
                "DOWNSTREAM_ERROR": "Check downstream service availability and logs",
            }

            return suggestions.get(error_code)

        return None


# Global error tracker instance
_error_tracker: ErrorTracker | None = None


def get_error_tracker() -> ErrorTracker:
    """Get or create global error tracker."""
    global _error_tracker  # noqa: PLW0603
    if _error_tracker is None:
        _error_tracker = ErrorTracker()
    return _error_tracker

