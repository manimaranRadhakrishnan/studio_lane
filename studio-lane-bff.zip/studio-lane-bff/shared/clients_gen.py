"""Gen Lane HTTP client for generative AI operations."""

from typing import Any

import httpx

from shared.config import Settings
from shared.context import RequestContext
from shared.errors import DownstreamError
from shared.http_utils import HttpClientContextManager
from shared.observability import LatencyTracker


class GenClient:
    """
    HTTP client for Gen Lane Public APIs.

    Handles prompt-to-code, inline edits, chat, and UI builder operations.
    Never calls LLMs directly - delegates to Gen Lane services.

    Can be used as async context manager:
        async with GenClient(settings) as client:
            result = await client.prompt_to_code(...)

    Or manually managed:
        client = GenClient(settings)
        try:
            result = await client.prompt_to_code(...)
        finally:
            await client.close()
    """

    def __init__(self, settings: Settings):
        self.base_url = settings.gen_base_url
        self.timeout = settings.http_timeout
        self.max_retries = settings.http_max_retries
        self.settings = settings
        self.client: httpx.AsyncClient | None = None
        self._context_manager: HttpClientContextManager | None = None

    async def __aenter__(self) -> "GenClient":
        """Enter async context manager."""
        self._context_manager = HttpClientContextManager(
            base_url=self.base_url,
            timeout=self.timeout,
            max_retries=self.max_retries,
        )
        self.client = await self._context_manager.__aenter__()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        """Exit async context manager."""
        if self._context_manager:
            await self._context_manager.__aexit__(exc_type, exc_val, exc_tb)
            self.client = None
            self._context_manager = None

    def _ensure_client(self) -> httpx.AsyncClient:
        """Ensure client is initialized."""
        if self.client is None:
            # Fallback to manual initialization for backward compatibility
            self.client = httpx.AsyncClient(
                base_url=self.base_url,
                timeout=httpx.Timeout(self.timeout),
            )
        return self.client

    async def close(self) -> None:
        """Close HTTP client (for manual management)."""
        if self.client:
            await self.client.aclose()
            self.client = None

    async def prompt_to_code(
        self,
        ctx: RequestContext,
        prompt: str,
        project_id: str,
        session_id: str,
    ) -> dict[str, Any]:
        """
        Generate code from natural language prompt.

        Calls Gen Public API for prompt-to-code generation.
        """
        client = self._ensure_client()
        with LatencyTracker("gen", "prompt_to_code"):
            try:
                # Contract-first: start a GenAI run (async)
                payload = {
                    "tenantId": ctx.tenant_id,
                    "projectId": project_id,
                    "sessionId": session_id,
                    "intent": "prompt_to_code",
                    "input": {"promptText": prompt, "selectedContexts": [], "hints": {}},
                    "wcRef": {"wcVersionStamp": "unknown", "branch": "main", "blobBaseUri": None},
                    "locks": {},
                    "authContext": {"userId": ctx.user_id, "roles": list(ctx.roles), "locale": None, "region": None},
                }
                response = await client.post(
                    "/v1/gen/runs",
                    json=payload,
                    headers={"X-Correlation-Id": ctx.correlation_id or "", "X-CS-Tenant-Id": ctx.tenant_id},
                )
                response.raise_for_status()
                return response.json()
            except httpx.HTTPStatusError as e:
                raise DownstreamError(
                    service="gen",
                    message=f"Gen API error: {e.response.text}",
                    status_code=e.response.status_code,
                ) from e
            except httpx.RequestError as e:
                raise DownstreamError(
                    service="gen",
                    message=f"Failed to connect to Gen API: {e!s}",
                ) from e

    async def plan(self, ctx: RequestContext, payload: dict[str, Any]) -> dict[str, Any]:
        client = self._ensure_client()
        with LatencyTracker("gen", "plan"):
            response = await client.post(
                "/plan",
                json=payload,
                headers={"X-Correlation-Id": ctx.correlation_id or "", "X-CS-Tenant-Id": ctx.tenant_id},
            )
            response.raise_for_status()
            return response.json()

    async def start_run(self, ctx: RequestContext, payload: dict[str, Any]) -> dict[str, Any]:
        client = self._ensure_client()
        with LatencyTracker("gen", "start_run"):
            response = await client.post(
                "/v1/gen/runs",
                json=payload,
                headers={"X-Correlation-Id": ctx.correlation_id or "", "X-CS-Tenant-Id": ctx.tenant_id},
            )
            response.raise_for_status()
            return response.json()

    async def get_run(self, ctx: RequestContext, gen_run_id: str, tenant_id: str) -> dict[str, Any]:
        client = self._ensure_client()
        with LatencyTracker("gen", "get_run"):
            response = await client.get(
                f"/v1/gen/runs/{gen_run_id}",
                params={"tenantId": tenant_id},
                headers={"X-Correlation-Id": ctx.correlation_id or "", "X-CS-Tenant-Id": ctx.tenant_id},
            )
            response.raise_for_status()
            return response.json()

    async def get_tasks(self, ctx: RequestContext, gen_run_id: str, tenant_id: str) -> dict[str, Any]:
        client = self._ensure_client()
        with LatencyTracker("gen", "get_tasks"):
            response = await client.get(
                f"/v1/gen/runs/{gen_run_id}/tasks",
                params={"tenantId": tenant_id},
                headers={"X-Correlation-Id": ctx.correlation_id or "", "X-CS-Tenant-Id": ctx.tenant_id},
            )
            response.raise_for_status()
            return response.json()

    async def get_patches(self, ctx: RequestContext, gen_run_id: str, tenant_id: str) -> dict[str, Any]:
        client = self._ensure_client()
        with LatencyTracker("gen", "get_patches"):
            response = await client.get(
                f"/v1/gen/runs/{gen_run_id}/patches",
                params={"tenantId": tenant_id},
                headers={"X-Correlation-Id": ctx.correlation_id or "", "X-CS-Tenant-Id": ctx.tenant_id},
            )
            response.raise_for_status()
            return response.json()

    async def cancel_run(self, ctx: RequestContext, gen_run_id: str, tenant_id: str) -> dict[str, Any]:
        client = self._ensure_client()
        with LatencyTracker("gen", "cancel_run"):
            response = await client.post(
                f"/v1/gen/runs/{gen_run_id}:cancel",
                params={"tenantId": tenant_id},
                headers={"X-Correlation-Id": ctx.correlation_id or "", "X-CS-Tenant-Id": ctx.tenant_id},
            )
            response.raise_for_status()
            return response.json()

    async def inline_edit(
        self,
        _ctx: RequestContext,
        _file_path: str,
        _edit_instruction: str,
        project_id: str,
    ) -> dict[str, Any]:
        """
        Apply inline edit to existing code.

        TODO: Implement actual API call to Gen Lane.
        """
        with LatencyTracker("gen", "inline_edit"):
            # STUB: Return mock response
            return {
                "task_id": f"task-edit-{project_id}",
                "status": "processing",
                "message": "Inline edit started",
            }

    async def chat(
        self,
        _ctx: RequestContext,
        _message: str,
        session_id: str,
        _project_id: str,
    ) -> dict[str, Any]:
        """
        Context-aware chat about project.

        TODO: Implement actual API call to Gen Lane.
        """
        with LatencyTracker("gen", "chat"):
            # STUB: Return mock response
            return {
                "message_id": f"msg-{session_id}",
                "response": "This is a stub response from Gen Lane chat API",
                "status": "completed",
            }

    async def ui_builder(
        self,
        _ctx: RequestContext,
        _ui_prompt: str,
        project_id: str,
        _design_system_id: str | None = None,
    ) -> dict[str, Any]:
        """
        Generate UI components from prompt.

        TODO: Implement actual API call to Gen Lane.
        """
        with LatencyTracker("gen", "ui_builder"):
            # STUB: Return mock response
            return {
                "task_id": f"task-ui-{project_id}",
                "status": "processing",
                "message": "UI generation started",
            }


async def get_gen_client(settings: Settings) -> GenClient:
    """Dependency to get Gen client."""
    return GenClient(settings)

