"""Configuration management using Pydantic Settings."""

from functools import lru_cache

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Application settings loaded from environment variables and Azure services."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # Environment
    studio_env: str = Field(default="dev", alias="STUDIO_ENV")

    # Downstream service URLs
    gen_base_url: str = Field(
        default="http://gen-lane-api:8080",
        alias="GEN_BASE_URL",
    )
    delivery_base_url: str = Field(
        default="http://delivery-api:8080",
        alias="DELIVERY_BASE_URL",
    )
    fabric_base_url: str = Field(
        default="http://fabric-api:8080",
        alias="FABRIC_BASE_URL",
    )
    audit_base_url: str = Field(
        default="http://audit-api:8080",
        alias="AUDIT_BASE_URL",
    )

    # HTTP client settings
    http_timeout: int = Field(default=30, alias="HTTP_TIMEOUT")
    http_max_retries: int = Field(default=3, alias="HTTP_MAX_RETRIES")

    # Azure AD / Temenos SSO settings
    sso_authority: str = Field(
        default="https://login.microsoftonline.com/common",
        alias="SSO_AUTHORITY",
    )
    sso_audience: str = Field(
        default="api://studio-lane-bff",
        alias="SSO_AUDIENCE",
    )
    sso_jwks_url: str | None = Field(
        default=None,
        alias="SSO_JWKS_URL",
    )

    # Cosmos DB settings
    cosmos_connection_string: str = Field(
        default="",
        alias="COSMOS_CONNECTION_STRING",
    )
    cosmos_database_name: str = Field(
        default="studio_lane",
        alias="COSMOS_DATABASE_NAME",
    )
    cosmos_partition_key_path: str = Field(
        default="/partitionKey",
        alias="COSMOS_PARTITION_KEY_PATH",
    )
    cosmos_max_retry_attempts: int = Field(
        default=3,
        alias="COSMOS_MAX_RETRY_ATTEMPTS",
    )
    cosmos_request_timeout: int = Field(
        default=30,
        alias="COSMOS_REQUEST_TIMEOUT",
    )
    azure_ad_client_id: str = Field(
        default="",
        alias="AZURE_AD_CLIENT_ID",
    )

    # Azure infrastructure (optional)
    azure_app_config_endpoint: str | None = Field(
        default=None,
        alias="AZURE_APP_CONFIG_ENDPOINT",
    )
    azure_key_vault_url: str | None = Field(
        default=None,
        alias="AZURE_KEY_VAULT_URL",
    )

    # Observability
    otel_exporter_otlp_endpoint: str | None = Field(
        default=None,
        alias="OTEL_EXPORTER_OTLP_ENDPOINT",
    )
    log_level: str = Field(default="INFO", alias="LOG_LEVEL")

    # Security
    cors_origins: str = Field(
        default="http://localhost:3000,http://localhost:3001",
        alias="CORS_ORIGINS",
    )

    @property
    def cors_origins_list(self) -> list[str]:
        """Parse CORS origins into a list."""
        return [origin.strip() for origin in self.cors_origins.split(",")]

    @property
    def cosmos_container_config(self) -> dict[str, str]:
        """Get Cosmos DB container configuration mapping entity types to container names."""
        return {
            "user_profile": "users",
            "user_role_assignment": "users",
            "workspace": "workspaces",
            "folder": "workspaces",
            "project": "projects",
            "favorite": "projects",
            "project_share": "projects",
            "design_system": "design_systems",
            "theme": "themes",
            "context_item": "contexts",
            "project_context_selection": "projects",
            "studio_session": "sessions",
            "chat_session": "conversations",
            "chat_message": "conversations",
            "task": "tasks",
            "file": "files",
            "working_copy_metadata": "wcMetadata",
            "job_projection": "jobProjections",
            "lifecycle_timeline": "lifecycleTimelines",
        }
        


@lru_cache
def get_settings() -> Settings:
    """Get cached settings instance."""
    return Settings()

