"""Azure Cosmos DB client with multi-container support and async operations."""

from typing import Any

from azure.cosmos import PartitionKey, exceptions
from azure.cosmos.aio import ContainerProxy, CosmosClient, DatabaseProxy

from shared.observability import get_logger
from dotenv import load_dotenv
from shared.config import get_settings
load_dotenv()


logger = get_logger(__name__)


class CosmosDBClient:
    """Azure Cosmos DB client for async operations with multi-container support."""

    def __init__(
        self,
        connection_string: str,
        database_name: str,
        container_config: dict[str, str],
        partition_key_path: str = "/partitionKey",
        max_retry_attempts: int = 3,
        request_timeout: int = 30,
    ):
        """
        Initialize Cosmos DB client with multiple containers.

        Args:
            connection_string: Cosmos DB connection string
            database_name: Database name
            container_config: Dictionary mapping entity types to container names
                Example: {"workspace": "workspaces", "user": "users"}
            partition_key_path: Partition key path (default: /partitionKey)
            max_retry_attempts: Maximum retry attempts for transient failures
            request_timeout: Request timeout in seconds
        """
        connection_string=CosmosClient(os.getenv("COSMOS_ENDPOINT"),os.getenv("COSMOS_KEY"))
        database_name=connection_string.get_database_client(os.getenv("COSMOS_DATABASE"))
        container_config=database_name.get_container_client(os.getenv("COSMOS_CONTAINER"))

        self.connection_string = connection_string
        self.database_name = database_name
        self.container_config = container_config
        self.partition_key_path = partition_key_path
        self.max_retry_attempts = max_retry_attempts
        self.request_timeout = request_timeout

        self._client: CosmosClient | None = None
        self._database: DatabaseProxy | None = None
        self._containers: dict[str, ContainerProxy] = {}

    async def __aenter__(self):
        """Async context manager entry."""
        await self.connect()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        await self.close()

    async def connect(self) -> None:
        """Initialize Cosmos DB connection and all containers."""
        if self._client is None:
            logger.info(
                "Connecting to Cosmos DB",
                extra={
                    "database": self.database_name,
                    "containers": list(self.container_config.values()),
                },
            )

            self._client = CosmosClient.from_connection_string(
                self.connection_string,
                connection_timeout=self.request_timeout,
            )

            # Get or create database
            self._database = self._client.get_database_client(self.database_name)

            # Initialize all containers
            for _entity_type, container_name in self.container_config.items():
                try:
                    container = self._database.get_container_client(container_name)
                    # Verify container exists
                    await container.read()
                    self._containers[container_name] = container
                    logger.debug(f"Connected to existing container: {container_name}")
                except exceptions.CosmosResourceNotFoundError:
                    logger.info(f"Container not found, creating: {container_name}")
                    container = await self._database.create_container(
                        id=container_name,
                        partition_key=PartitionKey(path=self.partition_key_path),
                    )
                    self._containers[container_name] = container
                    logger.info(f"Created new container: {container_name}")

            logger.info("Connected to all Cosmos DB containers")

    async def close(self) -> None:
        """Close Cosmos DB connection."""
        if self._client:
            logger.info("Closing Cosmos DB connection")
            await self._client.close()
            self._client = None
            self._database = None
            self._containers.clear()

    def get_container(self, container_name: str) -> ContainerProxy:
        """Get container by name."""
        if container_name not in self._containers:
            raise ValueError(f"Container {container_name} not initialized")
        return self._containers[container_name]

    async def create_item(
        self,
        item: dict[str, Any],
        container_name: str,
    ) -> dict[str, Any]:
        """
        Create a new item in the specified container.

        Args:
            item: Item to create (must include id and partitionKey)
            container_name: Name of the container

        Returns:
            Created item
        """
        container = self.get_container(container_name)

        try:
            logger.debug(
                "Creating Cosmos DB item",
                extra={"item_id": item.get("id"), "container": container_name},
            )

            created_item = await container.create_item(body=item)

            logger.info(
                "Created Cosmos DB item",
                extra={"item_id": created_item.get("id"), "container": container_name},
            )

            return created_item

        except exceptions.CosmosResourceExistsError:
            logger.error(
                "Item already exists",
                extra={"item_id": item.get("id"), "container": container_name},
            )
            raise
        except Exception as e:
            logger.error(
                "Failed to create item",
                extra={"item_id": item.get("id"), "container": container_name, "error": str(e)},
            )
            raise

    async def read_item(
        self,
        item_id: str,
        partition_key: str,
        container_name: str,
    ) -> dict[str, Any] | None:
        """
        Read an item from the specified container.

        Args:
            item_id: Item ID
            partition_key: Partition key value
            container_name: Name of the container

        Returns:
            Item data or None if not found
        """
        container = self.get_container(container_name)

        try:
            logger.debug(
                "Reading Cosmos DB item",
                extra={"item_id": item_id, "partition_key": partition_key, "container": container_name},
            )

            return await container.read_item(
                item=item_id,
                partition_key=partition_key,
            )


        except exceptions.CosmosResourceNotFoundError:
            logger.warning(
                "Item not found",
                extra={"item_id": item_id, "partition_key": partition_key, "container": container_name},
            )
            return None
        except Exception as e:
            logger.error(
                "Failed to read item",
                extra={"item_id": item_id, "container": container_name, "error": str(e)},
            )
            raise

    async def query_items(
        self,
        query: str,
        container_name: str,
        parameters: list[dict[str, Any]] | None = None,
        partition_key: str | None = None,
        max_item_count: int | None = None,
    ) -> list[dict[str, Any]]:
        """
        Query items from the specified container.

        Args:
            query: SQL query string
            container_name: Name of the container
            parameters: Query parameters
            partition_key: Optional partition key for cross-partition queries
            max_item_count: Maximum number of items to return

        Returns:
            List of items
        """
        container = self.get_container(container_name)

        try:
            logger.debug(
                "Querying Cosmos DB",
                extra={"query": query, "partition_key": partition_key, "container": container_name},
            )

            query_iterable = container.query_items(
                query=query,
                parameters=parameters,
                partition_key=partition_key,
                max_item_count=max_item_count,
            )

            items = []
            async for item in query_iterable:
                items.append(item)

            logger.info(
                "Query completed",
                extra={"item_count": len(items), "container": container_name},
            )

            return items

        except Exception as e:
            logger.error(
                "Failed to query items",
                extra={"query": query, "container": container_name, "error": str(e)},
            )
            raise

    async def upsert_item(
        self,
        item: dict[str, Any],
        container_name: str,
    ) -> dict[str, Any]:
        """
        Create or update an item in the specified container.

        Args:
            item: Item to upsert (must include id and partitionKey)
            container_name: Name of the container

        Returns:
            Upserted item
        """
        container = self.get_container(container_name)

        try:
            logger.debug(
                "Upserting Cosmos DB item",
                extra={"item_id": item.get("id"), "container": container_name},
            )

            upserted_item = await container.upsert_item(body=item)

            logger.info(
                "Upserted Cosmos DB item",
                extra={"item_id": upserted_item.get("id"), "container": container_name},
            )

            return upserted_item

        except Exception as e:
            logger.error(
                "Failed to upsert item",
                extra={"item_id": item.get("id"), "container": container_name, "error": str(e)},
            )
            raise

    async def delete_item(
        self,
        item_id: str,
        partition_key: str,
        container_name: str,
    ) -> None:
        """
        Delete an item from the specified container.

        Args:
            item_id: Item ID
            partition_key: Partition key value
            container_name: Name of the container
        """
        container = self.get_container(container_name)

        try:
            logger.debug(
                "Deleting Cosmos DB item",
                extra={"item_id": item_id, "partition_key": partition_key, "container": container_name},
            )

            await container.delete_item(
                item=item_id,
                partition_key=partition_key,
            )

            logger.info(
                "Deleted Cosmos DB item",
                extra={"item_id": item_id, "container": container_name},
            )

        except exceptions.CosmosResourceNotFoundError:
            logger.warning(
                "Item not found for deletion",
                extra={"item_id": item_id, "partition_key": partition_key, "container": container_name},
            )
        except Exception as e:
            logger.error(
                "Failed to delete item",
                extra={"item_id": item_id, "container": container_name, "error": str(e)},
            )
            raise

    async def health_check(self) -> bool:
        """
        Check Cosmos DB health by verifying all containers are accessible.

        Returns:
            True if healthy, False otherwise
        """
        try:
            if not self._containers:
                await self.connect()

            # Try to read each container's properties
            for _container_name, container in self._containers.items():
                await container.read()

            logger.debug("Cosmos DB health check passed")
            return True

        except Exception as e:
            logger.error(
                "Cosmos DB health check failed",
                extra={"error": str(e)},
            )
            return False


# Global Cosmos DB client
_cosmos_client: CosmosDBClient | None = None


def init_cosmosdb(
    connection_string: str,
    database_name: str,
    container_config: dict[str, str],
    partition_key_path: str = "/partitionKey",
) -> CosmosDBClient:
    """Initialize global Cosmos DB client."""
    global _cosmos_client  # noqa: PLW0603
    if _cosmos_client is None:
        _cosmos_client = CosmosDBClient(
            connection_string=connection_string,
            database_name=database_name,
            container_config=container_config,
            partition_key_path=partition_key_path,
        )
        logger.info("Cosmos DB client initialized")
    return _cosmos_client


def get_cosmosdb_client() -> CosmosDBClient:
    """Get global Cosmos DB client."""
    if _cosmos_client is None:
        raise RuntimeError("Cosmos DB not initialized. Call init_cosmosdb() first.")
    return _cosmos_client


async def get_cosmosdb() -> CosmosDBClient:
    """
    FastAPI dependency for Cosmos DB client.

    Usage:
        @router.get("/items")
        async def list_items(cosmos: CosmosDBClient = Depends(get_cosmosdb)):
            ...
    """
    return get_cosmosdb_client()


# @lru_cache
# def get_secret_client(vault_url: str) -> SecretClient:
#     """
#     Cached SecretClient per vault URL.
#     """
#     credential = DefaultAzureCredential()
#     return SecretClient(vault_url=vault_url, credential=credential)


# def get_secret(vault_url: str, secret_name: str) -> str:
#     """
#     Read a secret value from Azure Key Vault.
#     """
#     client = get_secret_client(vault_url)
#     secret = client.get_secret(secret_name)
#     return secret.value    


def resolve_cosmos_url(dbname: str, db_key: str) -> str:
    """
    Example: tenant123 + dev -> https://kv-tenant123-dev.vault.azure.net/
    """
    return f"AccountEndpoint=https://{dbname}.documents.azure.com:443/;AccountKey={db_key};"    
