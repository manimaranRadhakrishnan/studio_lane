# API Definition of Done

This document defines the quality standards that must be met before an API endpoint is considered complete and ready for production.

## Checklist

### Code Quality

- [ ] Endpoint implemented with full type hints
- [ ] RBAC enforced via `require_role()` dependency
- [ ] Request/response Pydantic models defined
- [ ] Tenant isolation verified in code (all queries filtered by `tenant_id`)
- [ ] Business logic in domain/application layers (not router)
- [ ] No hardcoded values or magic numbers
- [ ] Proper error handling with appropriate error types

### Testing

- [ ] Unit tests for domain logic (>90% coverage)
- [ ] Integration test (DB + endpoint)
- [ ] RBAC test (unauthorized returns 403)
- [ ] Multi-tenant test (no data leakage between tenants)
- [ ] Error cases tested (400, 404, 500)
- [ ] Edge cases tested (empty lists, null values, etc.)

### Documentation

- [ ] OpenAPI schema auto-generated (via FastAPI)
- [ ] Example request/response in docstring
- [ ] Error codes documented in `shared/error_codes.py`
- [ ] Business rules documented in domain service
- [ ] README updated if new service/endpoint

### Observability

- [ ] Metrics emitted (via middleware, automatic)
- [ ] Trace span created (via middleware, automatic)
- [ ] Error scenarios logged with context
- [ ] Slow queries detected (>100ms threshold)
- [ ] Correlation ID propagated

### Security

- [ ] Input validation (Pydantic + custom rules)
- [ ] SQL injection protected (SQLAlchemy ORM)
- [ ] PII sanitized in logs
- [ ] Rate limiting configured (via middleware)
- [ ] No secrets in code/logs
- [ ] JWT validation working (if authenticated endpoint)

### Performance

- [ ] Database queries optimized (no N+1 queries)
- [ ] Pagination implemented for list endpoints
- [ ] Response size reasonable (<1MB for typical responses)
- [ ] No blocking operations in request path

## Examples

### Good Endpoint Implementation

```python
@router.post("/workspaces", response_model=Workspace, status_code=201)
async def create_workspace(
    request: CreateWorkspaceRequest,
    ctx: RequestContext = Depends(require_role("Owner", "Editor")),
    use_case: CreateWorkspaceUseCase = Depends(),
) -> Workspace:
    """
    Create a new workspace.
    
    Example request:
        {
            "name": "My Workspace",
            "description": "A new workspace"
        }
    
    Example response:
        {
            "id": "workspace-123",
            "name": "My Workspace",
            "tenant_id": "tenant-001",
            ...
        }
    
    Errors:
        - 400: Validation error (invalid request)
        - 403: Permission denied (insufficient roles)
        - 500: Internal server error
    """
    dto = CreateWorkspaceDTO.from_request(request)
    workspace = await use_case.execute(dto, ctx)
    return WorkspaceResponse.from_entity(workspace)
```

### Good Test Coverage

```python
async def test_create_workspace_success(db, ctx):
    """Test successful workspace creation."""
    # Test implementation
    
async def test_create_workspace_unauthorized(db, ctx):
    """Test unauthorized access returns 403."""
    # Test implementation
    
async def test_create_workspace_tenant_isolation(db, ctx1, ctx2):
    """Test tenant isolation - user can't see other tenant's workspaces."""
    # Test implementation
```

## Review Process

1. **Self-review**: Developer checks all items before creating PR
2. **Peer review**: Another developer reviews code and tests
3. **Automated checks**: CI/CD runs lint, type-check, tests
4. **Final approval**: Tech lead/architect approves

## Enforcement

- PR template includes DoD checklist
- CI/CD fails if tests don't pass
- Code review blocks merge if DoD not met
- Automated DoD verification script (future)

