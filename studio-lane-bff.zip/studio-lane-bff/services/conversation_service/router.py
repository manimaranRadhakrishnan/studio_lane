"""Conversation service router."""

import uuid
from datetime import datetime
from typing import Any

from fastapi import APIRouter, Depends

from services.conversation_service.models import (
    ChatRequest,
    CreateSessionRequest,
    PromptToCodeRequest,
)
from shared import (
    NotFoundError,
    RequestContext,
    get_cosmosdb,
    get_request_context,
    get_settings,
    require_role,
)
from shared.clients_gen import GenClient
from shared.config import Settings
from shared.cosmosdb import CosmosDBClient
from shared.models import ChatMessage, ChatSession, Task
from shared.repository import BaseRepository


router = APIRouter()


def get_chat_session_repo(
    cosmos: CosmosDBClient = Depends(get_cosmosdb),
    ctx: RequestContext = Depends(get_request_context),
) -> BaseRepository[ChatSession]:
    """Get chat session repository."""
    return BaseRepository(cosmos, ctx, ChatSession, "chat_session")


def get_chat_message_repo(
    cosmos: CosmosDBClient = Depends(get_cosmosdb),
    ctx: RequestContext = Depends(get_request_context),
) -> BaseRepository[ChatMessage]:
    """Get chat message repository."""
    return BaseRepository(cosmos, ctx, ChatMessage, "chat_message")


def get_task_repo(
    cosmos: CosmosDBClient = Depends(get_cosmosdb),
    ctx: RequestContext = Depends(get_request_context),
) -> BaseRepository[Task]:
    """Get task repository."""
    return BaseRepository(cosmos, ctx, Task, "task")


@router.post("/sessions", response_model=ChatSession, status_code=201)
async def create_session(
    request: CreateSessionRequest,
    ctx: RequestContext = Depends(require_role("Owner", "Editor")),
    repo: BaseRepository[ChatSession] = Depends(get_chat_session_repo),
):
    """Create a new chat session."""
    session = ChatSession(
        id=str(uuid.uuid4()),
        project_id=request.project_id,
        workspace_id=request.workspace_id,
        user_id=ctx.user_id,
        title=request.title or "New Chat",
        created_at=datetime.utcnow(),
        updated_at=datetime.utcnow(),
    )
    return await repo.create(session)


@router.get("/sessions", response_model=list[ChatSession])
async def list_sessions(
    ctx: RequestContext = Depends(get_request_context),
    repo: BaseRepository[ChatSession] = Depends(get_chat_session_repo),
):
    """List all chat sessions for current user."""
    return await repo.list(filters={"user_id": ctx.user_id})


@router.get("/sessions/{session_id}", response_model=ChatSession)
async def get_session(
    session_id: str,
    ctx: RequestContext = Depends(get_request_context),
    repo: BaseRepository[ChatSession] = Depends(get_chat_session_repo),
):
    """Get a chat session by ID."""
    session = await repo.get(session_id)
    if not session:
        raise NotFoundError(message="Session not found")

    # Verify session belongs to user
    if session.user_id != ctx.user_id:
        raise NotFoundError(message="Session not found")

    return session


@router.get("/sessions/{session_id}/messages", response_model=list[ChatMessage])
async def list_messages(
    session_id: str,
    ctx: RequestContext = Depends(get_request_context),
    session_repo: BaseRepository[ChatSession] = Depends(get_chat_session_repo),
    message_repo: BaseRepository[ChatMessage] = Depends(get_chat_message_repo),
):
    """List message metadata for a session (not full content)."""
    # Verify session exists and belongs to user
    session = await session_repo.get(session_id)
    if not session or session.user_id != ctx.user_id:
        raise NotFoundError(message="Session not found")

    # Get messages
    return await message_repo.list(filters={"session_id": session_id})


@router.get("/sessions/{session_id}/tasks", response_model=list[Task])
async def list_tasks(
    session_id: str,
    ctx: RequestContext = Depends(get_request_context),
    session_repo: BaseRepository[ChatSession] = Depends(get_chat_session_repo),
    task_repo: BaseRepository[Task] = Depends(get_task_repo),
):
    """
    List tasks for a session (read-only task planner).

    Returns task list with status, timestamps, and agent info.
    """
    # Verify session exists and belongs to user
    session = await session_repo.get(session_id)
    if not session or session.user_id != ctx.user_id:
        raise NotFoundError(message="Session not found")

    # Get tasks
    return await task_repo.list(filters={"session_id": session_id})


@router.post("/sessions/{session_id}/prompt-to-code")
async def prompt_to_code(
    session_id: str,
    request: PromptToCodeRequest,
    ctx: RequestContext = Depends(require_role("Owner", "Editor")),
    session_repo: BaseRepository[ChatSession] = Depends(get_chat_session_repo),
    settings: Settings = Depends(get_settings),
) -> dict[str, Any]:
    """
    Generate code from prompt.

    Delegates to Gen Public API - never calls LLMs directly.
    """
    # Verify session exists and belongs to user
    session = await session_repo.get(session_id)
    if not session or session.user_id != ctx.user_id:
        raise NotFoundError(message="Session not found")

    # Call Gen client
    gen_client = GenClient(settings)
    try:
        return await gen_client.prompt_to_code(
            ctx=ctx,
            prompt=request.prompt,
            project_id=request.project_id,
            session_id=session_id,
        )
    finally:
        await gen_client.close()


@router.post("/sessions/{session_id}/chat")
async def chat(
    session_id: str,
    request: ChatRequest,
    ctx: RequestContext = Depends(require_role("Owner", "Editor")),
    session_repo: BaseRepository[ChatSession] = Depends(get_chat_session_repo),
    settings: Settings = Depends(get_settings),
) -> dict[str, Any]:
    """
    Context-aware chat about project.

    Delegates to Gen Public API - never calls LLMs directly.
    """
    # Verify session exists and belongs to user
    session = await session_repo.get(session_id)
    if not session or session.user_id != ctx.user_id:
        raise NotFoundError(message="Session not found")

    # Call Gen client
    gen_client = GenClient(settings)
    try:
        return await gen_client.chat(
            ctx=ctx,
            message=request.message,
            session_id=session_id,
            project_id=request.project_id,
        )
    finally:
        await gen_client.close()
