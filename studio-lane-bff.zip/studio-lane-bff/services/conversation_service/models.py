"""Conversation service request/response models."""


from pydantic import BaseModel


class CreateSessionRequest(BaseModel):
    """Request to create a chat session."""

    project_id: str
    workspace_id: str
    title: str | None = "New Chat"


class PromptToCodeRequest(BaseModel):
    """Request for prompt-to-code generation."""

    prompt: str
    project_id: str


class ChatRequest(BaseModel):
    """Request for context-aware chat."""

    message: str
    project_id: str

