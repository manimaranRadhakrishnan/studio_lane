"""Design system service router."""

import uuid
from datetime import datetime

from fastapi import APIRouter, Depends

from services.designsystem_service.models import (
    CreateDesignSystemRequest,
    UpdateDesignSystemRequest,
)
from shared import (
    NotFoundError,
    RequestContext,
    get_cosmosdb,
    get_request_context,
    require_role,
)
from shared.cosmosdb import CosmosDBClient
from shared.models import DesignSystem
from shared.repository import BaseRepository


router = APIRouter()


def get_design_system_repo(
    cosmos: CosmosDBClient = Depends(get_cosmosdb),
    ctx: RequestContext = Depends(get_request_context),
) -> BaseRepository[DesignSystem]:
    """Get design system repository."""
    return BaseRepository(cosmos, ctx, DesignSystem, "design_system")


@router.get("/design-systems", response_model=list[DesignSystem])
async def list_design_systems(
    ctx: RequestContext = Depends(get_request_context),
    repo: BaseRepository[DesignSystem] = Depends(get_design_system_repo),
):
    """List all design systems for current tenant."""
    return await repo.list()


@router.post("/design-systems", response_model=DesignSystem, status_code=201)
async def create_design_system(
    request: CreateDesignSystemRequest,
    ctx: RequestContext = Depends(require_role("Owner", "Editor")),
    repo: BaseRepository[DesignSystem] = Depends(get_design_system_repo),
):
    """Create a new design system (Owner/Editor only)."""
    design_system = DesignSystem(
        id=str(uuid.uuid4()),
        name=request.name,
        version=request.version,
        description=request.description,
        project_id=request.project_id,
        tenant_id=ctx.tenant_id,
        created_by=ctx.user_id,
        config=request.config,
        created_at=datetime.utcnow(),
        updated_at=datetime.utcnow(),
    )
    return await repo.create(design_system)


@router.get("/design-systems/{design_system_id}", response_model=DesignSystem)
async def get_design_system(
    design_system_id: str,
    repo: BaseRepository[DesignSystem] = Depends(get_design_system_repo),
):
    """Get a design system by ID."""
    design_system = await repo.get(design_system_id)
    if not design_system:
        raise NotFoundError(message="Design system not found")
    return design_system


@router.patch("/design-systems/{design_system_id}", response_model=DesignSystem)
async def update_design_system(
    design_system_id: str,
    request: UpdateDesignSystemRequest,
    ctx: RequestContext = Depends(require_role("Owner")),
    repo: BaseRepository[DesignSystem] = Depends(get_design_system_repo),
):
    """Update a design system (Owner only)."""
    design_system = await repo.get(design_system_id)
    if not design_system:
        raise NotFoundError(message="Design system not found")

    update_data = {"updated_at": datetime.utcnow()}
    if request.name is not None:
        update_data["name"] = request.name
    if request.version is not None:
        update_data["version"] = request.version
    if request.description is not None:
        update_data["description"] = request.description
    if request.config is not None:
        update_data["config"] = request.config

    return await repo.update(design_system_id, **update_data)


@router.delete("/design-systems/{design_system_id}", status_code=204)
async def delete_design_system(
    design_system_id: str,
    ctx: RequestContext = Depends(require_role("Owner")),
    repo: BaseRepository[DesignSystem] = Depends(get_design_system_repo),
):
    """Delete a design system (Owner only)."""
    design_system = await repo.get(design_system_id)
    if not design_system:
        raise NotFoundError(message="Design system not found")

    await repo.delete(design_system_id)
