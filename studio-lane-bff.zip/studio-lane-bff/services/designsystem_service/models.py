"""Design system service request/response models."""


from pydantic import BaseModel


class CreateDesignSystemRequest(BaseModel):
    """Request to create a design system."""

    name: str
    version: str
    description: str | None = None
    project_id: str | None = None
    config: dict = {}


class UpdateDesignSystemRequest(BaseModel):
    """Request to update a design system."""

    name: str | None = None
    version: str | None = None
    description: str | None = None
    config: dict | None = None

