"""Gen proxy service models (Studio-facing)."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field


class PlanRequest(BaseModel):
    goal: str
    target: Literal["screen", "service", "flow", "unknown"] = "unknown"


class PlanResponse(BaseModel):
    plan_id: str
    steps: list[dict[str, Any]]


class GenStartRequest(BaseModel):
    tenantId: str
    projectId: str
    sessionId: str
    intent: Literal["prompt_to_code", "inline_refactor", "preview_fix", "api_bind", "image_to_code"]
    input: dict[str, Any]
    wcRef: dict[str, Any]
    locks: dict[str, Any] = Field(default_factory=dict)
    authContext: dict[str, Any]


