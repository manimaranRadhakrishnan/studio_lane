"""Gen proxy service router (BFF → GenAI Core)."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, HTTPException

from services.gen_proxy_service.models import GenStartRequest, PlanRequest
from services.job_projection_service.models import UpsertJobProjectionRequest
from services.job_projection_service.router import upsert_job_projection
from shared import NotFoundError, RequestContext, get_cosmosdb, get_request_context, get_settings, require_role
from shared.clients_gen import GenClient
from shared.config import Settings
from shared.cosmosdb import CosmosDBClient
from shared.models import GenRunStatus, JobProjection
from shared.repository import BaseRepository


router = APIRouter()


def get_job_repo(
    cosmos: CosmosDBClient = Depends(get_cosmosdb),
    ctx: RequestContext = Depends(get_request_context),
) -> BaseRepository[JobProjection]:
    """Get job projection repository."""
    return BaseRepository(cosmos, ctx, JobProjection, "job_projection")


@router.post("/plan")
async def plan(
    request: PlanRequest,
    ctx: RequestContext = Depends(require_role("Owner", "Editor")),
    settings: Settings = Depends(get_settings),
) -> dict[str, Any]:
    """Deterministic planner proxy (Studio Task Planner UX)."""
    gen_client = GenClient(settings)
    try:
        return await gen_client.plan(ctx=ctx, payload=request.model_dump())
    finally:
        await gen_client.close()


@router.post("/gen/runs")
async def start_run(
    request: GenStartRequest,
    ctx: RequestContext = Depends(require_role("Owner", "Editor")),
    settings: Settings = Depends(get_settings),
    job_repo: BaseRepository[JobProjection] = Depends(get_job_repo),
) -> dict[str, Any]:
    """
    Start a GenAI run and create job projection.

    Before starting:
    - Validates wcRef points to latest WC (ensures Git→WC sync completed)
    - Creates job projection in Cosmos with status=QUEUED
    - Calls GenAI /v1/gen/runs
    - Updates projection with genRunId from response
    """
    # TODO: Validate wcRef points to latest WC for project/branch (Git→WC sync requirement)
    # For now, proceed with the provided wcRef

    gen_client = GenClient(settings)
    try:
        # Call GenAI to start run
        gen_response = await gen_client.start_run(ctx=ctx, payload=request.model_dump())

        # Extract genRunId from response
        gen_run_id = gen_response.get("genRunId") or gen_response.get("id")
        if not gen_run_id:
            raise HTTPException(status_code=500, detail="GenAI did not return genRunId")

        # Create job projection in Cosmos
        from datetime import datetime

        projection = JobProjection(
            id=gen_run_id,
            tenant_id=ctx.tenant_id,
            project_id=request.projectId,
            gen_run_id=gen_run_id,
            session_id=request.sessionId,
            status=GenRunStatus.QUEUED,
            progress_percent=0,
            current_task_id=None,
            tasks_completed=0,
            tasks_total=0,
            patch_set_id=None,
            error_message=None,
            created_at=datetime.utcnow(),
            updated_at=datetime.utcnow(),
            completed_at=None,
        )
        await job_repo.create(projection)

        return gen_response
    finally:
        await gen_client.close()


@router.get("/gen/runs/{gen_run_id}")
async def get_run(
    gen_run_id: str,
    refresh: bool = False,
    ctx: RequestContext = Depends(require_role("Owner", "Editor")),
    settings: Settings = Depends(get_settings),
    job_repo: BaseRepository[JobProjection] = Depends(get_job_repo),
) -> dict[str, Any]:
    """
    Get GenAI run status.

    Serves from Cosmos job projection (fast), with optional refresh from GenAI.
    If refresh=true, fetches latest from GenAI and updates projection.
    """
    # Get projection from Cosmos (fast path)
    projection = await job_repo.get(gen_run_id)

    # If refresh requested or projection doesn't exist, fetch from GenAI
    if refresh or not projection:
        gen_client = GenClient(settings)
        try:
            gen_response = await gen_client.get_run(ctx=ctx, gen_run_id=gen_run_id, tenant_id=ctx.tenant_id)

            # Update or create projection
            from datetime import datetime

            if projection:
                # Update existing projection
                projection.status = GenRunStatus(gen_response.get("status", "queued"))
                projection.progress_percent = gen_response.get("progress", {}).get("percent", 0)
                projection.current_task_id = gen_response.get("progress", {}).get("currentTaskId")
                projection.tasks_completed = gen_response.get("progress", {}).get("tasksCompleted", 0)
                projection.tasks_total = gen_response.get("progress", {}).get("tasksTotal", 0)
                projection.patch_set_id = gen_response.get("outputs", {}).get("patchSetId")
                projection.error_message = gen_response.get("errors", {}).get("message") if gen_response.get("errors") else None

                if projection.status in (GenRunStatus.COMPLETED, GenRunStatus.FAILED, GenRunStatus.CANCELLED):
                    projection.completed_at = datetime.utcnow()

                projection.updated_at = datetime.utcnow()
                await job_repo.update(projection)
            else:
                # Create new projection (shouldn't happen normally)
                projection = JobProjection(
                    id=gen_run_id,
                    tenant_id=ctx.tenant_id,
                    project_id=gen_response.get("projectId", ""),
                    gen_run_id=gen_run_id,
                    session_id=gen_response.get("sessionId"),
                    status=GenRunStatus(gen_response.get("status", "queued")),
                    progress_percent=gen_response.get("progress", {}).get("percent", 0),
                    current_task_id=gen_response.get("progress", {}).get("currentTaskId"),
                    tasks_completed=gen_response.get("progress", {}).get("tasksCompleted", 0),
                    tasks_total=gen_response.get("progress", {}).get("tasksTotal", 0),
                    patch_set_id=gen_response.get("outputs", {}).get("patchSetId"),
                    error_message=gen_response.get("errors", {}).get("message") if gen_response.get("errors") else None,
                    created_at=datetime.utcnow(),
                    updated_at=datetime.utcnow(),
                    completed_at=datetime.utcnow()
                    if GenRunStatus(gen_response.get("status", "queued")) in (GenRunStatus.COMPLETED, GenRunStatus.FAILED, GenRunStatus.CANCELLED)
                    else None,
                )
                await job_repo.create(projection)

            return gen_response
        finally:
            await gen_client.close()
    else:
        # Return projection as GenAI response shape
        return {
            "genRunId": projection.gen_run_id,
            "status": projection.status.value,
            "progress": {
                "percent": projection.progress_percent,
                "currentTaskId": projection.current_task_id,
                "tasksCompleted": projection.tasks_completed,
                "tasksTotal": projection.tasks_total,
            },
            "outputs": {"patchSetId": projection.patch_set_id} if projection.patch_set_id else None,
            "errors": {"message": projection.error_message} if projection.error_message else None,
        }


@router.get("/gen/runs/{gen_run_id}/tasks")
async def get_tasks(
    gen_run_id: str,
    ctx: RequestContext = Depends(require_role("Owner", "Editor")),
    settings: Settings = Depends(get_settings),
) -> dict[str, Any]:
    """Get task graph for a GenAI run (always calls GenAI directly, not from projection)."""
    gen_client = GenClient(settings)
    try:
        return await gen_client.get_tasks(ctx=ctx, gen_run_id=gen_run_id, tenant_id=ctx.tenant_id)
    finally:
        await gen_client.close()


@router.get("/gen/runs/{gen_run_id}/patches")
async def get_patches(
    gen_run_id: str,
    ctx: RequestContext = Depends(require_role("Owner", "Editor")),
    settings: Settings = Depends(get_settings),
) -> dict[str, Any]:
    """Get patch set for a GenAI run (always calls GenAI directly, not from projection)."""
    gen_client = GenClient(settings)
    try:
        return await gen_client.get_patches(ctx=ctx, gen_run_id=gen_run_id, tenant_id=ctx.tenant_id)
    finally:
        await gen_client.close()


@router.post("/gen/runs/{gen_run_id}:cancel")
async def cancel_run(
    gen_run_id: str,
    ctx: RequestContext = Depends(require_role("Owner", "Editor")),
    settings: Settings = Depends(get_settings),
    job_repo: BaseRepository[JobProjection] = Depends(get_job_repo),
) -> dict[str, Any]:
    """Cancel a GenAI run and update projection."""
    gen_client = GenClient(settings)
    try:
        gen_response = await gen_client.cancel_run(ctx=ctx, gen_run_id=gen_run_id, tenant_id=ctx.tenant_id)

        # Update projection
        projection = await job_repo.get(gen_run_id)
        if projection:
            from datetime import datetime

            projection.status = GenRunStatus.CANCELLED
            projection.completed_at = datetime.utcnow()
            projection.updated_at = datetime.utcnow()
            await job_repo.update(projection)

        return gen_response
    finally:
        await gen_client.close()


