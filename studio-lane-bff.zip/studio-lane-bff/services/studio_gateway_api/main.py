"""Studio Gateway API - Main entry point for Studio Web/Admin."""

import uuid

from fastapi import FastAPI, Request,Depends,HTTPException
from fastapi.middleware.cors import CORSMiddleware
from starlette.middleware.base import BaseHTTPMiddleware

from services.audit_proxy_service.router import router as audit_router

# Import all service routers
from services.auth_rbac_service.router import router as auth_router
from services.build_proxy_service.router import router as build_router
from services.conversation_service.router import router as conversation_router
from services.context_catalog_service.router import router as context_catalog_router
from services.designsystem_service.router import router as designsystem_router
from services.fabric_proxy_service.router import router as fabric_router
from services.gen_proxy_service.router import router as gen_router
from services.internal_truth_service.router import router as internal_truth_router
from services.job_projection_service.router import router as job_projection_router
from services.lifecycle_timeline_service.router import router as lifecycle_timeline_router
from services.preview_proxy_service.router import router as preview_router
from services.release_proxy_service.router import router as release_router
from services.session_service.router import router as session_router
from services.theme_service.router import router as theme_router
from services.working_copy_service.router import router as working_copy_router
from services.workspace_service.router import router as workspace_router
from shared import global_exception_handler
from shared.config import get_settings
from shared.cosmosdb import get_cosmosdb_client, init_cosmosdb
from shared.errors import AppError
from shared.health import get_health_checker
from shared.middleware import (
    AuthMiddleware,
    LoggingMiddleware,
    MetricsMiddleware,
    RateLimitMiddleware,
    TracingMiddleware,
    ValidationMiddleware,
)
from shared.middleware.response_envelope_middleware import ResponseEnvelopeMiddleware
from shared.observability import get_logger, setup_logging, setup_tracing


from pydantic import BaseModel, Field
from typing import List,Optional
import uuid
from datetime import datetime


app=FastAPI()

logger = get_logger(__name__)


class CorrelationIDMiddleware(BaseHTTPMiddleware):
    """Middleware to add correlation ID to requests."""

    async def dispatch(self, request: Request, call_next):
        """Add X-Correlation-ID header if not present."""
        correlation_id = request.headers.get("X-Correlation-ID")
        if not correlation_id:
            correlation_id = str(uuid.uuid4())
            request.state.correlation_id = correlation_id

        response = await call_next(request)
        response.headers["X-Correlation-ID"] = correlation_id
        return response


class RequestIDMiddleware(BaseHTTPMiddleware):
    """Middleware to add request ID to requests."""

    async def dispatch(self, request: Request, call_next):
        request_id = request.headers.get("X-Request-Id")
        if not request_id:
            request_id = str(uuid.uuid4())
            request.state.request_id = request_id

        response = await call_next(request)
        response.headers["X-Request-Id"] = request_id
        return response


def create_app() -> FastAPI:
    """
    Create and configure the Studio Gateway FastAPI application.

    This is the main entry point that:
    - Creates FastAPI app with metadata
    - Adds global exception handlers
    - Adds middleware (CORS, correlation IDs)
    - Includes all service routers
    - Sets up observability (logging, tracing)
    - Initializes database engine

    Returns:
        Configured FastAPI application
    """
    settings = get_settings()

    # Setup observability
    setup_logging(settings.log_level)
    setup_tracing(
        service_name="studio-gateway-api",
        endpoint=settings.otel_exporter_otlp_endpoint,
    )

    # Create FastAPI app
    app = FastAPI(
        title="Studio Gateway API",
        description="Backend for Frontend (BFF) for Temenos Conversational Studio",
        version="0.1.0",
        docs_url="/docs",
        redoc_url="/redoc",
    )

    # Add CORS middleware (first, handles preflight requests)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins_list,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
        expose_headers=["X-Correlation-ID"],
    )

    # Add correlation ID middleware
    app.add_middleware(CorrelationIDMiddleware)
    app.add_middleware(RequestIDMiddleware)

    # Add comprehensive middleware stack (order matters - last added runs first)
    # 1. Logging (runs last, logs everything)
    app.add_middleware(LoggingMiddleware)

    # 2. Metrics (collects metrics)
    app.add_middleware(MetricsMiddleware)

    # 3. Tracing (creates OpenTelemetry spans)
    app.add_middleware(TracingMiddleware)

    # 3.1 Response envelope (wrap successful Studio v1 responses)
    app.add_middleware(ResponseEnvelopeMiddleware)

    # 4. Rate limiting (checks limits before processing)
    app.add_middleware(
        RateLimitMiddleware,
        requests_per_minute=getattr(settings, "rate_limit_per_minute", 100),
        window_seconds=60,
    )

    # 5. Validation (validates request format/size)
    app.add_middleware(
        ValidationMiddleware,
        max_request_size=getattr(settings, "max_request_size", 10 * 1024 * 1024),
    )

    # 6. Auth (extracts JWT, adds context - runs first to set up context)
    app.add_middleware(
        AuthMiddleware,
        require_auth=getattr(settings, "require_auth_globally", False),
    )

    # Add global exception handler
    app.add_exception_handler(AppError, global_exception_handler)
    app.add_exception_handler(Exception, global_exception_handler)

    # Include all service routers with versioning
    # Version 1 (new)
    app.include_router(
        auth_router,
        prefix="/api/v1/studio/auth",
        tags=["auth"],
    )
    app.include_router(
        workspace_router,
        prefix="/api/v1/studio/workspaces",
        tags=["workspaces"],
    )
    app.include_router(
        designsystem_router,
        prefix="/api/v1/studio/design-systems",
        tags=["design-systems"],
    )
    app.include_router(
        conversation_router,
        prefix="/api/v1/studio/conversations",
        tags=["conversations"],
    )
    app.include_router(
        session_router,
        prefix="/api/v1/studio/session",
        tags=["session"],
    )
    app.include_router(
        theme_router,
        prefix="/api/v1/studio/themes",
        tags=["themes"],
    )
    app.include_router(
        context_catalog_router,
        prefix="/api/v1/studio/contexts",
        tags=["contexts"],
    )
    app.include_router(
        preview_router,
        prefix="/api/v1/studio/preview",
        tags=["preview"],
    )
    app.include_router(
        build_router,
        prefix="/api/v1/studio/builds",
        tags=["builds"],
    )
    app.include_router(
        release_router,
        prefix="/api/v1/studio/publish",
        tags=["publish"],
    )
    app.include_router(
        fabric_router,
        prefix="/api/v1/studio/fabric",
        tags=["fabric"],
    )
    app.include_router(
        audit_router,
        prefix="/api/v1/studio/audit",
        tags=["audit"],
    )
    app.include_router(
        gen_router,
        prefix="/api/v1/studio",
        tags=["gen"],
    )
    app.include_router(
        working_copy_router,
        tags=["working-copy"],
    )
    app.include_router(
        job_projection_router,
        tags=["job-projections"],
    )
    app.include_router(
        lifecycle_timeline_router,
        tags=["lifecycle-timelines"],
    )
    app.include_router(
        internal_truth_router,
        tags=["internal"],
    )

    # Legacy routes (backward compatibility)
    # These will be deprecated in a future release
    app.include_router(
        auth_router,
        prefix="/api/studio/auth",
        tags=["auth (deprecated)"],
    )
    app.include_router(
        workspace_router,
        prefix="/api/studio/workspaces",
        tags=["workspaces (deprecated)"],
    )
    app.include_router(
        designsystem_router,
        prefix="/api/studio/design-systems",
        tags=["design-systems (deprecated)"],
    )
    app.include_router(
        conversation_router,
        prefix="/api/studio/conversations",
        tags=["conversations (deprecated)"],
    )
    app.include_router(
        preview_router,
        prefix="/api/studio/preview",
        tags=["preview (deprecated)"],
    )
    app.include_router(
        build_router,
        prefix="/api/studio/builds",
        tags=["builds (deprecated)"],
    )
    app.include_router(
        release_router,
        prefix="/api/studio/releases",
        tags=["releases (deprecated)"],
    )
    app.include_router(
        fabric_router,
        prefix="/api/studio/fabric",
        tags=["fabric (deprecated)"],
    )
    app.include_router(
        audit_router,
        prefix="/api/studio/audit",
        tags=["audit (deprecated)"],
    )

    # Add deprecation warning middleware for legacy routes
    @app.middleware("http")
    async def add_deprecation_headers(request: Request, call_next):
        """Add deprecation headers for legacy API routes."""
        response = await call_next(request)

        # Check if this is a legacy route (not /api/v1/ and not health/docs)
        path = request.url.path
        if (
            path.startswith("/api/studio/")
            and not path.startswith("/api/v1/studio/")
            and not path.startswith("/health")
            and not path.startswith("/docs")
            and not path.startswith("/redoc")
        ):
            response.headers["X-API-Deprecated"] = "true"
            response.headers["X-API-Version"] = "v1"
            response.headers["Warning"] = '299 - "This API version is deprecated. Use /api/v1/studio/* instead."'

        return response

    @app.on_event("startup")
    async def startup():
        """Initialize Cosmos DB on startup."""
        if settings.cosmos_connection_string:
            try:
                cosmos_client = init_cosmosdb(
                    connection_string=settings.cosmos_connection_string,
                    database_name=settings.cosmos_database_name,
                    container_config=settings.cosmos_container_config,
                    partition_key_path=settings.cosmos_partition_key_path,
                )
                await cosmos_client.connect()
                logger.info("Cosmos DB initialized successfully")
            except Exception as e:
                logger.error(f"Failed to initialize Cosmos DB: {e}", exc_info=True)
                # Don't fail startup, but log the error
        else:
            logger.warning("COSMOS_CONNECTION_STRING not set, Cosmos DB not initialized")

    @app.on_event("shutdown")
    async def shutdown():
        """Close Cosmos DB on shutdown."""
        try:
            cosmos_client = get_cosmosdb_client()
            await cosmos_client.close()
        except RuntimeError:
            pass  # Cosmos DB not initialized

    # Health check endpoints
    health_checker = get_health_checker()

    @app.get("/health")
    async def health():
        """Legacy health check endpoint (backward compatibility)."""
        return {
            "status": "healthy",
            "service": "studio-gateway-api",
            "version": "0.1.0",
        }

    @app.get("/health/live")
    async def health_live():
        """
        Liveness probe for Kubernetes.

        Returns 200 if application is running.
        """
        return await health_checker.check_liveness()

    @app.get("/health/ready")
    async def health_ready():
        """
        Readiness probe for Kubernetes.

        Returns 200 if application is ready to serve traffic.
        Checks database and downstream services.
        """
        status = await health_checker.check_readiness()
        from fastapi import status as http_status
        from fastapi.responses import JSONResponse

        if status["status"] != "healthy":
            return JSONResponse(
                status_code=http_status.HTTP_503_SERVICE_UNAVAILABLE,
                content=status,
            )
        return status

    @app.get("/health/startup")
    async def health_startup():
        """
        Startup probe for Kubernetes.

        Returns 200 if application has finished initializing.
        """
        status = await health_checker.check_startup()
        from fastapi import status as http_status
        from fastapi.responses import JSONResponse

        if status["status"] != "healthy":
            return JSONResponse(
                status_code=http_status.HTTP_503_SERVICE_UNAVAILABLE,
                content=status,
            )
        return status

    @app.get("/")
    async def root():
        """Root endpoint with API information."""
        return {
            "service": "Studio Gateway API",
            "description": "Backend for Frontend (BFF) for Temenos Conversational Studio",
            "docs": "/docs",
            "health": "/health",
        }

    return app

class ProjectCreateRequest(BaseModel):
    workspace_id:str
    name:str
    repo_url:str
    repo_provider:str
    platforms:List[str]

class ProjectResponse(BaseModel):
    project_id:str
    status:str
    message:str

class AuthContext:
    def __init__(self,user_id:str,workspace_id:str,role:str):
        self.user_id=user_id
        self.workspace_id=workspace_id
        self.role=role

async def get_auth_context():
    return AuthContext(
        user_id="user_123",
        workspace_id="ws-123",
        role="admin"
    )

FAKE_COSMOS_DB={}

async def save_to_cosmos(container:str,document:dict):
    FAKE_COSMOS_DB[document["id"]]=document
    return document    


@app.post("api/v1/project",response_model=ProjectResponse)
async def create_project(request:ProjectCreateRequest,auth:AuthContext=Depends(get_auth_context)) -> FastAPI:
    # ---------- STEP 1: Validate Workspace Access ----------
    if auth.workspace_id != request.workspace_id:
        raise HTTPException(
            status_code=403,
            detail="Workspace access denied"
        )
 
    if auth.role not in ["admin", "editor"]:
        raise HTTPException(
            status_code=403,
            detail="Insufficient permissions"
        )
 
    # ---------- STEP 2: Generate Project UUID ----------
    project_id = f"proj-{uuid.uuid4()}"
 
    # ---------- STEP 3: Create Metadata ----------
    metadata = {
        "created_at": datetime.utcnow().isoformat(),
        "created_by": auth.user_id,
        "workspace_id": request.workspace_id,
        "status": "CREATED",
        "version": "v1"
    }
 
    # ---------- STEP 4: Create Cosmos DB Document ----------
    project_doc = {
        "id": project_id,
        "type": "project",
        "workspace_id": request.workspace_id,
        "name": request.name,
        "repo_url": request.repo_url,
        "repo_provider": request.repo_provider,
        "platforms": request.platforms,
        "settings": {
            "design_system": "v1",
            "build_mode": "preview"
        },
        "metadata": metadata
    }
 
    # Save to Cosmos DB
    await save_to_cosmos(container="projects", document=project_doc)
 
    return ProjectResponse(
        project_id=project_id,
        status="CREATED",
        message="Project created successfully"
    )



# Create app instance for uvicorn       
app = create_app()


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8080)

