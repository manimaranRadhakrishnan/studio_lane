"""Studio Gateway API - Main entry point for Studio Web/Admin."""

