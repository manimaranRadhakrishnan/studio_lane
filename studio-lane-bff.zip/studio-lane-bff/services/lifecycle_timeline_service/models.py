"""Lifecycle timeline service request/response models."""

from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, Field

from shared.models import BuildStatus, PreviewStatus, ReleaseStatus


class PreviewTimelineEntryResponse(BaseModel):
    """Preview timeline entry response."""

    env_id: str
    status: PreviewStatus
    preview_url: str | None = None
    wc_version_stamp: str | None = None
    triggered_by: str | None = None
    created_at: datetime
    updated_at: datetime


class BuildTimelineEntryResponse(BaseModel):
    """Build timeline entry response."""

    build_id: str
    status: BuildStatus
    platform: str | None = None
    logs_url: str | None = None
    artifact_id: str | None = None
    wc_version_stamp: str | None = None
    triggered_by: str | None = None
    created_at: datetime
    updated_at: datetime
    completed_at: datetime | None = None


class PublishTimelineEntryResponse(BaseModel):
    """Publish timeline entry response."""

    publish_id: str
    status: ReleaseStatus
    platforms: list[str] = Field(default_factory=list)
    artifacts: list[dict] = Field(default_factory=list)
    release_notes: str | None = None
    wc_version_stamp: str | None = None
    triggered_by: str | None = None
    created_at: datetime
    updated_at: datetime
    completed_at: datetime | None = None


class GetLifecycleTimelineResponse(BaseModel):
    """Response for getting lifecycle timeline."""

    id: str
    tenant_id: str
    project_id: str
    previews: list[PreviewTimelineEntryResponse]
    builds: list[BuildTimelineEntryResponse]
    publishes: list[PublishTimelineEntryResponse]
    updated_at: datetime


class AddPreviewEntryRequest(BaseModel):
    """Request to add a preview timeline entry."""

    env_id: str
    status: PreviewStatus
    preview_url: str | None = None
    wc_version_stamp: str | None = None
    triggered_by: str | None = None


class AddBuildEntryRequest(BaseModel):
    """Request to add a build timeline entry."""

    build_id: str
    status: BuildStatus
    platform: str | None = None
    logs_url: str | None = None
    artifact_id: str | None = None
    wc_version_stamp: str | None = None
    triggered_by: str | None = None


class AddPublishEntryRequest(BaseModel):
    """Request to add a publish timeline entry."""

    publish_id: str
    status: ReleaseStatus
    platforms: list[str] = Field(default_factory=list)
    artifacts: list[dict] = Field(default_factory=list)
    release_notes: str | None = None
    wc_version_stamp: str | None = None
    triggered_by: str | None = None


class UpdatePreviewEntryRequest(BaseModel):
    """Request to update a preview timeline entry."""

    status: PreviewStatus | None = None
    preview_url: str | None = None
    wc_version_stamp: str | None = None


class UpdateBuildEntryRequest(BaseModel):
    """Request to update a build timeline entry."""

    status: BuildStatus | None = None
    logs_url: str | None = None
    artifact_id: str | None = None


class UpdatePublishEntryRequest(BaseModel):
    """Request to update a publish timeline entry."""

    status: ReleaseStatus | None = None
    artifacts: list[dict] | None = None
