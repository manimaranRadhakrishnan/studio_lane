"""Lifecycle timeline service router (preview/build/publish projections)."""

from __future__ import annotations

from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException, Path, Query

from shared import NotFoundError, RequestContext, get_cosmosdb, get_request_context
from shared.cosmosdb import CosmosDBClient
from shared.models import (
    BuildStatus,
    BuildTimelineEntry,
    LifecycleTimeline,
    PreviewTimelineEntry,
    PublishTimelineEntry,
    ReleaseStatus,
)
from shared.repository import BaseRepository

from .models import (
    AddBuildEntryRequest,
    AddPreviewEntryRequest,
    AddPublishEntryRequest,
    BuildTimelineEntryResponse,
    GetLifecycleTimelineResponse,
    PublishTimelineEntryResponse,
    PreviewTimelineEntryResponse,
    UpdateBuildEntryRequest,
    UpdatePreviewEntryRequest,
    UpdatePublishEntryRequest,
)


router = APIRouter(prefix="/api/v1/studio/timelines", tags=["lifecycle-timelines"])


def get_timeline_repo(
    cosmos: CosmosDBClient = Depends(get_cosmosdb),
    ctx: RequestContext = Depends(get_request_context),
) -> BaseRepository[LifecycleTimeline]:
    """Get lifecycle timeline repository."""
    return BaseRepository(cosmos, ctx, LifecycleTimeline, "lifecycle_timeline")


@router.get("/project/{project_id}", response_model=GetLifecycleTimelineResponse)
async def get_lifecycle_timeline(
    project_id: str = Path(..., min_length=1),
    ctx: RequestContext = Depends(get_request_context),
    repo: BaseRepository[LifecycleTimeline] = Depends(get_timeline_repo),
):
    """
    Get lifecycle timeline for a project.

    Returns UI-friendly projection of preview/build/publish history.
    Delivery owns execution IDs; BFF stores this projection for fast reads.
    """
    # LifecycleTimeline uses project_id as id for simple upsert
    timeline = await repo.get(project_id)
    if not timeline:
        # Return empty timeline if not found
        timeline = LifecycleTimeline(
            id=project_id,
            tenant_id=ctx.tenant_id,
            project_id=project_id,
            previews=[],
            builds=[],
            publishes=[],
            updated_at=datetime.utcnow(),
        )

    return GetLifecycleTimelineResponse(
        id=timeline.id,
        tenant_id=timeline.tenant_id,
        project_id=timeline.project_id,
        previews=[
            PreviewTimelineEntryResponse(
                env_id=entry.env_id,
                status=entry.status,
                preview_url=entry.preview_url,
                wc_version_stamp=entry.wc_version_stamp,
                triggered_by=entry.triggered_by,
                created_at=entry.created_at,
                updated_at=entry.updated_at,
            )
            for entry in timeline.previews
        ],
        builds=[
            BuildTimelineEntryResponse(
                build_id=entry.build_id,
                status=entry.status,
                platform=entry.platform,
                logs_url=entry.logs_url,
                artifact_id=entry.artifact_id,
                wc_version_stamp=entry.wc_version_stamp,
                triggered_by=entry.triggered_by,
                created_at=entry.created_at,
                updated_at=entry.updated_at,
                completed_at=entry.completed_at,
            )
            for entry in timeline.builds
        ],
        publishes=[
            PublishTimelineEntryResponse(
                publish_id=entry.publish_id,
                status=entry.status,
                platforms=entry.platforms,
                artifacts=entry.artifacts,
                release_notes=entry.release_notes,
                wc_version_stamp=entry.wc_version_stamp,
                triggered_by=entry.triggered_by,
                created_at=entry.created_at,
                updated_at=entry.updated_at,
                completed_at=entry.completed_at,
            )
            for entry in timeline.publishes
        ],
        updated_at=timeline.updated_at,
    )


@router.post("/project/{project_id}/preview", status_code=201)
async def add_preview_entry(
    project_id: str = Path(..., min_length=1),
    request: AddPreviewEntryRequest = ...,
    ctx: RequestContext = Depends(get_request_context),
    repo: BaseRepository[LifecycleTimeline] = Depends(get_timeline_repo),
):
    """
    Add a preview timeline entry.

    Typically called from Delivery → BFF event ingestion when a preview env is created/updated.
    """
    now = datetime.utcnow()

    # Get or create timeline
    timeline = await repo.get(project_id)
    if not timeline:
        timeline = LifecycleTimeline(
            id=project_id,
            tenant_id=ctx.tenant_id,
            project_id=project_id,
            previews=[],
            builds=[],
            publishes=[],
            updated_at=now,
        )

    # Check if entry already exists (update) or create new
    entry_index = None
    for idx, entry in enumerate(timeline.previews):
        if entry.env_id == request.env_id:
            entry_index = idx
            break

    new_entry = PreviewTimelineEntry(
        env_id=request.env_id,
        status=request.status,
        preview_url=request.preview_url,
        wc_version_stamp=request.wc_version_stamp,
        triggered_by=request.triggered_by or ctx.user_id,
        created_at=timeline.previews[entry_index].created_at if entry_index is not None else now,
        updated_at=now,
    )

    if entry_index is not None:
        timeline.previews[entry_index] = new_entry
    else:
        timeline.previews.append(new_entry)

    timeline.updated_at = now
    if await repo.exists(project_id):
        await repo.update(timeline)
    else:
        await repo.create(timeline)


@router.patch("/project/{project_id}/preview/{env_id}")
async def update_preview_entry(
    project_id: str = Path(..., min_length=1),
    env_id: str = Path(..., min_length=1),
    request: UpdatePreviewEntryRequest = ...,
    ctx: RequestContext = Depends(get_request_context),
    repo: BaseRepository[LifecycleTimeline] = Depends(get_timeline_repo),
):
    """Update a preview timeline entry."""
    timeline = await repo.get(project_id)
    if not timeline:
        raise NotFoundError(message="Lifecycle timeline not found")

    # Find entry
    entry_index = None
    for idx, entry in enumerate(timeline.previews):
        if entry.env_id == env_id:
            entry_index = idx
            break

    if entry_index is None:
        raise NotFoundError(message="Preview entry not found")

    # Update entry
    entry = timeline.previews[entry_index]
    if request.status is not None:
        entry.status = request.status
    if request.preview_url is not None:
        entry.preview_url = request.preview_url
    if request.wc_version_stamp is not None:
        entry.wc_version_stamp = request.wc_version_stamp
    entry.updated_at = datetime.utcnow()

    timeline.updated_at = datetime.utcnow()
    await repo.update(timeline)


@router.post("/project/{project_id}/build", status_code=201)
async def add_build_entry(
    project_id: str = Path(..., min_length=1),
    request: AddBuildEntryRequest = ...,
    ctx: RequestContext = Depends(get_request_context),
    repo: BaseRepository[LifecycleTimeline] = Depends(get_timeline_repo),
):
    """
    Add a build timeline entry.

    Typically called from Delivery → BFF event ingestion when a build is created/updated.
    """
    now = datetime.utcnow()

    # Get or create timeline
    timeline = await repo.get(project_id)
    if not timeline:
        timeline = LifecycleTimeline(
            id=project_id,
            tenant_id=ctx.tenant_id,
            project_id=project_id,
            previews=[],
            builds=[],
            publishes=[],
            updated_at=now,
        )

    # Check if entry already exists (update) or create new
    entry_index = None
    for idx, entry in enumerate(timeline.builds):
        if entry.build_id == request.build_id:
            entry_index = idx
            break

    existing_entry = timeline.builds[entry_index] if entry_index is not None else None
    new_entry = BuildTimelineEntry(
        build_id=request.build_id,
        status=request.status,
        platform=request.platform,
        logs_url=request.logs_url,
        artifact_id=request.artifact_id,
        wc_version_stamp=request.wc_version_stamp,
        triggered_by=request.triggered_by or ctx.user_id,
        created_at=existing_entry.created_at if existing_entry else now,
        updated_at=now,
        completed_at=existing_entry.completed_at
        if existing_entry and existing_entry.completed_at
        else (now if request.status in (BuildStatus.SUCCESS, BuildStatus.FAILED) else None),
    )

    if entry_index is not None:
        timeline.builds[entry_index] = new_entry
    else:
        timeline.builds.append(new_entry)

    timeline.updated_at = now
    if await repo.exists(project_id):
        await repo.update(timeline)
    else:
        await repo.create(timeline)


@router.patch("/project/{project_id}/build/{build_id}")
async def update_build_entry(
    project_id: str = Path(..., min_length=1),
    build_id: str = Path(..., min_length=1),
    request: UpdateBuildEntryRequest = ...,
    ctx: RequestContext = Depends(get_request_context),
    repo: BaseRepository[LifecycleTimeline] = Depends(get_timeline_repo),
):
    """Update a build timeline entry."""
    timeline = await repo.get(project_id)
    if not timeline:
        raise NotFoundError(message="Lifecycle timeline not found")

    # Find entry
    entry_index = None
    for idx, entry in enumerate(timeline.builds):
        if entry.build_id == build_id:
            entry_index = idx
            break

    if entry_index is None:
        raise NotFoundError(message="Build entry not found")

    # Update entry
    entry = timeline.builds[entry_index]
    if request.status is not None:
        entry.status = request.status
    if request.logs_url is not None:
        entry.logs_url = request.logs_url
    if request.artifact_id is not None:
        entry.artifact_id = request.artifact_id

    # Set completed_at if status is terminal
    if request.status and request.status in (BuildStatus.SUCCESS, BuildStatus.FAILED):
        entry.completed_at = datetime.utcnow()

    entry.updated_at = datetime.utcnow()

    timeline.updated_at = datetime.utcnow()
    await repo.update(timeline)


@router.post("/project/{project_id}/publish", status_code=201)
async def add_publish_entry(
    project_id: str = Path(..., min_length=1),
    request: AddPublishEntryRequest = ...,
    ctx: RequestContext = Depends(get_request_context),
    repo: BaseRepository[LifecycleTimeline] = Depends(get_timeline_repo),
):
    """
    Add a publish timeline entry.

    Typically called from Delivery → BFF event ingestion when a publish is created/updated.
    """
    now = datetime.utcnow()

    # Get or create timeline
    timeline = await repo.get(project_id)
    if not timeline:
        timeline = LifecycleTimeline(
            id=project_id,
            tenant_id=ctx.tenant_id,
            project_id=project_id,
            previews=[],
            builds=[],
            publishes=[],
            updated_at=now,
        )

    # Check if entry already exists (update) or create new
    entry_index = None
    for idx, entry in enumerate(timeline.publishes):
        if entry.publish_id == request.publish_id:
            entry_index = idx
            break

    existing_entry = timeline.publishes[entry_index] if entry_index is not None else None
    new_entry = PublishTimelineEntry(
        publish_id=request.publish_id,
        status=request.status,
        platforms=request.platforms,
        artifacts=request.artifacts,
        release_notes=request.release_notes,
        wc_version_stamp=request.wc_version_stamp,
        triggered_by=request.triggered_by or ctx.user_id,
        created_at=existing_entry.created_at if existing_entry else now,
        updated_at=now,
        completed_at=existing_entry.completed_at
        if existing_entry and existing_entry.completed_at
        else (now if request.status in (ReleaseStatus.COMPLETED, ReleaseStatus.FAILED) else None),
    )

    if entry_index is not None:
        timeline.publishes[entry_index] = new_entry
    else:
        timeline.publishes.append(new_entry)

    timeline.updated_at = now
    if await repo.exists(project_id):
        await repo.update(timeline)
    else:
        await repo.create(timeline)


@router.patch("/project/{project_id}/publish/{publish_id}")
async def update_publish_entry(
    project_id: str = Path(..., min_length=1),
    publish_id: str = Path(..., min_length=1),
    request: UpdatePublishEntryRequest = ...,
    ctx: RequestContext = Depends(get_request_context),
    repo: BaseRepository[LifecycleTimeline] = Depends(get_timeline_repo),
):
    """Update a publish timeline entry."""
    timeline = await repo.get(project_id)
    if not timeline:
        raise NotFoundError(message="Lifecycle timeline not found")

    # Find entry
    entry_index = None
    for idx, entry in enumerate(timeline.publishes):
        if entry.publish_id == publish_id:
            entry_index = idx
            break

    if entry_index is None:
        raise NotFoundError(message="Publish entry not found")

    # Update entry
    entry = timeline.publishes[entry_index]
    if request.status is not None:
        entry.status = request.status
    if request.artifacts is not None:
        entry.artifacts = request.artifacts

    # Set completed_at if status is terminal
    if request.status and request.status in (ReleaseStatus.COMPLETED, ReleaseStatus.FAILED):
        entry.completed_at = datetime.utcnow()

    entry.updated_at = datetime.utcnow()

    timeline.updated_at = datetime.utcnow()
    await repo.update(timeline)
