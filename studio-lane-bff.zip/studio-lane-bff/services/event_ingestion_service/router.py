"""Event ingestion router for GenAI and Delivery events."""

from __future__ import annotations

from datetime import datetime

from fastapi import APIRouter, Depends, Header, HTTPException, status

from services.event_ingestion_service.models import (
    BuildStatusChangedEvent,
    GenRunCompletedEvent,
    GenRunFailedEvent,
    GenRunProgressEvent,
    PreviewEnvChangedEvent,
    PublishStatusChangedEvent,
)
from services.job_projection_service.models import UpsertJobProjectionRequest
from shared import get_cosmosdb
from shared.cosmosdb import CosmosDBClient
from shared.models import (
    BuildStatus,
    BuildTimelineEntry,
    GenRunStatus,
    JobProjection,
    LifecycleTimeline,
    PreviewStatus,
    PreviewTimelineEntry,
    PublishTimelineEntry,
    ReleaseStatus,
)
from shared.repository import BaseRepository
from shared.logging import get_logger

logger = get_logger(__name__)

router = APIRouter(prefix="/api/v1/studio/internal/events", tags=["events"])

# In-memory idempotency store (TODO: replace with Redis or Cosmos in prod)
_seen_event_ids: set[str] = set()


def _check_idempotency(event_id: str) -> bool:
    """
    Check if event was already processed (idempotency).

    Returns True if event was already seen, False otherwise.
    In prod, use Cosmos or Redis for distributed idempotency.
    """
    if event_id in _seen_event_ids:
        logger.warning("Duplicate event ignored (idempotency)", extra={"event_id": event_id})
        return True
    _seen_event_ids.add(event_id)
    # TODO: TTL cleanup for in-memory store
    return False


def _get_job_repo(tenant_id: str, cosmos: CosmosDBClient) -> BaseRepository[JobProjection]:
    """Get job projection repository for event ingestion."""
    from shared import RequestContext

    # Create a minimal context for repository (only tenant_id needed)
    ctx = RequestContext(tenant_id=tenant_id, user_id="system", correlation_id=None)
    return BaseRepository(cosmos, ctx, JobProjection, "job_projection")


def _get_timeline_repo(tenant_id: str, cosmos: CosmosDBClient) -> BaseRepository[LifecycleTimeline]:
    """Get lifecycle timeline repository for event ingestion."""
    from shared import RequestContext

    # Create a minimal context for repository (only tenant_id needed)
    ctx = RequestContext(tenant_id=tenant_id, user_id="system", correlation_id=None)
    return BaseRepository(cosmos, ctx, LifecycleTimeline, "lifecycle_timeline")


@router.post("/gen-run/progress")
async def ingest_gen_run_progress(
    event: GenRunProgressEvent,
    x_cs_tenant_id: str | None = Header(None, alias="X-CS-Tenant-Id"),
    cosmos: CosmosDBClient = Depends(get_cosmosdb),
):
    """
    Ingest GenAI run progress event.

    Updates job projection in Cosmos (BFF-owned product truth).
    Idempotent: duplicate eventId is ignored.
    """
    if x_cs_tenant_id and x_cs_tenant_id != event.tenantId:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Tenant scope mismatch",
        )

    if _check_idempotency(event.eventId):
        return {"status": "ignored", "reason": "duplicate"}

    try:
        # Update job projection in Cosmos using repository
        job_repo = _get_job_repo(event.tenantId, cosmos)
        existing = await job_repo.get(event.genRunId)
        now = datetime.utcnow()

        if existing:
            existing.status = GenRunStatus.RUNNING
            existing.progress_percent = event.percent
            existing.current_task_id = event.currentTaskId
            existing.updated_at = now
            await job_repo.update(existing)
        else:
            projection = JobProjection(
                id=event.genRunId,
                tenant_id=event.tenantId,
                project_id=event.projectId,
                gen_run_id=event.genRunId,
                session_id=None,
                status=GenRunStatus.RUNNING,
                progress_percent=event.percent,
                current_task_id=event.currentTaskId,
                tasks_completed=0,
                tasks_total=0,
                patch_set_id=None,
                error_message=None,
                created_at=now,
                updated_at=now,
                completed_at=None,
            )
            await job_repo.create(projection)

        logger.info(
            "Ingested gen run progress event",
            extra={
                "event_id": event.eventId,
                "gen_run_id": event.genRunId,
                "tenant_id": event.tenantId,
                "project_id": event.projectId,
                "percent": event.percent,
            },
        )
        return {"status": "processed"}
    except Exception as e:
        logger.error(
            "Failed to ingest gen run progress event",
            extra={
                "event_id": event.eventId,
                "gen_run_id": event.genRunId,
                "error": str(e),
            },
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Event ingestion failed: {str(e)}",
        )


@router.post("/gen-run/completed")
async def ingest_gen_run_completed(
    event: GenRunCompletedEvent,
    x_cs_tenant_id: str | None = Header(None, alias="X-CS-Tenant-Id"),
):
    """
    Ingest GenAI run completed event.

    Updates job projection in Cosmos (BFF-owned product truth).
    Idempotent: duplicate eventId is ignored.
    """
    if x_cs_tenant_id and x_cs_tenant_id != event.tenantId:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Tenant scope mismatch",
        )

    if _check_idempotency(event.eventId):
        return {"status": "ignored", "reason": "duplicate"}

    try:
        # Update job projection in Cosmos
        await upsert_job_projection(
            gen_run_id=event.genRunId,
            tenant_id=event.tenantId,
            project_id=event.projectId,
            status=event.status,
            progress_percent=100,
            patch_set_id=event.patchSetId,
            validator_summary=event.validatorSummary,
            correlation_id=event.correlationId,
        )

        logger.info(
            "Ingested gen run completed event",
            extra={
                "event_id": event.eventId,
                "gen_run_id": event.genRunId,
                "tenant_id": event.tenantId,
                "project_id": event.projectId,
                "status": event.status,
            },
        )
        return {"status": "processed"}
    except Exception as e:
        logger.error(
            "Failed to ingest gen run completed event",
            extra={
                "event_id": event.eventId,
                "gen_run_id": event.genRunId,
                "error": str(e),
            },
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Event ingestion failed: {str(e)}",
        )


@router.post("/gen-run/failed")
async def ingest_gen_run_failed(
    event: GenRunFailedEvent,
    x_cs_tenant_id: str | None = Header(None, alias="X-CS-Tenant-Id"),
):
    """
    Ingest GenAI run failed event.

    Updates job projection in Cosmos (BFF-owned product truth).
    Idempotent: duplicate eventId is ignored.
    """
    if x_cs_tenant_id and x_cs_tenant_id != event.tenantId:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Tenant scope mismatch",
        )

    if _check_idempotency(event.eventId):
        return {"status": "ignored", "reason": "duplicate"}

    try:
        # Update job projection in Cosmos
        await upsert_job_projection(
            gen_run_id=event.genRunId,
            tenant_id=event.tenantId,
            project_id=event.projectId,
            status="failed",
            error_type=event.errorType,
            error_message=event.message,
            diagnostics_ref=event.diagnosticsRef,
            correlation_id=event.correlationId,
        )

        logger.info(
            "Ingested gen run failed event",
            extra={
                "event_id": event.eventId,
                "gen_run_id": event.genRunId,
                "tenant_id": event.tenantId,
                "project_id": event.projectId,
                "error_type": event.errorType,
            },
        )
        return {"status": "processed"}
    except Exception as e:
        logger.error(
            "Failed to ingest gen run failed event",
            extra={
                "event_id": event.eventId,
                "gen_run_id": event.genRunId,
                "error": str(e),
            },
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Event ingestion failed: {str(e)}",
        )


@router.post("/build/status-changed")
async def ingest_build_status_changed(
    event: BuildStatusChangedEvent,
    x_cs_tenant_id: str | None = Header(None, alias="X-CS-Tenant-Id"),
):
    """
    Ingest Delivery build status changed event.

    Updates lifecycle timeline in Cosmos (BFF-owned product truth).
    Idempotent: duplicate eventId is ignored.
    """
    if x_cs_tenant_id and x_cs_tenant_id != event.tenantId:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Tenant scope mismatch",
        )

    if _check_idempotency(event.eventId):
        return {"status": "ignored", "reason": "duplicate"}

    try:
        # Update lifecycle timeline in Cosmos
        await add_or_update_build_entry(
            build_id=event.buildId,
            tenant_id=event.tenantId,
            project_id=event.projectId,
            status=event.status,
            artifact_id=event.artifactId,
            logs_url=event.logsUrl,
            correlation_id=event.correlationId,
        )

        logger.info(
            "Ingested build status changed event",
            extra={
                "event_id": event.eventId,
                "build_id": event.buildId,
                "tenant_id": event.tenantId,
                "project_id": event.projectId,
                "status": event.status,
            },
        )
        return {"status": "processed"}
    except Exception as e:
        logger.error(
            "Failed to ingest build status changed event",
            extra={
                "event_id": event.eventId,
                "build_id": event.buildId,
                "error": str(e),
            },
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Event ingestion failed: {str(e)}",
        )


@router.post("/preview/env-changed")
async def ingest_preview_env_changed(
    event: PreviewEnvChangedEvent,
    x_cs_tenant_id: str | None = Header(None, alias="X-CS-Tenant-Id"),
):
    """
    Ingest Delivery preview environment changed event.

    Updates lifecycle timeline in Cosmos (BFF-owned product truth).
    Idempotent: duplicate eventId is ignored.
    """
    if x_cs_tenant_id and x_cs_tenant_id != event.tenantId:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Tenant scope mismatch",
        )

    if _check_idempotency(event.eventId):
        return {"status": "ignored", "reason": "duplicate"}

    try:
        # Update lifecycle timeline in Cosmos
        await add_or_update_preview_entry(
            env_id=event.envId,
            tenant_id=event.tenantId,
            project_id=event.projectId,
            status=event.status,
            preview_url=event.previewUrl,
            correlation_id=event.correlationId,
        )

        logger.info(
            "Ingested preview env changed event",
            extra={
                "event_id": event.eventId,
                "env_id": event.envId,
                "tenant_id": event.tenantId,
                "project_id": event.projectId,
                "status": event.status,
            },
        )
        return {"status": "processed"}
    except Exception as e:
        logger.error(
            "Failed to ingest preview env changed event",
            extra={
                "event_id": event.eventId,
                "env_id": event.envId,
                "error": str(e),
            },
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Event ingestion failed: {str(e)}",
        )


@router.post("/publish/status-changed")
async def ingest_publish_status_changed(
    event: PublishStatusChangedEvent,
    x_cs_tenant_id: str | None = Header(None, alias="X-CS-Tenant-Id"),
):
    """
    Ingest Delivery publish status changed event.

    Updates lifecycle timeline in Cosmos (BFF-owned product truth).
    Idempotent: duplicate eventId is ignored.
    """
    if x_cs_tenant_id and x_cs_tenant_id != event.tenantId:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Tenant scope mismatch",
        )

    if _check_idempotency(event.eventId):
        return {"status": "ignored", "reason": "duplicate"}

    try:
        # Update lifecycle timeline in Cosmos
        await add_or_update_publish_entry(
            publish_id=event.publishId,
            tenant_id=event.tenantId,
            project_id=event.projectId,
            status=event.status,
            artifacts=event.artifacts,
            correlation_id=event.correlationId,
        )

        logger.info(
            "Ingested publish status changed event",
            extra={
                "event_id": event.eventId,
                "publish_id": event.publishId,
                "tenant_id": event.tenantId,
                "project_id": event.projectId,
                "status": event.status,
            },
        )
        return {"status": "processed"}
    except Exception as e:
        logger.error(
            "Failed to ingest publish status changed event",
            extra={
                "event_id": event.eventId,
                "publish_id": event.publishId,
                "error": str(e),
            },
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Event ingestion failed: {str(e)}",
        )
