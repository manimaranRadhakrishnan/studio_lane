"""Event ingestion service for GenAI and Delivery events."""

from services.event_ingestion_service.router import router

__all__ = ["router"]
