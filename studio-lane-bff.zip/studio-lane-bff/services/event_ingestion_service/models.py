"""Event ingestion models."""

from typing import Any, Literal

from pydantic import BaseModel, Field


class GenRunProgressEvent(BaseModel):
    """GenAI run progress event."""

    eventId: str  # Idempotency key
    genRunId: str
    tenantId: str
    projectId: str
    percent: int = Field(ge=0, le=100)
    currentTaskId: str | None = None
    correlationId: str | None = None


class GenRunCompletedEvent(BaseModel):
    """GenAI run completed event."""

    eventId: str  # Idempotency key
    genRunId: str
    tenantId: str
    projectId: str
    status: Literal["succeeded", "canceled"]
    patchSetId: str | None = None
    validatorSummary: dict[str, Any] | None = None
    correlationId: str | None = None


class GenRunFailedEvent(BaseModel):
    """GenAI run failed event."""

    eventId: str  # Idempotency key
    genRunId: str
    tenantId: str
    projectId: str
    errorType: str
    message: str
    diagnosticsRef: str | None = None
    correlationId: str | None = None


class BuildStatusChangedEvent(BaseModel):
    """Delivery build status changed event."""

    eventId: str  # Idempotency key
    buildId: str
    tenantId: str
    projectId: str
    status: str
    artifactId: str | None = None
    logsUrl: str | None = None
    correlationId: str | None = None


class PreviewEnvChangedEvent(BaseModel):
    """Delivery preview environment changed event."""

    eventId: str  # Idempotency key
    envId: str
    tenantId: str
    projectId: str
    status: str
    previewUrl: str | None = None
    correlationId: str | None = None


class PublishStatusChangedEvent(BaseModel):
    """Delivery publish status changed event."""

    eventId: str  # Idempotency key
    publishId: str
    tenantId: str
    projectId: str
    status: str
    artifacts: list[dict[str, Any]] = Field(default_factory=list)
    correlationId: str | None = None
