"""Auth and RBAC router."""

import os
from datetime import datetime

from fastapi import APIRouter, Depends

from services.auth_rbac_service.models import (
    AzureADConfigResponse,
    UpdateProfileRequest,
    WhoAmIResponse,
)
from shared import NotFoundError, RequestContext, get_cosmosdb, get_request_context
from shared.cosmosdb import CosmosDBClient
from shared.models import UserProfile
from shared.repository import BaseRepository


router = APIRouter()


def get_user_profile_repo(
    cosmos: CosmosDBClient = Depends(get_cosmosdb),
    ctx: RequestContext = Depends(get_request_context),
) -> BaseRepository[UserProfile]:
    """Get user profile repository."""
    return BaseRepository(cosmos, ctx, UserProfile, "user_profile")


@router.get("/whoami", response_model=WhoAmIResponse)
async def whoami(ctx: RequestContext = Depends(get_request_context)):
    """
    Get current user's identity and roles.

    Returns resolved tenantId, userId, and roles from JWT.
    """
    return WhoAmIResponse(
        tenant_id=ctx.tenant_id,
        user_id=ctx.user_id,
        roles=list(ctx.roles),
        session_id=ctx.session_id,
    )


@router.get("/profile", response_model=UserProfile)
async def get_profile(
    ctx: RequestContext = Depends(get_request_context),
    repo: BaseRepository[UserProfile] = Depends(get_user_profile_repo),
):
    """Get current user profile."""
    # Try to get existing profile
    profile = await repo.get(ctx.user_id)

    if profile:
        return profile

    # Create new profile if doesn't exist
    # In production, profile should be created during first login
    new_profile = UserProfile(
        id=ctx.user_id,
        email=f"{ctx.user_id}@temenos.com",  # Placeholder
        created_at=datetime.utcnow(),
        updated_at=datetime.utcnow(),
    )
    return await repo.create(new_profile)


@router.put("/profile", response_model=UserProfile)
async def update_profile(
    request: UpdateProfileRequest,
    ctx: RequestContext = Depends(get_request_context),
    repo: BaseRepository[UserProfile] = Depends(get_user_profile_repo),
):
    """Update user profile."""
    profile = await repo.get(ctx.user_id)

    if not profile:
        raise NotFoundError(message="Profile not found")

    # Update fields
    update_data = {"updated_at": datetime.utcnow()}
    if request.full_name is not None:
        update_data["full_name"] = request.full_name
    if request.avatar_url is not None:
        update_data["avatar_url"] = request.avatar_url

    return await repo.update(ctx.user_id, **update_data)


@router.get("/azure/config", response_model=AzureADConfigResponse)
async def get_azure_ad_config():
    """
    Get Azure AD configuration for frontend MSAL.

    Public endpoint (no auth required) for frontend to initialize MSAL.
    """
    return AzureADConfigResponse(
        client_id=os.getenv("AZURE_AD_CLIENT_ID", "stub-client-id"),
        authority=os.getenv(
            "AZURE_AD_AUTHORITY",
            "https://login.microsoftonline.com/common",
        ),
        redirect_uri=os.getenv("AZURE_AD_REDIRECT_URI", "http://localhost:3000"),
        scopes=["openid", "profile", "email"],
    )
