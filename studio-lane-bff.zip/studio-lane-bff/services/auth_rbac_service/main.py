"""Auth and RBAC service main application."""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from services.auth_rbac_service.router import router
from shared.config import get_settings


settings = get_settings()

app = FastAPI(
    title="Auth & RBAC Service",
    description="Azure AD/Temenos SSO integration, JWT validation, and role enforcement",
    version="0.1.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include auth router
app.include_router(router, prefix="/api/v1/auth", tags=["auth"])


@app.get("/health")
async def health():
    """Health check endpoint."""
    return {"status": "healthy", "service": "auth-rbac"}


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8001)
