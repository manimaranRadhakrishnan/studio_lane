"""Auth service request/response models."""


from pydantic import BaseModel


class WhoAmIResponse(BaseModel):
    """Response for /whoami endpoint."""

    tenant_id: str
    user_id: str
    roles: list[str]
    session_id: str | None = None


class UpdateProfileRequest(BaseModel):
    """Request to update user profile."""

    full_name: str | None = None
    avatar_url: str | None = None


class AzureADConfigResponse(BaseModel):
    """Azure AD MSAL configuration for frontend."""

    client_id: str
    authority: str
    redirect_uri: str
    scopes: list[str]

