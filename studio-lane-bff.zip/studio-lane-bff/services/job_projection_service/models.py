"""Job projection service request/response models."""

from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel

from shared.models import GenRunStatus


class GetJobProjectionResponse(BaseModel):
    """Response for getting job projection."""

    id: str
    tenant_id: str
    project_id: str
    gen_run_id: str
    session_id: str | None = None
    status: GenRunStatus
    progress_percent: int
    current_task_id: str | None = None
    tasks_completed: int
    tasks_total: int
    patch_set_id: str | None = None
    error_message: str | None = None
    created_at: datetime
    updated_at: datetime
    completed_at: datetime | None = None


class ListJobProjectionsResponse(BaseModel):
    """Response for listing job projections."""

    items: list[GetJobProjectionResponse]
    total: int


class UpsertJobProjectionRequest(BaseModel):
    """Request to create or update job projection."""

    project_id: str
    gen_run_id: str
    session_id: str | None = None
    status: GenRunStatus | None = None
    progress_percent: int | None = None
    current_task_id: str | None = None
    tasks_completed: int | None = None
    tasks_total: int | None = None
    patch_set_id: str | None = None
    error_message: str | None = None


class UpsertJobProjectionResponse(BaseModel):
    """Response for creating or updating job projection."""

    id: str
    tenant_id: str
    project_id: str
    gen_run_id: str
    session_id: str | None = None
    status: GenRunStatus
    progress_percent: int
    current_task_id: str | None = None
    tasks_completed: int
    tasks_total: int
    patch_set_id: str | None = None
    error_message: str | None = None
    created_at: datetime
    updated_at: datetime
    completed_at: datetime | None = None
