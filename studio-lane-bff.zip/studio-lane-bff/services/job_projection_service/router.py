"""Job projection service router (GenAI run status projections)."""

from __future__ import annotations

from datetime import datetime

from fastapi import APIRouter, Depends, Query

from shared import NotFoundError, RequestContext, get_cosmosdb, get_request_context
from shared.cosmosdb import CosmosDBClient
from shared.models import GenRunStatus, JobProjection
from shared.repository import BaseRepository

from .models import (
    GetJobProjectionResponse,
    ListJobProjectionsResponse,
    UpsertJobProjectionRequest,
    UpsertJobProjectionResponse,
)


router = APIRouter(prefix="/api/v1/studio/jobs", tags=["job-projections"])


def get_job_repo(
    cosmos: CosmosDBClient = Depends(get_cosmosdb),
    ctx: RequestContext = Depends(get_request_context),
) -> BaseRepository[JobProjection]:
    """Get job projection repository."""
    return BaseRepository(cosmos, ctx, JobProjection, "job_projection")


@router.get("/{gen_run_id}", response_model=GetJobProjectionResponse)
async def get_job_projection(
    gen_run_id: str,
    ctx: RequestContext = Depends(get_request_context),
    repo: BaseRepository[JobProjection] = Depends(get_job_repo),
):
    """
    Get job projection by GenAI run ID.

    Returns BFF's projection of GenAI run status/progress for UI display.
    """
    projection = await repo.get(gen_run_id)
    if not projection:
        raise NotFoundError(message="Job projection not found")

    return GetJobProjectionResponse(
        id=projection.id,
        tenant_id=projection.tenant_id,
        project_id=projection.project_id,
        gen_run_id=projection.gen_run_id,
        session_id=projection.session_id,
        status=projection.status,
        progress_percent=projection.progress_percent,
        current_task_id=projection.current_task_id,
        tasks_completed=projection.tasks_completed,
        tasks_total=projection.tasks_total,
        patch_set_id=projection.patch_set_id,
        error_message=projection.error_message,
        created_at=projection.created_at,
        updated_at=projection.updated_at,
        completed_at=projection.completed_at,
    )


@router.get("", response_model=ListJobProjectionsResponse)
async def list_job_projections(
    project_id: str = Query(..., min_length=1),
    session_id: str | None = Query(None, min_length=1),
    status: GenRunStatus | None = Query(None),
    limit: int = Query(50, ge=1, le=100),
    offset: int = Query(0, ge=0),
    ctx: RequestContext = Depends(get_request_context),
    repo: BaseRepository[JobProjection] = Depends(get_job_repo),
):
    """
    List job projections for a project (optionally filtered by session or status).

    Returns BFF's projections of GenAI run status for UI display.
    """
    # Build query
    query = "SELECT * FROM c WHERE c.project_id = @project_id"
    parameters = [{"name": "@project_id", "value": project_id}]

    if session_id:
        query += " AND c.session_id = @session_id"
        parameters.append({"name": "@session_id", "value": session_id})

    if status:
        query += " AND c.status = @status"
        parameters.append({"name": "@status", "value": status.value})

    query += " ORDER BY c.created_at DESC OFFSET @offset LIMIT @limit"
    parameters.extend(
        [
            {"name": "@offset", "value": offset},
            {"name": "@limit", "value": limit},
        ]
    )

    items = await repo.cosmos_client.query_items(
        query=query,
        container_name=repo.container_name,
        parameters=parameters,
        partition_key=ctx.tenant_id,
    )

    # Count total (for same filters)
    count_query = "SELECT VALUE COUNT(1) FROM c WHERE c.project_id = @project_id"
    count_params = [{"name": "@project_id", "value": project_id}]
    if session_id:
        count_query += " AND c.session_id = @session_id"
        count_params.append({"name": "@session_id", "value": session_id})
    if status:
        count_query += " AND c.status = @status"
        count_params.append({"name": "@status", "value": status.value})

    count_results = await repo.cosmos_client.query_items(
        query=count_query,
        container_name=repo.container_name,
        parameters=count_params,
        partition_key=ctx.tenant_id,
    )
    total = count_results[0] if count_results else 0

    projections = [repo._to_domain(item) for item in items]

    return ListJobProjectionsResponse(
        items=[
            GetJobProjectionResponse(
                id=proj.id,
                tenant_id=proj.tenant_id,
                project_id=proj.project_id,
                gen_run_id=proj.gen_run_id,
                session_id=proj.session_id,
                status=proj.status,
                progress_percent=proj.progress_percent,
                current_task_id=proj.current_task_id,
                tasks_completed=proj.tasks_completed,
                tasks_total=proj.tasks_total,
                patch_set_id=proj.patch_set_id,
                error_message=proj.error_message,
                created_at=proj.created_at,
                updated_at=proj.updated_at,
                completed_at=proj.completed_at,
            )
            for proj in projections
        ],
        total=total,
    )


@router.post("", response_model=UpsertJobProjectionResponse, status_code=201)
async def upsert_job_projection(
    request: UpsertJobProjectionRequest,
    ctx: RequestContext = Depends(get_request_context),
    repo: BaseRepository[JobProjection] = Depends(get_job_repo),
):
    """
    Create or update job projection.

    Typically called:
    - On GenAI run start (create projection with status=QUEUED)
    - On GenAI run progress events (update projection with progress)
    - On GenAI run completion/failure (update projection with final status)

    This maintains a UI-friendly projection in Cosmos for fast reads (BFF serves from Cosmos,
    optionally refreshing from GenAI on demand).
    """
    now = datetime.utcnow()

    # Check if projection already exists
    existing = await repo.get(request.gen_run_id)

    if existing:
        # Update existing
        if request.status is not None:
            existing.status = request.status
        if request.progress_percent is not None:
            existing.progress_percent = request.progress_percent
        if request.current_task_id is not None:
            existing.current_task_id = request.current_task_id
        if request.tasks_completed is not None:
            existing.tasks_completed = request.tasks_completed
        if request.tasks_total is not None:
            existing.tasks_total = request.tasks_total
        if request.patch_set_id is not None:
            existing.patch_set_id = request.patch_set_id
        if request.error_message is not None:
            existing.error_message = request.error_message
        if request.session_id is not None:
            existing.session_id = request.session_id

        # Set completed_at if status is terminal
        if request.status in (GenRunStatus.COMPLETED, GenRunStatus.FAILED, GenRunStatus.CANCELLED):
            existing.completed_at = now

        existing.updated_at = now
        updated = await repo.update(existing)
        proj = updated
    else:
        # Create new
        projection = JobProjection(
            id=request.gen_run_id,
            tenant_id=ctx.tenant_id,
            project_id=request.project_id,
            gen_run_id=request.gen_run_id,
            session_id=request.session_id,
            status=request.status or GenRunStatus.QUEUED,
            progress_percent=request.progress_percent or 0,
            current_task_id=request.current_task_id,
            tasks_completed=request.tasks_completed or 0,
            tasks_total=request.tasks_total or 0,
            patch_set_id=request.patch_set_id,
            error_message=request.error_message,
            created_at=now,
            updated_at=now,
            completed_at=now
            if (request.status or GenRunStatus.QUEUED) in (GenRunStatus.COMPLETED, GenRunStatus.FAILED, GenRunStatus.CANCELLED)
            else None,
        )
        proj = await repo.create(projection)

    return UpsertJobProjectionResponse(
        id=proj.id,
        tenant_id=proj.tenant_id,
        project_id=proj.project_id,
        gen_run_id=proj.gen_run_id,
        session_id=proj.session_id,
        status=proj.status,
        progress_percent=proj.progress_percent,
        current_task_id=proj.current_task_id,
        tasks_completed=proj.tasks_completed,
        tasks_total=proj.tasks_total,
        patch_set_id=proj.patch_set_id,
        error_message=proj.error_message,
        created_at=proj.created_at,
        updated_at=proj.updated_at,
        completed_at=proj.completed_at,
    )
