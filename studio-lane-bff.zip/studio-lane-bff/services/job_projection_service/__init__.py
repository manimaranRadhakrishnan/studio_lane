"""Job projection service for GenAI run status projections."""

from .router import router

__all__ = ["router"]
