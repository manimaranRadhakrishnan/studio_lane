"""Workspace service request/response models."""


from pydantic import BaseModel

from shared.models import PermissionLevel


class CreateWorkspaceRequest(BaseModel):
    """Request to create a workspace."""

    name: str
    description: str | None = None


class UpdateWorkspaceRequest(BaseModel):
    """Request to update a workspace."""

    name: str | None = None
    description: str | None = None


class CreateProjectRequest(BaseModel):
    """Request to create a project."""

    name: str
    description: str | None = None
    workspace_id: str
    folder_id: str | None = None


class UpdateProjectRequest(BaseModel):
    """Request to update a project."""

    name: str | None = None
    description: str | None = None
    status: str | None = None


class CreateFolderRequest(BaseModel):
    """Request to create a folder."""

    name: str
    workspace_id: str


class RenameFolderRequest(BaseModel):
    """Request to rename a folder."""

    name: str


class MoveProjectRequest(BaseModel):
    """Request to move project to folder."""

    folder_id: str | None = None


class ShareProjectRequest(BaseModel):
    """Request to share a project."""

    shared_with_email: str
    permission: PermissionLevel = PermissionLevel.VIEW

