"""Workspace service main application."""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from services.workspace_service.router import router
from shared.config import get_settings


settings = get_settings()

app = FastAPI(
    title="Workspace Service",
    description="Workspaces, projects, files, metadata, and user workspace state",
    version="0.1.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include workspace router
app.include_router(router, prefix="/api/v1/workspace", tags=["workspace"])


@app.get("/health")
async def health():
    """Health check endpoint."""
    return {"status": "healthy", "service": "workspace"}


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8000)
