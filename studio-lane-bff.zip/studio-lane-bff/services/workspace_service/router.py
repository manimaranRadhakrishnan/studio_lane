"""Workspace service router."""

import uuid
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException

from services.workspace_service.models import (
    CreateFolderRequest,
    CreateProjectRequest,
    CreateWorkspaceRequest,
    MoveProjectRequest,
    RenameFolderRequest,
    ShareProjectRequest,
    UpdateProjectRequest,
    UpdateWorkspaceRequest,
)
from shared import (
    NotFoundError,
    PermissionError,
    RequestContext,
    get_cosmosdb,
    get_request_context,
    require_role,
)
from shared.cosmosdb import CosmosDBClient
from shared.models import (
    Favorite,
    Folder,
    Project,
    ProjectShare,
    ProjectStatus,
    Workspace,
)
from shared.repository import BaseRepository


router = APIRouter()


def get_workspace_repo(
    cosmos: CosmosDBClient = Depends(get_cosmosdb),
    ctx: RequestContext = Depends(get_request_context),
) -> BaseRepository[Workspace]:
    """Get workspace repository."""
    return BaseRepository(cosmos, ctx, Workspace, "workspace")


def get_project_repo(
    cosmos: CosmosDBClient = Depends(get_cosmosdb),
    ctx: RequestContext = Depends(get_request_context),
) -> BaseRepository[Project]:
    """Get project repository."""
    return BaseRepository(cosmos, ctx, Project, "project")


def get_folder_repo(
    cosmos: CosmosDBClient = Depends(get_cosmosdb),
    ctx: RequestContext = Depends(get_request_context),
) -> BaseRepository[Folder]:
    """Get folder repository."""
    return BaseRepository(cosmos, ctx, Folder, "folder")


def get_favorite_repo(
    cosmos: CosmosDBClient = Depends(get_cosmosdb),
    ctx: RequestContext = Depends(get_request_context),
) -> BaseRepository[Favorite]:
    """Get favorite repository."""
    return BaseRepository(cosmos, ctx, Favorite, "favorite")


def get_project_share_repo(
    cosmos: CosmosDBClient = Depends(get_cosmosdb),
    ctx: RequestContext = Depends(get_request_context),
) -> BaseRepository[ProjectShare]:
    """Get project share repository."""
    return BaseRepository(cosmos, ctx, ProjectShare, "project_share")


# ==================== Workspace Endpoints ====================


@router.get("/workspaces", response_model=list[Workspace])
async def list_workspaces(
    repo: BaseRepository[Workspace] = Depends(get_workspace_repo),
):
    """List all workspaces for current user's tenant."""
    return await repo.list()


@router.post("/workspaces", response_model=Workspace, status_code=201)
async def create_workspace(
    request: CreateWorkspaceRequest,
    ctx: RequestContext = Depends(require_role("Owner", "Editor")),
    repo: BaseRepository[Workspace] = Depends(get_workspace_repo),
):
    """Create a new workspace."""
    workspace = Workspace(
        id=str(uuid.uuid4()),
        name=request.name,
        description=request.description,
        tenant_id=ctx.tenant_id,
        owner_id=ctx.user_id,
        created_at=datetime.utcnow(),
        updated_at=datetime.utcnow(),
    )
    return await repo.create(workspace)


@router.get("/workspaces/{workspace_id}", response_model=Workspace)
async def get_workspace(
    workspace_id: str,
    repo: BaseRepository[Workspace] = Depends(get_workspace_repo),
):
    """Get a workspace by ID."""
    workspace = await repo.get(workspace_id)
    if not workspace:
        raise NotFoundError(message="Workspace not found")
    return workspace


@router.patch("/workspaces/{workspace_id}", response_model=Workspace)
async def update_workspace(
    workspace_id: str,
    request: UpdateWorkspaceRequest,
    ctx: RequestContext = Depends(require_role("Owner", "Editor")),
    repo: BaseRepository[Workspace] = Depends(get_workspace_repo),
):
    """Update a workspace."""
    workspace = await repo.get(workspace_id)
    if not workspace:
        raise NotFoundError(message="Workspace not found")

    update_data = {}
    if request.name is not None:
        update_data["name"] = request.name
    if request.description is not None:
        update_data["description"] = request.description
    update_data["updated_at"] = datetime.utcnow()

    return await repo.update(workspace_id, **update_data)


# ==================== Project Endpoints ====================


@router.get("/workspaces/{workspace_id}/projects", response_model=list[Project])
async def list_projects(
    workspace_id: str,
    repo: BaseRepository[Project] = Depends(get_project_repo),
):
    print(repo,"qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq")
    """List all projects in a workspace."""
    return await repo.list(filters={"workspace_id": workspace_id})


@router.post("/projects", response_model=Project, status_code=201)
async def create_project(
    request: CreateProjectRequest,
    ctx: RequestContext = Depends(require_role("Owner", "Editor")),
    repo: BaseRepository[Project] = Depends(get_project_repo),
):
    """Create a new project."""
    project = Project(
        id=str(uuid.uuid4()),
        name=request.name,
        description=request.description,
        workspace_id=request.workspace_id,
        folder_id=request.folder_id,
        status=ProjectStatus.DRAFT,
        tenant_id=ctx.tenant_id,
        user_id=ctx.user_id,
        created_at=datetime.utcnow(),
        updated_at=datetime.utcnow(),
    )
    return await repo.create(project)


@router.get("/projects/{project_id}", response_model=Project)
async def get_project(
    project_id: str,
    repo: BaseRepository[Project] = Depends(get_project_repo),
):
    """Get a project by ID."""
    project = await repo.get(project_id)
    if not project:
        raise NotFoundError(message="Project not found")
    return project


@router.patch("/projects/{project_id}", response_model=Project)
async def update_project(
    project_id: str,
    request: UpdateProjectRequest,
    ctx: RequestContext = Depends(require_role("Owner", "Editor")),
    repo: BaseRepository[Project] = Depends(get_project_repo),
):
    """Update a project."""
    project = await repo.get(project_id)
    if not project:
        raise NotFoundError(message="Project not found")

    update_data = {}
    if request.name is not None:
        update_data["name"] = request.name
    if request.description is not None:
        update_data["description"] = request.description
    if request.status is not None:
        update_data["status"] = ProjectStatus(request.status)
    update_data["updated_at"] = datetime.utcnow()

    return await repo.update(project_id, **update_data)


# ==================== Folder Endpoints ====================


@router.get("/folders", response_model=list[Folder])
async def list_folders(
    ctx: RequestContext = Depends(get_request_context),
    repo: BaseRepository[Folder] = Depends(get_folder_repo),
):
    """List all folders for current user."""
    return await repo.list(filters={"user_id": ctx.user_id})


@router.post("/folders", response_model=Folder, status_code=201)
async def create_folder(
    request: CreateFolderRequest,
    ctx: RequestContext = Depends(require_role("Owner", "Editor")),
    repo: BaseRepository[Folder] = Depends(get_folder_repo),
):
    """Create a new folder."""
    folder = Folder(
        id=str(uuid.uuid4()),
        name=request.name,
        workspace_id=request.workspace_id,
        user_id=ctx.user_id,
        tenant_id=ctx.tenant_id,
        created_at=datetime.utcnow(),
        updated_at=datetime.utcnow(),
    )
    return await repo.create(folder)


@router.put("/folders/{folder_id}", response_model=Folder)
async def rename_folder(
    folder_id: str,
    request: RenameFolderRequest,
    ctx: RequestContext = Depends(require_role("Owner", "Editor")),
    repo: BaseRepository[Folder] = Depends(get_folder_repo),
):
    """Rename a folder."""
    folder = await repo.get(folder_id)
    if not folder:
        raise NotFoundError(message="Folder not found")

    if folder.user_id != ctx.user_id:
        raise PermissionError(message="Only folder owner can rename")

    return await repo.update(folder_id, name=request.name, updated_at=datetime.utcnow())


@router.delete("/folders/{folder_id}", status_code=204)
async def delete_folder(
    folder_id: str,
    ctx: RequestContext = Depends(require_role("Owner", "Editor")),
    repo: BaseRepository[Folder] = Depends(get_folder_repo),
):
    """Delete a folder."""
    folder = await repo.get(folder_id)
    if not folder:
        raise NotFoundError(message="Folder not found")

    if folder.user_id != ctx.user_id:
        raise PermissionError(message="Only folder owner can delete")

    await repo.delete(folder_id)


# ==================== Project Organization Endpoints ====================


@router.post("/projects/{project_id}/move", response_model=Project)
async def move_project(
    project_id: str,
    request: MoveProjectRequest,
    ctx: RequestContext = Depends(require_role("Owner", "Editor")),
    repo: BaseRepository[Project] = Depends(get_project_repo),
):
    """Move project to folder or remove from folder."""
    project = await repo.get(project_id)
    if not project:
        raise NotFoundError(message="Project not found")

    return await repo.update(project_id, folder_id=request.folder_id, updated_at=datetime.utcnow())


@router.post("/projects/{project_id}/favorite", status_code=200)
async def toggle_favorite(
    project_id: str,
    ctx: RequestContext = Depends(get_request_context),
    project_repo: BaseRepository[Project] = Depends(get_project_repo),
    favorite_repo: BaseRepository[Favorite] = Depends(get_favorite_repo),
):
    """Toggle favorite status for a project."""
    # Check if project exists
    project = await project_repo.get(project_id)
    if not project:
        raise NotFoundError(message="Project not found")

    # Check if already favorited
    favorites = await favorite_repo.list(filters={"user_id": ctx.user_id, "project_id": project_id})
    existing = favorites[0] if favorites else None

    if existing:
        await favorite_repo.delete(existing.id)
        return {"favorited": False}
    favorite = Favorite(
        id=str(uuid.uuid4()),
        user_id=ctx.user_id,
        project_id=project_id,
        created_at=datetime.utcnow(),
    )
    await favorite_repo.create(favorite)
    return {"favorited": True}


# ==================== Project Sharing Endpoints ====================


@router.post("/projects/{project_id}/share", response_model=ProjectShare, status_code=201)
async def share_project(
    project_id: str,
    request: ShareProjectRequest,
    ctx: RequestContext = Depends(require_role("Owner")),
    project_repo: BaseRepository[Project] = Depends(get_project_repo),
    share_repo: BaseRepository[ProjectShare] = Depends(get_project_share_repo),
):
    """Share a project with another user (Owner only)."""
    # Verify project exists and user is owner
    project = await project_repo.get(project_id)
    if not project:
        raise NotFoundError(message="Project not found")

    if project.user_id != ctx.user_id:
        raise PermissionError(message="Only project owner can share")

    # Check if already shared
    shares = await share_repo.list(filters={
        "project_id": project_id,
        "shared_with_email": request.shared_with_email,
    })
    if shares:
        raise HTTPException(status_code=400, detail="Project already shared with this user")

    share = ProjectShare(
        id=str(uuid.uuid4()),
        project_id=project_id,
        shared_by_user_id=ctx.user_id,
        shared_with_email=request.shared_with_email,
        permission=request.permission,
        created_at=datetime.utcnow(),
    )
    return await share_repo.create(share)


@router.get("/projects/{project_id}/shares", response_model=list[ProjectShare])
async def list_project_shares(
    project_id: str,
    ctx: RequestContext = Depends(require_role("Owner")),
    share_repo: BaseRepository[ProjectShare] = Depends(get_project_share_repo),
):
    """List all shares for a project (Owner only)."""
    return await share_repo.list(filters={"project_id": project_id})


@router.delete("/projects/{project_id}/shares/{share_id}", status_code=204)
async def remove_share(
    project_id: str,
    share_id: str,
    ctx: RequestContext = Depends(require_role("Owner")),
    share_repo: BaseRepository[ProjectShare] = Depends(get_project_share_repo),
):
    """Remove a project share (Owner only)."""
    share = await share_repo.get(share_id)
    if not share:
        raise NotFoundError(message="Share not found")

    if share.project_id != project_id:
        raise NotFoundError(message="Share not found for this project")

    await share_repo.delete(share_id)
