"""Working copy metadata service router (metadata-only; no file read/write)."""

from __future__ import annotations

from datetime import datetime

from fastapi import APIRouter, Depends, Query

from shared import NotFoundError, RequestContext, get_cosmosdb, get_request_context, require_role
from shared.cosmosdb import CosmosDBClient
from shared.models import WorkingCopyMetadata
from shared.repository import BaseRepository

from .models import (
    GetWorkingCopyMetadataResponse,
    ListWorkingCopyMetadataResponse,
    UpsertWorkingCopyMetadataRequest,
    UpsertWorkingCopyMetadataResponse,
)


router = APIRouter(prefix="/api/v1/studio/wc", tags=["working-copy"])


def get_wc_repo(
    cosmos: CosmosDBClient = Depends(get_cosmosdb),
    ctx: RequestContext = Depends(get_request_context),
) -> BaseRepository[WorkingCopyMetadata]:
    """Get working copy metadata repository."""
    return BaseRepository(cosmos, ctx, WorkingCopyMetadata, "working_copy_metadata")


@router.get("/metadata/{wc_version_stamp}", response_model=GetWorkingCopyMetadataResponse)
async def get_working_copy_metadata(
    wc_version_stamp: str,
    ctx: RequestContext = Depends(get_request_context),
    repo: BaseRepository[WorkingCopyMetadata] = Depends(get_wc_repo),
):
    """
    Get working copy metadata by version stamp.

    Note: This endpoint only returns metadata pointers. Studio Web does not access file content.
    GenAI Core owns actual code read/write in Blob storage.
    """
    meta = await repo.get(wc_version_stamp)
    if not meta:
        raise NotFoundError(message="Working copy metadata not found")

    return GetWorkingCopyMetadataResponse(
        id=meta.id,
        tenant_id=meta.tenant_id,
        project_id=meta.project_id,
        branch=meta.branch,
        wc_version_stamp=meta.wc_version_stamp,
        blob_base_uri=meta.blob_base_uri,
        base_wc_version_stamp=meta.base_wc_version_stamp,
        git_commit_sha=meta.git_commit_sha,
        created_by=meta.created_by,
        created_at=meta.created_at,
        updated_at=meta.updated_at,
    )


@router.get("/metadata", response_model=ListWorkingCopyMetadataResponse)
async def list_working_copy_metadata(
    project_id: str = Query(..., min_length=1),
    branch: str | None = Query(None, min_length=1),
    limit: int = Query(50, ge=1, le=100),
    offset: int = Query(0, ge=0),
    ctx: RequestContext = Depends(get_request_context),
    repo: BaseRepository[WorkingCopyMetadata] = Depends(get_wc_repo),
):
    """
    List working copy metadata entries for a project (optionally filtered by branch).

    Returns only metadata pointers; no file content is exposed.
    """
    # Build query
    query = f"SELECT * FROM c WHERE c.project_id = @project_id"
    parameters = [{"name": "@project_id", "value": project_id}]

    if branch:
        query += " AND c.branch = @branch"
        parameters.append({"name": "@branch", "value": branch})

    query += " ORDER BY c.created_at DESC OFFSET @offset LIMIT @limit"
    parameters.extend(
        [
            {"name": "@offset", "value": offset},
            {"name": "@limit", "value": limit},
        ]
    )

    items = await repo.cosmos_client.query_items(
        query=query,
        container_name=repo.container_name,
        parameters=parameters,
        partition_key=ctx.tenant_id,
    )

    # Count total (for same filters)
    count_query = f"SELECT VALUE COUNT(1) FROM c WHERE c.project_id = @project_id"
    count_params = [{"name": "@project_id", "value": project_id}]
    if branch:
        count_query += " AND c.branch = @branch"
        count_params.append({"name": "@branch", "value": branch})

    count_results = await repo.cosmos_client.query_items(
        query=count_query,
        container_name=repo.container_name,
        parameters=count_params,
        partition_key=ctx.tenant_id,
    )
    total = count_results[0] if count_results else 0

    metadata_list = [repo._to_domain(item) for item in items]

    return ListWorkingCopyMetadataResponse(
        items=[
            GetWorkingCopyMetadataResponse(
                id=meta.id,
                tenant_id=meta.tenant_id,
                project_id=meta.project_id,
                branch=meta.branch,
                wc_version_stamp=meta.wc_version_stamp,
                blob_base_uri=meta.blob_base_uri,
                base_wc_version_stamp=meta.base_wc_version_stamp,
                git_commit_sha=meta.git_commit_sha,
                created_by=meta.created_by,
                created_at=meta.created_at,
                updated_at=meta.updated_at,
            )
            for meta in metadata_list
        ],
        total=total,
    )


@router.post("/metadata", response_model=UpsertWorkingCopyMetadataResponse, status_code=201)
async def upsert_working_copy_metadata(
    request: UpsertWorkingCopyMetadataRequest,
    ctx: RequestContext = Depends(require_role("Owner", "Editor")),
    repo: BaseRepository[WorkingCopyMetadata] = Depends(get_wc_repo),
):
    """
    Create or update working copy metadata (pointers only).

    This endpoint stores metadata pointers to Blob storage. GenAI Core owns actual code read/write.
    Typically called after:
    - Git → WC sync (BFF updates WC metadata after syncing from Git)
    - GenAI run completion (BFF updates WC metadata after GenAI writes new WC version)
    """
    now = datetime.utcnow()

    # Check if metadata already exists
    existing = await repo.get(request.wc_version_stamp)

    if existing:
        # Update existing
        existing.blob_base_uri = request.blob_base_uri
        existing.branch = request.branch
        existing.base_wc_version_stamp = request.base_wc_version_stamp
        existing.git_commit_sha = request.git_commit_sha
        existing.updated_at = now
        updated = await repo.update(existing)
        meta = updated
    else:
        # Create new
        metadata = WorkingCopyMetadata(
            id=request.wc_version_stamp,
            tenant_id=ctx.tenant_id,
            project_id=request.project_id,
            branch=request.branch,
            wc_version_stamp=request.wc_version_stamp,
            blob_base_uri=request.blob_base_uri,
            base_wc_version_stamp=request.base_wc_version_stamp,
            git_commit_sha=request.git_commit_sha,
            created_by=ctx.user_id,
            created_at=now,
            updated_at=now,
        )
        meta = await repo.create(metadata)

    return UpsertWorkingCopyMetadataResponse(
        id=meta.id,
        tenant_id=meta.tenant_id,
        project_id=meta.project_id,
        branch=meta.branch,
        wc_version_stamp=meta.wc_version_stamp,
        blob_base_uri=meta.blob_base_uri,
        base_wc_version_stamp=meta.base_wc_version_stamp,
        git_commit_sha=meta.git_commit_sha,
        created_by=meta.created_by,
        created_at=meta.created_at,
        updated_at=meta.updated_at,
    )


@router.get("/metadata/project/{project_id}/latest", response_model=GetWorkingCopyMetadataResponse)
async def get_latest_working_copy_metadata(
    project_id: str,
    branch: str = Query("main", min_length=1),
    ctx: RequestContext = Depends(get_request_context),
    repo: BaseRepository[WorkingCopyMetadata] = Depends(get_wc_repo),
):
    """
    Get the latest working copy metadata for a project and branch.

    Returns the most recent WC version stamp pointer for the specified project/branch.
    """
    query = (
        "SELECT TOP 1 * FROM c "
        "WHERE c.project_id = @project_id AND c.branch = @branch "
        "ORDER BY c.created_at DESC"
    )
    parameters = [
        {"name": "@project_id", "value": project_id},
        {"name": "@branch", "value": branch},
    ]

    items = await repo.cosmos_client.query_items(
        query=query,
        container_name=repo.container_name,
        parameters=parameters,
        partition_key=ctx.tenant_id,
    )

    if not items:
        raise NotFoundError(
            message="No working copy metadata found",
            details={"project_id": project_id, "branch": branch},
        )

    meta = repo._to_domain(items[0])

    return GetWorkingCopyMetadataResponse(
        id=meta.id,
        tenant_id=meta.tenant_id,
        project_id=meta.project_id,
        branch=meta.branch,
        wc_version_stamp=meta.wc_version_stamp,
        blob_base_uri=meta.blob_base_uri,
        base_wc_version_stamp=meta.base_wc_version_stamp,
        git_commit_sha=meta.git_commit_sha,
        created_by=meta.created_by,
        created_at=meta.created_at,
        updated_at=meta.updated_at,
    )