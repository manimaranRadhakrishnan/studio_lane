"""Working copy metadata service request/response models."""

from __future__ import annotations

from datetime import datetime
from typing import Literal

from pydantic import BaseModel, Field


class WorkingCopyRef(BaseModel):
    """Working copy reference (pointer to Blob storage)."""

    blob_base_uri: str
    wc_version_stamp: str
    branch: str


class GetWorkingCopyMetadataResponse(BaseModel):
    """Response for getting working copy metadata."""

    id: str
    tenant_id: str
    project_id: str
    branch: str
    wc_version_stamp: str
    blob_base_uri: str
    base_wc_version_stamp: str | None = None
    git_commit_sha: str | None = None
    created_by: str | None = None
    created_at: datetime
    updated_at: datetime


class ListWorkingCopyMetadataResponse(BaseModel):
    """Response for listing working copy metadata entries."""

    items: list[GetWorkingCopyMetadataResponse]
    total: int


class UpsertWorkingCopyMetadataRequest(BaseModel):
    """Request to create or update working copy metadata."""

    project_id: str
    branch: str = "main"
    wc_version_stamp: str
    blob_base_uri: str
    base_wc_version_stamp: str | None = None
    git_commit_sha: str | None = None


class UpsertWorkingCopyMetadataResponse(BaseModel):
    """Response for creating or updating working copy metadata."""

    id: str
    tenant_id: str
    project_id: str
    branch: str
    wc_version_stamp: str
    blob_base_uri: str
    base_wc_version_stamp: str | None = None
    git_commit_sha: str | None = None
    created_by: str | None = None
    created_at: datetime
    updated_at: datetime