"""Release proxy service router."""

from typing import Any

from fastapi import APIRouter, Depends

from services.release_proxy_service.models import PublishRequest
from shared import RequestContext, get_settings, require_role
from shared.clients_delivery import DeliveryClient
from shared.config import Settings


router = APIRouter()


@router.post("")
async def publish(
    request: PublishRequest,
    ctx: RequestContext = Depends(require_role("Owner", "Editor")),
    settings: Settings = Depends(get_settings),
) -> dict[str, Any]:
    """
    Publish artifacts (contract-first).
    """
    delivery_client = DeliveryClient(settings)
    try:
        return await delivery_client.publish(ctx=ctx, payload=request.model_dump())
    finally:
        await delivery_client.close()


