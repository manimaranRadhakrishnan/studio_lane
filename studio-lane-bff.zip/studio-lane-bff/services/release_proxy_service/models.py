"""Release proxy service request/response models."""

from typing import Literal

from pydantic import BaseModel


class PublishRequest(BaseModel):
    """Contract-first publish request."""

    tenantId: str
    projectId: str
    sourceWcVersionStamp: str
    platforms: list[Literal["web", "ios", "android"]] = ["web"]
    releaseNotes: str | None = None

