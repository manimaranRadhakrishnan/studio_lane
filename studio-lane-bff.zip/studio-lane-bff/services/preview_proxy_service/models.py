"""Preview proxy service request/response models (ms-apis aligned)."""

from typing import Literal

from pydantic import BaseModel


class WcRef(BaseModel):
    blobBaseUri: str | None = None
    wcVersionStamp: str
    branch: str | None = None


class DesignSystemRef(BaseModel):
    version: str | None = None
    uri: str | None = None


class CreateEnvRequest(BaseModel):
    tenantId: str
    projectId: str
    platform: Literal["web", "ios", "android"]
    wcRef: WcRef
    designSystemRef: DesignSystemRef | None = None
    mode: Literal["editable_preview", "live_preview"] = "editable_preview"


class RefreshEnvRequest(BaseModel):
    trigger: Literal["wc_change", "design_system_change"]
    wcRef: WcRef | None = None
    designSystemRef: DesignSystemRef | None = None


class RevertEnvRequest(BaseModel):
    target: dict

