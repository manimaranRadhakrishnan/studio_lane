"""Preview proxy service router."""

from typing import Any

from fastapi import APIRouter, Depends

from services.preview_proxy_service.models import (
    CreateEnvRequest,
    RefreshEnvRequest,
    RevertEnvRequest,
)
from shared import RequestContext, get_settings, require_role
from shared.clients_delivery import DeliveryClient
from shared.config import Settings


router = APIRouter()


@router.post("/envs")
async def create_env(
    request: CreateEnvRequest,
    ctx: RequestContext = Depends(require_role("Owner", "Editor")),
    settings: Settings = Depends(get_settings),
) -> dict[str, Any]:
    """
    Create/start preview environment (contract-first).
    """
    delivery_client = DeliveryClient(settings)
    try:
        return await delivery_client.create_env(ctx=ctx, payload=request.model_dump())
    finally:
        await delivery_client.close()


@router.post("/envs/{env_id}:refresh")
async def refresh_env(
    env_id: str,
    request: RefreshEnvRequest,
    tenantId: str,
    ctx: RequestContext = Depends(require_role("Owner", "Editor")),
    settings: Settings = Depends(get_settings),
) -> dict[str, Any]:
    """
    Refresh preview environment (contract-first).
    """
    delivery_client = DeliveryClient(settings)
    try:
        return await delivery_client.refresh_env(
            ctx=ctx,
            env_id=env_id,
            tenant_id=tenantId,
            payload=request.model_dump(),
        )
    finally:
        await delivery_client.close()


@router.post("/envs/{env_id}:revert")
async def revert_env(
    env_id: str,
    request: RevertEnvRequest,
    tenantId: str,
    ctx: RequestContext = Depends(require_role("Owner", "Editor")),
    settings: Settings = Depends(get_settings),
) -> dict[str, Any]:
    """
    Revert preview environment (contract-first).
    """
    delivery_client = DeliveryClient(settings)
    try:
        return await delivery_client.revert_env(
            ctx=ctx,
            env_id=env_id,
            tenant_id=tenantId,
            payload=request.model_dump(),
        )
    finally:
        await delivery_client.close()

