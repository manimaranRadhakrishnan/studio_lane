"""Context catalog service router (prompt library)."""

import uuid
from datetime import datetime

from fastapi import APIRouter, Depends

from services.context_catalog_service.models import CreateContextRequest, UpdateProjectContextSelectionRequest
from shared import NotFoundError, RequestContext, get_cosmosdb, get_request_context, require_role
from shared.cosmosdb import CosmosDBClient
from shared.models import ContextItem, ProjectContextSelection
from shared.repository import BaseRepository


router = APIRouter()


def get_context_repo(
    cosmos: CosmosDBClient = Depends(get_cosmosdb),
    ctx: RequestContext = Depends(get_request_context),
) -> BaseRepository[ContextItem]:
    return BaseRepository(cosmos, ctx, ContextItem, "context_item")


def get_selection_repo(
    cosmos: CosmosDBClient = Depends(get_cosmosdb),
    ctx: RequestContext = Depends(get_request_context),
) -> BaseRepository[ProjectContextSelection]:
    return BaseRepository(cosmos, ctx, ProjectContextSelection, "project_context_selection")


@router.get("/", response_model=list[ContextItem])
async def list_contexts(
    _ctx: RequestContext = Depends(get_request_context),
    repo: BaseRepository[ContextItem] = Depends(get_context_repo),
):
    """List context library items for tenant (no search/filter in MVP)."""
    return await repo.list()


@router.post("/", response_model=ContextItem, status_code=201)
async def create_context(
    request: CreateContextRequest,
    ctx: RequestContext = Depends(require_role("Owner", "Editor")),
    repo: BaseRepository[ContextItem] = Depends(get_context_repo),
):
    """Create a context library item."""
    item = ContextItem(
        id=str(uuid.uuid4()),
        tenant_id=ctx.tenant_id,
        title=request.title,
        content=request.content,
        tags=request.tags or [],
        version=1,
        created_by=ctx.user_id,
        created_at=datetime.utcnow(),
        updated_at=datetime.utcnow(),
    )
    return await repo.create(item)


@router.get("/projects/{project_id}/selection", response_model=ProjectContextSelection)
async def get_project_context_selection(
    project_id: str,
    ctx: RequestContext = Depends(get_request_context),
    repo: BaseRepository[ProjectContextSelection] = Depends(get_selection_repo),
):
    """Get context selection for a project (single-select by UX; stored as list for evolvability)."""
    selection = await repo.get(project_id)
    if selection:
        return selection

    # Return empty selection record (not persisted) for convenience.
    return ProjectContextSelection(
        id=project_id,
        project_id=project_id,
        tenant_id=ctx.tenant_id,
        selected_context_ids=[],
        updated_by=ctx.user_id,
        updated_at=datetime.utcnow(),
    )


@router.put("/projects/{project_id}/selection", response_model=ProjectContextSelection)
async def update_project_context_selection(
    project_id: str,
    request: UpdateProjectContextSelectionRequest,
    ctx: RequestContext = Depends(require_role("Owner", "Editor")),
    repo: BaseRepository[ProjectContextSelection] = Depends(get_selection_repo),
):
    """
    Update context selection for a project.

    Sprint MVP: UX is single-select, but API supports list.
    """
    now = datetime.utcnow()
    existing = await repo.get(project_id)
    if existing:
        updated = await repo.update(
            project_id,
            selected_context_ids=request.selected_context_ids,
            updated_by=ctx.user_id,
            updated_at=now,
        )
        if not updated:
            raise NotFoundError(message="Project selection not found")
        return updated

    selection = ProjectContextSelection(
        id=project_id,
        project_id=project_id,
        tenant_id=ctx.tenant_id,
        selected_context_ids=request.selected_context_ids,
        updated_by=ctx.user_id,
        updated_at=now,
    )
    await repo.create(selection)
    return selection


