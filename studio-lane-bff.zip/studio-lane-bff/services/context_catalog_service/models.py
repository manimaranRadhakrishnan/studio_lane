"""Context catalog (prompt library) models."""

from pydantic import BaseModel


class CreateContextRequest(BaseModel):
    title: str
    content: str
    tags: list[str] = []


class UpdateProjectContextSelectionRequest(BaseModel):
    selected_context_ids: list[str] = []


