"""Theme service router."""

import uuid
from datetime import datetime

from fastapi import APIRouter, Depends

from services.theme_service.models import CreateThemeRequest, SeedThemesResponse, UpdateThemeRequest
from shared import NotFoundError, RequestContext, get_cosmosdb, get_request_context, require_role
from shared.cosmosdb import CosmosDBClient
from shared.models import Theme
from shared.repository import BaseRepository


router = APIRouter()


def get_theme_repo(
    cosmos: CosmosDBClient = Depends(get_cosmosdb),
    ctx: RequestContext = Depends(get_request_context),
) -> BaseRepository[Theme]:
    return BaseRepository(cosmos, ctx, Theme, "theme")


@router.get("/", response_model=list[Theme])
async def list_themes(
    _ctx: RequestContext = Depends(get_request_context),
    repo: BaseRepository[Theme] = Depends(get_theme_repo),
):
    """List themes for tenant."""
    return await repo.list()


@router.post("/", response_model=Theme, status_code=201)
async def create_theme(
    request: CreateThemeRequest,
    ctx: RequestContext = Depends(require_role("Owner", "Editor")),
    repo: BaseRepository[Theme] = Depends(get_theme_repo),
):
    """Create a theme."""
    theme = Theme(
        id=str(uuid.uuid4()),
        name=request.name,
        tenant_id=ctx.tenant_id,
        created_by=ctx.user_id,
        description=request.description,
        colors=request.colors or {},
        typography=request.typography or {},
        created_at=datetime.utcnow(),
        updated_at=datetime.utcnow(),
    )
    return await repo.create(theme)


@router.get("/{theme_id}", response_model=Theme)
async def get_theme(
    theme_id: str,
    repo: BaseRepository[Theme] = Depends(get_theme_repo),
):
    theme = await repo.get(theme_id)
    if not theme:
        raise NotFoundError(message="Theme not found")
    return theme


@router.patch("/{theme_id}", response_model=Theme)
async def update_theme(
    theme_id: str,
    request: UpdateThemeRequest,
    ctx: RequestContext = Depends(require_role("Owner", "Editor")),
    repo: BaseRepository[Theme] = Depends(get_theme_repo),
):
    existing = await repo.get(theme_id)
    if not existing:
        raise NotFoundError(message="Theme not found")

    update_data: dict = {"updated_at": datetime.utcnow()}
    if request.name is not None:
        update_data["name"] = request.name
    if request.description is not None:
        update_data["description"] = request.description
    if request.colors is not None:
        update_data["colors"] = request.colors
    if request.typography is not None:
        update_data["typography"] = request.typography

    updated = await repo.update(theme_id, **update_data)
    if not updated:
        raise NotFoundError(message="Theme not found")
    return updated


@router.delete("/{theme_id}")
async def delete_theme(
    theme_id: str,
    ctx: RequestContext = Depends(require_role("Owner", "Editor")),
    repo: BaseRepository[Theme] = Depends(get_theme_repo),
) -> dict:
    deleted = await repo.delete(theme_id)
    if not deleted:
        raise NotFoundError(message="Theme not found")
    return {"deleted": True, "id": theme_id}


@router.post("/seed", response_model=SeedThemesResponse)
async def seed_themes(
    ctx: RequestContext = Depends(require_role("Owner", "Editor")),
    repo: BaseRepository[Theme] = Depends(get_theme_repo),
):
    """
    Seed suggested Temenos themes (idempotent-by-name).
    """
    seeds = [
        {"name": "Temenos Light", "colors": {"background": "#ffffff", "text": "#111111"}},
        {"name": "Temenos Dark", "colors": {"background": "#0b0f1a", "text": "#f5f7ff"}},
    ]

    created = 0
    skipped = 0
    for seed in seeds:
        existing = await repo.list(filters={"name": seed["name"]})
        if isinstance(existing, list) and len(existing) > 0:
            skipped += 1
            continue
        theme = Theme(
            id=str(uuid.uuid4()),
            name=seed["name"],
            tenant_id=ctx.tenant_id,
            created_by=ctx.user_id,
            colors=seed.get("colors", {}),
            typography=seed.get("typography", {}),
            created_at=datetime.utcnow(),
            updated_at=datetime.utcnow(),
        )
        await repo.create(theme)
        created += 1

    return SeedThemesResponse(created=created, skipped=skipped)


