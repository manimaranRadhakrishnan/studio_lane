"""Theme service models."""

from pydantic import BaseModel


class CreateThemeRequest(BaseModel):
    name: str
    description: str | None = None
    colors: dict = {}
    typography: dict = {}


class UpdateThemeRequest(BaseModel):
    name: str | None = None
    description: str | None = None
    colors: dict | None = None
    typography: dict | None = None


class SeedThemesResponse(BaseModel):
    created: int
    skipped: int


