"""Fabric Proxy Service - Fabric API catalog."""

