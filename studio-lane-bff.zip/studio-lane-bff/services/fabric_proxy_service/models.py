"""Fabric proxy service request/response models."""

from typing import Any

from pydantic import BaseModel


class SaveFabricConfigRequest(BaseModel):
    """Request to save Fabric API configuration."""

    project_id: str
    api_id: str
    config: dict[str, Any]

