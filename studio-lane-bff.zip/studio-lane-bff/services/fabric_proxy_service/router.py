"""Fabric proxy service router."""

from typing import Any

from fastapi import APIRouter, Depends

from services.fabric_proxy_service.models import SaveFabricConfigRequest
from shared import RequestContext, get_settings, require_role
from shared.clients_control import FabricClient
from shared.config import Settings


router = APIRouter()


@router.get("/fabric/apis")
async def list_apis(
    ctx: RequestContext = Depends(require_role("Owner", "Editor")),
    settings: Settings = Depends(get_settings),
) -> list[dict[str, Any]]:
    """
    List available Fabric APIs.

    Proxies to Fabric/Control Plane service.
    """
    fabric_client = FabricClient(settings)
    try:
        return await fabric_client.list_apis(ctx=ctx)
    finally:
        await fabric_client.close()


@router.get("/fabric/apis/{api_id}")
async def get_api_details(
    api_id: str,
    ctx: RequestContext = Depends(require_role("Owner", "Editor")),
    settings: Settings = Depends(get_settings),
) -> dict[str, Any]:
    """
    Get detailed information about a Fabric API.

    Proxies to Fabric/Control Plane service.
    """
    fabric_client = FabricClient(settings)
    try:
        return await fabric_client.get_api_details(ctx=ctx, api_id=api_id)
    finally:
        await fabric_client.close()


@router.post("/fabric/apis/config")
async def save_fabric_config(
    request: SaveFabricConfigRequest,
    ctx: RequestContext = Depends(require_role("Owner", "Editor")),
    settings: Settings = Depends(get_settings),
) -> dict[str, Any]:
    """
    Save Fabric API configuration for a project.

    Proxies to Fabric/Control Plane service.
    """
    fabric_client = FabricClient(settings)
    try:
        return await fabric_client.save_config(
            ctx=ctx,
            project_id=request.project_id,
            api_id=request.api_id,
            config=request.config,
        )
    finally:
        await fabric_client.close()

