"""Internal truth bundle service router (service-to-service, GenAI calls these)."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Path

from shared import NotFoundError, RequestContext, get_cosmosdb, get_request_context
from shared.cosmosdb import CosmosDBClient
from shared.models import ContextItem, DesignSystem, Project, ProjectContextSelection
from shared.repository import BaseRepository

from .models import ContextBundleResponse, FabricApiResponse


router = APIRouter(prefix="/api/v1/studio/internal", tags=["internal"])


# Service-to-service auth: For now, rely on X-CS-Tenant-Id header validation via auth middleware
# In production, add service-to-service token validation here


@router.get("/projects/{project_id}/context-bundle", response_model=ContextBundleResponse)
async def get_context_bundle(
    project_id: str = Path(..., min_length=1),
    ctx: RequestContext = Depends(get_request_context),  # Service-to-service still needs tenant context
    cosmos: CosmosDBClient = Depends(get_cosmosdb),
) -> ContextBundleResponse:
    """
    Get context bundle for GenAI context building.

    Returns deterministic truth from Cosmos:
    - Project metadata
    - Selected contexts (from project context selection)
    - Design system reference
    - Fabric registry reference

    This is called by GenAI Core during context building phase.
    """
    # Get project
    project_repo = BaseRepository(cosmos, ctx, Project, "project")
    project = await project_repo.get(project_id)
    if not project:
        raise NotFoundError(message="Project not found")

    # Get project context selection
    context_selection_repo = BaseRepository(cosmos, ctx, ProjectContextSelection, "project_context_selection")
    context_selection = await context_selection_repo.get(project_id)

    selected_contexts = []
    if context_selection and context_selection.selected_context_ids:
        # Fetch context items
        context_repo = BaseRepository(cosmos, ctx, ContextItem, "context_item")
        for context_id in context_selection.selected_context_ids:
            context_item = await context_repo.get(context_id)
            if context_item:
                selected_contexts.append(
                    {
                        "id": context_item.id,
                        "title": context_item.title,
                        "content": context_item.content,
                        "tags": context_item.tags,
                        "version": context_item.version,
                    }
                )

    # Get design system (if linked)
    design_system_ref = None
    if project.folder_id:  # Assuming design system linked via folder/workspace; adjust based on actual schema
        design_system_repo = BaseRepository(cosmos, ctx, DesignSystem, "design_system")
        # Query for design system linked to project
        design_systems = await design_system_repo.cosmos_client.query_items(
            query="SELECT * FROM c WHERE c.project_id = @project_id AND c.type = @doc_type",
            container_name=design_system_repo.container_name,
            parameters=[
                {"name": "@project_id", "value": project_id},
                {"name": "@doc_type", "value": "design_system"},
            ],
            partition_key=ctx.tenant_id,
        )
        if design_systems:
            ds_doc = design_systems[0]
            design_system = design_system_repo._to_domain(ds_doc)
            design_system_ref = {
                "id": design_system.id,
                "name": design_system.name,
                "version": design_system.version,
                "config": design_system.config,
            }

    return ContextBundleResponse(
        project_id=project_id,
        tenant_id=ctx.tenant_id,
        selected_contexts=selected_contexts,
        project_metadata={
            "id": project.id,
            "name": project.name,
            "description": project.description,
            "status": project.status.value,
            "workspace_id": project.workspace_id,
        },
        design_system_ref=design_system_ref,
        fabric_registry_ref=None,  # TODO: Implement fabric registry lookup when available
    )


@router.get("/fabric/apis/{fabric_api_id}", response_model=FabricApiResponse)
async def get_fabric_api(
    fabric_api_id: str = Path(..., min_length=1),
    ctx: RequestContext = Depends(get_request_context),
    cosmos: CosmosDBClient = Depends(get_cosmosdb),
) -> FabricApiResponse:
    """
    Get Fabric API contract details for GenAI.

    Returns deterministic truth from Cosmos fabric registry.
    GenAI uses this for API binding context.

    TODO: Implement once fabric registry models are available in Cosmos.
    For now, return a placeholder structure.
    """
    # TODO: Implement fabric registry lookup
    # fabric_repo = BaseRepository(cosmos, ctx, FabricApi, "fabric_registry")
    # fabric_api = await fabric_repo.get(fabric_api_id)
    # if not fabric_api:
    #     raise NotFoundError(message="Fabric API not found")

    raise HTTPException(status_code=501, detail="Fabric API lookup not yet implemented")
    # return FabricApiResponse(
    #     fabric_api_id=fabric_api.id,
    #     name=fabric_api.name,
    #     description=fabric_api.description,
    #     category=fabric_api.category,
    #     api_spec=fabric_api.api_spec,
    #     auth_config=fabric_api.auth_config,
    # )
