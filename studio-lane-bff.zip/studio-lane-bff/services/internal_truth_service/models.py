"""Internal truth bundle service request/response models."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


class ContextBundleResponse(BaseModel):
    """Context bundle for GenAI context building."""

    project_id: str
    tenant_id: str
    selected_contexts: list[dict[str, Any]] = Field(default_factory=list)
    project_metadata: dict[str, Any] = Field(default_factory=dict)
    design_system_ref: dict[str, Any] | None = None
    fabric_registry_ref: dict[str, Any] | None = None


class FabricApiResponse(BaseModel):
    """Fabric API contract details for GenAI."""

    fabric_api_id: str
    name: str
    description: str | None = None
    category: str | None = None
    api_spec: dict[str, Any] = Field(default_factory=dict)
    auth_config: dict[str, Any] | None = None
