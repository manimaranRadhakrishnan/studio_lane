"""Internal truth bundle service for GenAI (service-to-service)."""

from .router import router

__all__ = ["router"]
