"""Build proxy service request/response models."""

from typing import Literal

from pydantic import BaseModel


class WcRef(BaseModel):
    blobBaseUri: str | None = None
    wcVersionStamp: str
    branch: str | None = None


class StartBuildRequest(BaseModel):
    """Contract-first build start request."""

    tenantId: str
    projectId: str
    platform: Literal["web", "ios", "android"]
    wcRef: WcRef
    buildMode: Literal["preview", "publish"] = "preview"

