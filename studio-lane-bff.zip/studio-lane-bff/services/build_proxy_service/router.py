"""Build proxy service router."""

from typing import Any

from fastapi import APIRouter, Depends

from services.build_proxy_service.models import StartBuildRequest
from shared import RequestContext, get_settings, require_role
from shared.clients_delivery import DeliveryClient
from shared.config import Settings


router = APIRouter()


@router.post("")
async def start_build(
    request: StartBuildRequest,
    ctx: RequestContext = Depends(require_role("Owner", "Editor")),
    settings: Settings = Depends(get_settings),
) -> dict[str, Any]:
    """
    Trigger a new build.

    Proxies to Delivery service.
    """
    delivery_client = DeliveryClient(settings)
    try:
        return await delivery_client.start_build(ctx=ctx, payload=request.model_dump())
    finally:
        await delivery_client.close()


@router.get("/{build_id}")
async def get_build(
    build_id: str,
    tenantId: str,
    ctx: RequestContext = Depends(require_role("Owner", "Editor")),
    settings: Settings = Depends(get_settings),
) -> dict[str, Any]:
    """
    Get build status and artifacts.

    Proxies to Delivery service.
    """
    delivery_client = DeliveryClient(settings)
    try:
        return await delivery_client.get_build(ctx=ctx, build_id=build_id, tenant_id=tenantId)
    finally:
        await delivery_client.close()

