"""Audit proxy service router."""

from typing import Any

from fastapi import APIRouter, Depends

from services.audit_proxy_service.models import WriteAuditEventRequest
from shared import RequestContext, get_request_context, get_settings
from shared.clients_control import AuditClient
from shared.config import Settings


router = APIRouter()


@router.post("/audit/events")
async def write_audit_event(
    request: WriteAuditEventRequest,
    ctx: RequestContext = Depends(get_request_context),
    settings: Settings = Depends(get_settings),
) -> dict[str, Any]:
    """
    Write an audit event to the ledger.

    Internal helper for other services to log user actions.
    Proxies to Audit/Control Plane service.
    """
    audit_client = AuditClient(settings)
    try:
        return await audit_client.write_event(
            ctx=ctx,
            event_type=request.event_type,
            resource_type=request.resource_type,
            resource_id=request.resource_id,
            action=request.action,
            details=request.details,
        )
    finally:
        await audit_client.close()


@router.get("/audit/ping")
async def ping(
    settings: Settings = Depends(get_settings),
) -> dict[str, str]:
    """
    Health check for audit service.

    Public endpoint (no auth required).
    """
    audit_client = AuditClient(settings)
    try:
        return await audit_client.ping()
    finally:
        await audit_client.close()

