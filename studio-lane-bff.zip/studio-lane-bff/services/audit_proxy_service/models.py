"""Audit proxy service request/response models."""

from typing import Any

from pydantic import BaseModel


class WriteAuditEventRequest(BaseModel):
    """Request to write an audit event."""

    event_type: str
    resource_type: str
    resource_id: str
    action: str
    details: dict[str, Any] | None = None

