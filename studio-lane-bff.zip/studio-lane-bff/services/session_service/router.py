"""Session service router."""

import uuid
from datetime import datetime

from fastapi import APIRouter, Depends, Header

from services.session_service.models import EndSessionResponse, HeartbeatResponse, StartSessionResponse
from shared import RequestContext, get_cosmosdb, get_request_context, require_role
from shared.cosmosdb import CosmosDBClient
from shared.models import StudioSession
from shared.repository import BaseRepository


router = APIRouter()


def get_session_repo(
    cosmos: CosmosDBClient = Depends(get_cosmosdb),
    ctx: RequestContext = Depends(get_request_context),
) -> BaseRepository[StudioSession]:
    return BaseRepository(cosmos, ctx, StudioSession, "studio_session")


@router.post("/start", response_model=StartSessionResponse)
async def start_session(
    ctx: RequestContext = Depends(require_role("Owner", "Editor")),
    repo: BaseRepository[StudioSession] = Depends(get_session_repo),
    x_session_id: str | None = Header(None, alias="X-Session-Id"),
):
    """
    Start or resume a Studio session projection.

    This does not replace SSO; it provides a stable session id for Studio Web workflows.
    """
    session_id = x_session_id or str(uuid.uuid4())
    existing = await repo.get(session_id)
    now = datetime.utcnow()

    if existing:
        await repo.update(session_id, last_seen_at=now)
        return StartSessionResponse(session_id=session_id)

    session = StudioSession(
        id=session_id,
        tenant_id=ctx.tenant_id,
        user_id=ctx.user_id,
        created_at=now,
        last_seen_at=now,
    )
    await repo.create(session)
    return StartSessionResponse(session_id=session_id)


@router.post("/heartbeat", response_model=HeartbeatResponse)
async def heartbeat(
    ctx: RequestContext = Depends(require_role("Owner", "Editor")),
    repo: BaseRepository[StudioSession] = Depends(get_session_repo),
    x_session_id: str | None = Header(None, alias="X-Session-Id"),
):
    """Update session last seen timestamp."""
    session_id = x_session_id or ctx.session_id
    if not session_id:
        # start_session will create one; heartbeat expects an existing session id
        return HeartbeatResponse(session_id=str(uuid.uuid4()))

    existing = await repo.get(session_id)
    if existing:
        await repo.update(session_id, last_seen_at=datetime.utcnow())
    return HeartbeatResponse(session_id=session_id)


@router.post("/end", response_model=EndSessionResponse)
async def end_session(
    ctx: RequestContext = Depends(require_role("Owner", "Editor")),
    repo: BaseRepository[StudioSession] = Depends(get_session_repo),
    x_session_id: str | None = Header(None, alias="X-Session-Id"),
):
    """End a Studio session projection (best-effort)."""
    session_id = x_session_id or ctx.session_id
    if not session_id:
        return EndSessionResponse(session_id=str(uuid.uuid4()), ended=False)

    ended = await repo.delete(session_id)
    return EndSessionResponse(session_id=session_id, ended=ended)


