"""Session service models."""

from pydantic import BaseModel


class StartSessionResponse(BaseModel):
    session_id: str


class HeartbeatResponse(BaseModel):
    session_id: str


class EndSessionResponse(BaseModel):
    session_id: str
    ended: bool


