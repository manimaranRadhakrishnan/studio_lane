"""Tests for folder endpoints."""

import pytest


def test_create_folder(test_client):
    """Test folder creation."""
    response = test_client.post(
        "/api/v1/studio/workspaces/folders",
        json={"name": "Test Folder"},
    )
    assert response.status_code == 201
    data = response.json()
    assert data["name"] == "Test Folder"
    assert "id" in data
    return data["id"]


def test_list_folders(test_client):
    """Test listing folders."""
    # Create a folder first
    test_client.post("/api/v1/studio/workspaces/folders", json={"name": "Test Folder"})

    response = test_client.get("/api/v1/studio/workspaces/folders")
    assert response.status_code == 200
    assert isinstance(response.json(), list)


def test_rename_folder(test_client):
    """Test folder renaming."""
    # Create folder
    create_response = test_client.post(
        "/api/v1/studio/workspaces/folders",
        json={"name": "Old Name"},
    )
    folder_id = create_response.json()["id"]

    # Rename
    response = test_client.put(
        f"/api/v1/studio/workspaces/folders/{folder_id}",
        json={"name": "New Name"},
    )
    assert response.status_code == 200
    assert response.json()["name"] == "New Name"


def test_delete_folder(test_client):
    """Test folder deletion."""
    # Create folder
    create_response = test_client.post(
        "/api/v1/studio/workspaces/folders",
        json={"name": "To Delete"},
    )
    folder_id = create_response.json()["id"]

    # Delete
    response = test_client.delete(f"/api/v1/studio/workspaces/folders/{folder_id}")
    assert response.status_code == 204

