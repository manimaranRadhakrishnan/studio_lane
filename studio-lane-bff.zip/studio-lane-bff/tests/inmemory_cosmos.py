"""In-memory CosmosDBClient test double."""

from __future__ import annotations

from collections import defaultdict
from typing import Any


class InMemoryCosmosDBClient:
    """
    Minimal in-memory stand-in for CosmosDBClient used by BaseRepository tests.

    Storage is partitioned by container_name and partition_key ("partitionKey").
    """

    def __init__(self):
        self._data: dict[str, dict[str, dict[str, dict[str, Any]]]] = defaultdict(lambda: defaultdict(dict))

    async def connect(self) -> None:  # pragma: no cover
        return None

    async def close(self) -> None:  # pragma: no cover
        return None

    async def create_item(self, item: dict[str, Any], container_name: str) -> dict[str, Any]:
        pk = item.get("partitionKey")
        if pk is None:
            raise ValueError("partitionKey required")
        item_id = item["id"]
        if item_id in self._data[container_name][pk]:
            raise ValueError("Item already exists")
        self._data[container_name][pk][item_id] = item
        return item

    async def read_item(self, item_id: str, partition_key: str, container_name: str) -> dict[str, Any] | None:
        return self._data[container_name][partition_key].get(item_id)

    async def upsert_item(self, item: dict[str, Any], container_name: str) -> dict[str, Any]:
        pk = item.get("partitionKey")
        if pk is None:
            raise ValueError("partitionKey required")
        item_id = item["id"]
        self._data[container_name][pk][item_id] = item
        return item

    async def delete_item(self, item_id: str, partition_key: str, container_name: str) -> bool:
        bucket = self._data[container_name][partition_key]
        if item_id not in bucket:
            return False
        del bucket[item_id]
        return True

    async def query_items(
        self,
        query: str,
        container_name: str,
        parameters: list[dict[str, Any]] | None = None,
        partition_key: str | None = None,
        max_item_count: int | None = None,
    ) -> list[dict[str, Any]]:
        params = {p["name"]: p["value"] for p in (parameters or [])}
        doc_type = params.get("@doc_type")
        tenant_id = params.get("@tenant_id") or partition_key

        if tenant_id is None:
            # For tests, treat missing partition key as empty.
            return []

        items = list(self._data[container_name][tenant_id].values())
        if doc_type is not None:
            items = [i for i in items if i.get("type") == doc_type]

        # Apply simple equality filters used by BaseRepository.list
        for name, value in params.items():
            if name.startswith("@filter_"):
                # Field name is embedded in query as "c.<field> = @filter_X"
                # We'll find the field token immediately before "= <param>".
                token = f"= {name}"
                if token in query:
                    left = query.split(token)[0].strip()
                    field = left.split()[-1].replace("c.", "")
                    items = [i for i in items if i.get(field) == value]

        # Best-effort ordering by createdAt if present
        if "ORDER BY c.createdAt DESC" in query:
            items.sort(key=lambda x: x.get("createdAt") or "", reverse=True)

        if max_item_count is not None:
            items = items[:max_item_count]
        return items


