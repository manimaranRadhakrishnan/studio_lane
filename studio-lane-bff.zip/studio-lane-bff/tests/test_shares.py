"""Tests for project sharing endpoints."""

import sys
from pathlib import Path

from fastapi.testclient import TestClient


sys.path.insert(0, str(Path(__file__).parent.parent.resolve()))

from services.studio_gateway_api.main import create_app

app = create_app()


client = TestClient(app)


def test_share_project(test_client):
    """Test sharing a project."""
    # Create a project first
    project_response = test_client.post(
        "/api/v1/studio/workspaces/projects",
        json={"name": "Test Project"},
    )
    project_id = project_response.json()["id"]

    # Share project
    response = test_client.post(
        f"/api/v1/studio/workspaces/projects/{project_id}/share",
        json={
            "shared_with_email": "colleague@example.com",
            "permission": "view",
        },
    )
    assert response.status_code == 201
    data = response.json()
    assert data["shared_with_email"] == "colleague@example.com"
    assert data["permission"] == "view"


def test_list_shares(test_client):
    """Test listing project shares."""
    # Create and share a project
    project_response = test_client.post(
        "/api/v1/studio/workspaces/projects",
        json={"name": "Test Project"},
    )
    project_id = project_response.json()["id"]

    test_client.post(
        f"/api/v1/studio/workspaces/projects/{project_id}/share",
        json={"shared_with_email": "user1@example.com", "permission": "view"},
    )

    # List shares
    response = test_client.get(f"/api/v1/studio/workspaces/projects/{project_id}/shares")
    assert response.status_code == 200
    assert isinstance(response.json(), list)
    assert len(response.json()) == 1


def test_remove_share(test_client):
    """Test removing a share."""
    # Create and share a project
    project_response = test_client.post(
        "/api/v1/studio/workspaces/projects",
        json={"name": "Test Project"},
    )
    project_id = project_response.json()["id"]

    share_response = test_client.post(
        f"/api/v1/studio/workspaces/projects/{project_id}/share",
        json={"shared_with_email": "user@example.com", "permission": "view"},
    )
    share_id = share_response.json()["id"]

    # Remove share
    response = test_client.delete(f"/api/v1/studio/workspaces/projects/{project_id}/shares/{share_id}")
    assert response.status_code == 204

