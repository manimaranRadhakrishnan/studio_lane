"""Tests for favorite endpoints."""

import pytest


def test_toggle_favorite(test_client):
    """Test toggling favorite status."""
    # Create a project first
    project_response = test_client.post(
        "/api/v1/studio/workspaces/projects",
        json={"name": "Test Project"},
    )
    project_id = project_response.json()["id"]

    # Add favorite
    response = test_client.post(f"/api/v1/studio/workspaces/projects/{project_id}/favorite")
    assert response.status_code == 200
    assert response.json()["favorited"] is True

    # Remove favorite
    response = test_client.post(f"/api/v1/studio/workspaces/projects/{project_id}/favorite")
    assert response.status_code == 200
    assert response.json()["favorited"] is False


def test_check_favorite_status(test_client):
    """Test checking if project is favorited."""
    # Create a project
    project_response = test_client.post(
        "/api/v1/studio/workspaces/projects",
        json={"name": "Test Project"},
    )
    project_id = project_response.json()["id"]

    # Check status (should be false initially)
    response = test_client.get(f"/api/v1/studio/workspaces/projects/{project_id}/favorites")
    assert response.status_code == 200
    assert response.json()["favorited"] is False

    # Add favorite
    test_client.post(f"/api/v1/studio/workspaces/projects/{project_id}/favorite")

    # Check status (should be true now)
    response = test_client.get(f"/api/v1/studio/workspaces/projects/{project_id}/favorites")
    assert response.status_code == 200
    assert response.json()["favorited"] is True

