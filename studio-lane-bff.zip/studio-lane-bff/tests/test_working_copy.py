"""Tests for working copy service."""


def test_apply_and_read_working_copy_file(test_client, tmp_path, monkeypatch):
    monkeypatch.setenv("WC_LOCAL_BASE_DIR", str(tmp_path))

    # Apply a file write
    resp = test_client.post(
        "/api/v1/studio/wc/apply",
        json={
            "project_id": "proj-1",
            "branch": "main",
            "operations": [
                {"op": "write_file", "path": "src/App.tsx", "content": "export const App = () => null;\n"},
            ],
        },
    )
    assert resp.status_code == 201
    body = resp.json()
    wc_version_stamp = body["data"]["wc_version_stamp"]

    # Read back
    resp = test_client.get(
        "/api/v1/studio/wc/files",
        params={
            "project_id": "proj-1",
            "branch": "main",
            "wc_version_stamp": wc_version_stamp,
            "path": "src/App.tsx",
        },
    )
    assert resp.status_code == 200
    body = resp.json()
    assert body["data"]["content"] == "export const App = () => null;\n"


def test_apply_clones_base_version(test_client, tmp_path, monkeypatch):
    monkeypatch.setenv("WC_LOCAL_BASE_DIR", str(tmp_path))

    # Base version
    resp = test_client.post(
        "/api/v1/studio/wc/apply",
        json={
            "project_id": "proj-1",
            "branch": "main",
            "operations": [
                {"op": "write_file", "path": "README.md", "content": "hello\n"},
            ],
        },
    )
    assert resp.status_code == 201
    base_stamp = resp.json()["data"]["wc_version_stamp"]

    # Clone (no operations)
    resp = test_client.post(
        "/api/v1/studio/wc/apply",
        json={
            "project_id": "proj-1",
            "branch": "main",
            "base_wc_version_stamp": base_stamp,
            "operations": [],
        },
    )
    assert resp.status_code == 201
    new_stamp = resp.json()["data"]["wc_version_stamp"]

    # File should exist in new version due to clone
    resp = test_client.get(
        "/api/v1/studio/wc/files",
        params={
            "project_id": "proj-1",
            "branch": "main",
            "wc_version_stamp": new_stamp,
            "path": "README.md",
        },
    )
    assert resp.status_code == 200
    assert resp.json()["data"]["content"] == "hello\n"


