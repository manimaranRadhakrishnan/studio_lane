"""Tests for workspace service."""

import pytest
from fastapi.testclient import TestClient


def test_health(test_client):
    """Test health endpoint."""
    response = test_client.get("/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "healthy"


def test_create_project(test_client):
    """Test project creation."""
    response = test_client.post(
        "/api/v1/studio/workspaces/projects",
        json={"name": "Test Project", "description": "Test description"},
    )
    assert response.status_code == 201
    data = response.json()
    assert data["name"] == "Test Project"
    assert "id" in data


def test_list_projects(test_client):
    """Test listing projects."""
    # Create a project first
    test_client.post("/api/v1/studio/workspaces/projects", json={"name": "Test Project"})

    response = test_client.get("/api/v1/studio/workspaces/projects")
    assert response.status_code == 200
    assert isinstance(response.json(), list)

