"""Tests for error normalization."""

from fastapi import HTTPException

from shared.errors import (
    AppError,
    AuthError,
    DownstreamError,
    NotFoundError,
    PermissionError,
    to_error_response,
)


def test_app_error():
    """Test AppError creation."""
    error = AppError(
        message="Test error",
        error_code="TEST_ERROR",
        status_code=500,
    )

    assert error.message == "Test error"
    assert error.error_code == "TEST_ERROR"
    assert error.status_code == 500


def test_auth_error():
    """Test AuthError creation."""
    error = AuthError(message="Invalid token")

    assert error.message == "Invalid token"
    assert error.error_code == "AUTH_ERROR"
    assert error.status_code == 401


def test_permission_error():
    """Test PermissionError creation."""
    error = PermissionError(message="Access denied")

    assert error.message == "Access denied"
    assert error.error_code == "PERMISSION_DENIED"
    assert error.status_code == 403


def test_not_found_error():
    """Test NotFoundError creation."""
    error = NotFoundError(message="Resource not found")

    assert error.message == "Resource not found"
    assert error.error_code == "NOT_FOUND"
    assert error.status_code == 404


def test_downstream_error():
    """Test DownstreamError creation."""
    error = DownstreamError(
        service="gen",
        message="Gen API failed",
        status_code=502,
    )

    assert error.message == "Gen API failed"
    assert error.error_code == "GEN_DOWNSTREAM_ERROR"
    assert error.status_code == 502
    assert error.details["service"] == "gen"


def test_to_error_response_with_app_error():
    """Test error response normalization with AppError."""
    error = AuthError(message="Invalid token")
    response = to_error_response(error, trace_id="test-trace")

    assert response["errorCode"] == "AUTH_ERROR"
    # AuthError uses get_error_message which may return standardized message
    assert "message" in response
    assert response["traceId"] == "test-trace"
    assert "details" in response


def test_to_error_response_with_http_exception():
    """Test error response normalization with HTTPException."""
    error = HTTPException(status_code=400, detail="Bad request")
    response = to_error_response(error, trace_id="test-trace")

    assert response["errorCode"] == "INTERNAL_ERROR"
    assert response["message"] == "Bad request"
    assert response["traceId"] == "test-trace"


def test_to_error_response_with_generic_exception():
    """Test error response normalization with generic Exception."""
    error = ValueError("Something went wrong")
    response = to_error_response(error, trace_id="test-trace")

    assert response["errorCode"] == "UNEXPECTED_ERROR"
    assert "message" in response
    assert response["traceId"] == "test-trace"
    assert response["details"]["error_type"] == "ValueError"

